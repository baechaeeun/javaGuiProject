SELECT * FROM ITEM;

SELECT * FROM INSERT_ITEM;
SELECT * FROM DELETE_ITEM;

drop trigger trg_insert_item;

CREATE TABLE ITEM
(
PRODUCT_ID VARCHAR2(20) PRIMARY KEY,
P_NAME VARCHAR2(20),
PRICE NUMBER,
DESCRIPTION VARCHAR2(20),
STOCK NUMBER
);

CREATE TABLE INSERT_ITEM
(
PRODUCT_ID VARCHAR2(20),
OLD_STOCK NUMBER,
NEW_STOCK NUMBER
);

CREATE TABLE DELETE_ITEM
(
PRODUCT_ID VARCHAR2(20),
OLD_STOCK NUMBER,
NEW_STOCK NUMBER
);


create or replace trigger trg_add_item
    after insert on INSERT_ITEM
    for each row
begin
    update item A
    set stock=:new.new_stock
    where product_id=:new.product_id;
end;
/

create or replace trigger trg_minus_item
    after insert on DELETE_ITEM
    for each row
begin
    update item A
    set stock=:new.new_stock
    where product_id=:new.product_id;
end;
/

create or replace trigger trg_delete_item1
    after delete on item
    for each row
begin
    delete from delete_item
    where product_id=:old.product_id;
end;
/

create or replace trigger trg_delete_item2
after delete on delete_item
    for each row
begin
    delete from insert_item
    where product_id=:old.product_id;
end;
/


