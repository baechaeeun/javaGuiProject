package �ǽ�����.com.kh.member.model.exception;

public class ItemException extends Exception {
	public ItemException() {
		
	}
	
	public ItemException(String message) {
		super(message);
	}

}
