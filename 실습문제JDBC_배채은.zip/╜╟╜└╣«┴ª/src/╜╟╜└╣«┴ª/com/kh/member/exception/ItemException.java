package �ǽ�����.com.kh.member.exception;

public class ItemException extends Exception{
	
	public ItemException() {
		
	}
	
	public ItemException(String message) {
		super(message);
	}


}
