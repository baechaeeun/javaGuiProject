package �ǽ�����.com.kh.member.model;
import static �ǽ�����.com.kh.common.JDBCTemplate.commit;
import static �ǽ�����.com.kh.common.JDBCTemplate.rollback;
import static �ǽ�����.com.kh.common.JDBCTemplate.close;
import static �ǽ�����.com.kh.common.JDBCTemplate.getConnection;
import java.sql.Connection;
import java.util.List;

import �ǽ�����.com.kh.member.exception.ItemException;
import �ǽ�����.com.kh.member.model.dao.ItemDAO;
import �ǽ�����.com.kh.member.model.vo.InsertDelete;
import �ǽ�����.com.kh.member.model.vo.Item;

public class ItemService {
	
	public List<Item> selectAll() throws ItemException{
		Connection conn = getConnection();
		List<Item> list = new ItemDAO().selectAll();
		return list;
	}
	public List<InsertDelete> selectDelete() throws ItemException{
		Connection conn = getConnection();
		List<InsertDelete> list = new ItemDAO().selectDelete();
		return list;
	}
	
	public List<InsertDelete> selectInsert() throws ItemException{
		Connection conn = getConnection();
		List<InsertDelete> list = new ItemDAO().selectInsert();
		return list;
	}

	public Item selectOne(String memberId) throws ItemException {
		Connection conn=getConnection();
		Item m =new ItemDAO().selectOne(conn, memberId);
		return m;
	}

	public int insertItem(Item m) throws ItemException {
		Connection conn=getConnection();
		int result=new ItemDAO().insertItem(conn,m);
		
		if(result > 0) commit(conn);// ����
		else rollback(conn);// �ǵ�����
		return result;
	}

	public List<Item> selectByName(String memberName) throws ItemException {
		Connection conn=getConnection();
		List<Item> list = new ItemDAO().selectByName(conn,memberName);
		
		return list;
	}

	public int updateItem(Item m) throws ItemException {
		Connection conn=getConnection();
		int result = new ItemDAO().updateItem(conn,m);
		if(result > 0) commit(conn);// ����
		else rollback(conn);// �ǵ�����
		return result;
	}

	public int deleteItem(String userId) throws ItemException {
		Connection conn=getConnection();
		int result = new ItemDAO().deleteItem(conn,userId);
		if(result > 0) commit(conn);// ����
		else rollback(conn);// �ǵ�����
		return result;
	}

	public void exitProgram() {
		close(getConnection());
	}
	public int add(String inputItemId) throws ItemException{
		Connection conn=getConnection();
		int result=new ItemDAO().add(conn,inputItemId);
		
		if(result > 0) commit(conn);// ����
		else rollback(conn);// �ǵ�����
		return result;
	}
	public int minus(String inputItemId)  throws ItemException{
		Connection conn=getConnection();
		int result=new ItemDAO().minus(conn,inputItemId);
		
		if(result > 0) commit(conn);// ����
		else rollback(conn);// �ǵ�����
		return result;
	}
	
}
