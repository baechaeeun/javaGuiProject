package �ǽ�����.com.kh.member.model.vo;

public class InsertDelete {
	private String product_id;
	private int old_stock;
	private int new_stock;
	public String getProduct_id() {
		return product_id;
	}
	public void setProduct_id(String product_id) {
		this.product_id = product_id;
	}
	public int getOld_stock() {
		return old_stock;
	}
	public void setOld_stock(int old_stock) {
		this.old_stock = old_stock;
	}
	public int getNew_stock() {
		return new_stock;
	}
	public void setNew_stock(int new_stock) {
		this.new_stock = new_stock;
	}
	
	public String toString() {
		return product_id+", "+old_stock+", "+new_stock;
	}
	
	

}
