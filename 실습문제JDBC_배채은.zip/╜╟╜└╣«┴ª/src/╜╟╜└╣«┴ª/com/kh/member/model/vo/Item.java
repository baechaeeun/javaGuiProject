package �ǽ�����.com.kh.member.model.vo;

import java.io.Serializable;

public class Item implements Serializable{
	
	private static final long serialversionUID = 1L;
	
	private String ItemId;
	private String ItemName;
	private int ItemPrice;
	private String ItemDescription;
	private int ItemStock;
	
	
	public Item() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Item(String itemId, String itemName, int itemPrice, String itemDescription, int itemStock) {
		super();
		ItemId = itemId;
		ItemName = itemName;
		ItemPrice = itemPrice;
		ItemDescription = itemDescription;
		ItemStock = itemStock;
	}


	public String getItemId() {
		return ItemId;
	}


	public void setItemId(String itemId) {
		ItemId = itemId;
	}


	public String getItemName() {
		return ItemName;
	}


	public void setItemName(String itemName) {
		ItemName = itemName;
	}


	public int getItemPrice() {
		return ItemPrice;
	}


	public void setItemPrice(int itemPrice) {
		ItemPrice = itemPrice;
	}


	public String getItemDescription() {
		return ItemDescription;
	}


	public void setItemDescription(String itemDescription) {
		ItemDescription = itemDescription;
	}


	public int getItemStock() {
		return ItemStock;
	}


	public void setItemStock(int itemStock) {
		ItemStock = itemStock;
	}


	public static long getSerialversionuid() {
		return serialversionUID;
	}
	
	public String toString() {
		return ItemId+", "+ItemName+", "+ItemPrice+", "+ItemDescription+", "+ItemStock;
	}

}
