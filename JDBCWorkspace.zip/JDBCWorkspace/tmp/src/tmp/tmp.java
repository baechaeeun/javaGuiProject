package tmp;

import java.util.Arrays;
import java.util.Scanner;

public class tmp {
	public static void main(String args[]) {
		Scanner sc=new Scanner(System.in);
		
		int num=sc.nextInt();
		int result[]=new int[num];
		sc.nextLine();
		
		
		for(int i=0;i<num;i++) {
			String str=sc.nextLine();
			int arr[]=new int[str.length()];
			
			for(int j=0;j<str.length();j++) {
				if(str.charAt(j)=='O') {
					if(j==0)
						arr[j]=1;
					else {
						arr[j]=arr[j-1]+1;
					}
				}
			}
			
			for(int j=0;j<str.length();j++) {
				result[i]+=arr[j];
			}
			
		}
		
		for(int i=0;i<num;i++) {
			System.out.println(result[i]);
		}
	}
}
