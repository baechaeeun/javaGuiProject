package com.kh.member.model;
import static com.kh.common.JDBCTemplate.commit;
import static com.kh.common.JDBCTemplate.rollback;
import static com.kh.common.JDBCTemplate.close;
import static com.kh.common.JDBCTemplate.getConnection;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

import com.kh.member.model.dao.MemberDAO;
import com.kh.member.model.exception.MemberException;
import com.kh.member.model.vo.Member;

public class MemberService {

	public List<Member> selectAll() throws MemberException {
		Connection conn = getConnection();
		List<Member> list = new MemberDAO().selectAll();
		return list;
	}
	
	public List<Member> selectDelete() throws MemberException{
		Connection conn = getConnection();
		List<Member> list = new MemberDAO().selectDelete();
		return list;
	}

	public Member selectOne(String memberId) throws MemberException {
		Connection conn=getConnection();
		Member m =new MemberDAO().selectOne(conn, memberId);
		return m;
	}

	public int insertMember(Member m) throws MemberException {
		Connection conn=getConnection();
		int result=new MemberDAO().insertMember(conn,m);
		
		if(result > 0) commit(conn);// 적용
		else rollback(conn);// 되돌리기
		return result;
	}

	public List<Member> selectByName(String memberName) throws MemberException {
		Connection conn=getConnection();
		List<Member> list = new MemberDAO().selectByName(conn,memberName);
		
		return list;
	}

	public int updateMember(Member m) throws MemberException {
		Connection conn=getConnection();
		int result = new MemberDAO().updateMember(conn,m);
		if(result > 0) commit(conn);// 적용
		else rollback(conn);// 되돌리기
		return result;
	}

	public int deleteMember(String userId) throws MemberException {
		Connection conn=getConnection();
		int result = new MemberDAO().deleteMember(conn,userId);
		if(result > 0) commit(conn);// 적용
		else rollback(conn);// 되돌리기
		return result;
	}

	public void exitProgram() {
		close(getConnection());
	}
	
	
}
