package com.kh.member.controller;

import java.util.ArrayList;
import java.util.List;

import com.kh.member.model.MemberService;
import com.kh.member.model.dao.MemberDAO;
import com.kh.member.model.exception.MemberException;
import com.kh.member.model.vo.Member;
import com.kh.member.view.MemberMenu;

public class MemberController {

	// view 와 dao(db와 연결 )를  연결해주는 객체
	// view <-> controller <-> dao <-> db
	public void selectAll() {
		
		MemberMenu menu = new MemberMenu();//컨트롤러와 view 연결 

		try {
			List<Member> list;
			list = new MemberService().selectAll();

			if (!list.isEmpty()) {

				menu.displayMemberList(list);

			} else {

				menu.displayNoData();
			}
		} catch (MemberException e) {
			menu.displayError("회원 조회 실패, 관리자에게 문의하세요");
			System.out.println(e.getMessage());
		}
		 
		
		
		
	}
	
	public void selectDeleteMember() {
		MemberMenu menu = new MemberMenu();// 컨트롤러와 view 연결

		try {
			List<Member> list;
			list = new MemberService().selectDelete();
			if (!list.isEmpty()) {

				menu.displayMemberList(list);

			} else {

				menu.displayNoData();
			}
		} catch (MemberException e) {
			menu.displayError("회원 삭제 조회 실패, 관리자에게 문의하세요");
			System.out.println(e.getMessage());
		}

	}

	public void selectOne(String memberId) {
		MemberMenu menu = new MemberMenu();// view를 통해 결과를 보여주기 위해 뷰 객체 생성

		try {
			Member m;
			m = new MemberService().selectOne(memberId);
			if (m != null) {// m 객체에 데이터가 있으면

				menu.displayMember(m);// view 를 통해 레코드 출력

			} else {// m 객체에 데이터가 없으면
				menu.displayNoData();
			}
		} catch (MemberException e) {
			
			menu.displayError("회원 조회 실패, 관리자에게 문의하세요");
			System.out.println(e.getMessage());
		}
		
	}

	public void insertMember(Member m) {
		int result;
		try {
			result = new MemberService().insertMember(m);

			if (result > 0) {
				new MemberMenu().displaySuccess("회원 가입 성공");
			} 
		} catch (MemberException e) {
			new MemberMenu().displayError("회원 가입 실패, 관리자에게 문의하세요");
			System.out.println(e.getMessage());
		}

	}
	public void selectByName(String memberName) {
		MemberMenu menu = new MemberMenu();
		List<Member> list;
		
		try {
			list = new MemberService().selectByName(memberName);
			if (!list.isEmpty()) {
				menu.displayMemberList(list);
			} else {
				menu.displayNoData();
			}
		} catch (MemberException e) {
			menu.displayError("회원 조회 실패, 관리자에게 문의하세요");
			System.out.println(e.getMessage());
		}
	}
	
	public void updateMember(Member m) {
		try {
			if(new MemberService().updateMember(m) > 0)
				new MemberMenu().displaySuccess("회원 정보가 변경되었습니다.");
			else
				new MemberMenu().displayNoData();
		} catch (MemberException e) {
			new MemberMenu().displayError("회원 정보 변경 실패, 관리자에게 문의하세요");
			System.out.println(e.getMessage());
		}
	}

	public void deleteMember(String userId) {
		try {
			if(new MemberService().deleteMember(userId) > 0)
				new MemberMenu().displaySuccess("회원 탈퇴 성공!");
			else
				new MemberMenu().displayNoData();
		} catch (MemberException e) {
			new MemberMenu().displayError("회원 탈퇴 실패, 관리자에게 문의하세요");
			System.out.println(e.getMessage());
		}
	}

	public void exitProgram() {
		new MemberService().exitProgram();
	}
}
