package com.kh.member.controller;

import java.util.ArrayList;
import java.util.List;

import com.kh.member.model.dao.MemberDAO;
import com.kh.member.model.vo.Member;
import com.kh.member.view.MemberMenu;

public class MemberController {

	// view 와 dao(db와 연결 )를  연결해주는 객체
	// view <-> controller <-> dao <-> db
	public void selectAll() {
		
		MemberMenu menu = new MemberMenu();//컨트롤러와 view 연결 
		
		ArrayList<Member> list = new MemberDAO().selectAll();// DAO 에서 멤머 list 를 받아서 리턴
		
		if(!list.isEmpty()) {
			
			menu.displayMemberList(list);
			
		}else {
			
			menu.displayError("해당되는 데이터가 없습니다.");
		}
		 
		
		
		
	}

	public void selectOne(String memberId) {
		MemberMenu menu = new MemberMenu();//view를 통해 결과를 보여주기 위해 뷰 객체 생성 
		
		Member m = new MemberDAO().selectOne(memberId);//Dao 를 통해 db에 접근하여 데이터 리턴 
		if(m != null) {// m 객체에 데이터가 있으면
			
			menu.displayMember(m);//view 를 통해 레코드 출력 
			
		}else {// m 객체에 데이터가 없으면
			menu.displayError(memberId + "해당되는 데이터가 없습니다.");//view 를 통해 레코드 출력 
		}
		
	}

	public void insertMember(Member m) {
		int result = new MemberDAO().insertMember(m);//insert, update,delete 는  쿼리문 성공 갯수가 리턴
		if(result > 0) {
			new MemberMenu().displaySuccess("회원 가입 성공");
		}else {
			new MemberMenu().displayError("회원 가입 실패");
		}
		
	}
	public void selectByName(String memberName) {
		MemberMenu menu = new MemberMenu();
		List<Member> list = new MemberDAO().selectByName(memberName);
		//if~else로 에러상황처리
		if(!list.isEmpty()){
			menu.displayMemberList(list);
		}
		else{
			menu.displayError(memberName+"에 해당되는 데이터가 없습니다.");
		}
	}
	
	public void updateMember(Member m) {
		if(new MemberDAO().updateMember(m) > 0)
			new MemberMenu().displaySuccess("회원 정보가 변경되었습니다.");
		else
			new MemberMenu().displayError("회원 정보 변경 실패!");
	}

	public void deleteMember(String userId) {
		if(new MemberDAO().deleteMember(userId) > 0)
			new MemberMenu().displaySuccess("회원 탈퇴 성공!");
		else
			new MemberMenu().displayError("회원 탈퇴 실패!");
	}

}
