package 문제;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class ScoreFrame extends JFrame{
	
	private JTextField javaScore;
	private JTextField sqlScore;
	private JTextField total;
	private JTextField average;
	private JButton calcBtn;
	
	public ScoreFrame() {
		this.setLayout(null);
		this.setSize(600,500);
		this.setTitle("문제 7");
		
		JLabel text=new JLabel("점수를 입력하세요");
		text.setBounds(250,10,600,100);
		this.add(text);
		
		JLabel j=new JLabel("자바 : ");
		j.setBounds(30,150,50,30);
		this.add(j);
		javaScore=new JTextField();
		javaScore.setBounds(90, 150, 100,30);
		
		JLabel s=new JLabel("SQL : ");
		s.setBounds(400,150,50,30);
		this.add(s);
		sqlScore=new JTextField();
		sqlScore.setBounds(460, 150, 100,30);
		
		calcBtn=new JButton("계산하기");
		calcBtn.setBounds(250, 250, 100,30);
		this.add(calcBtn);
		
		JLabel t=new JLabel("총점 : ");
		t.setBounds(30,400,50,30);
		this.add(t);
		total=new JTextField();
		total.setBounds(90, 400, 100,30);
		
		
		JLabel a=new JLabel("평균 : ");
		a.setBounds(400,400 ,50,30);
		this.add(a);
		average=new JTextField();
		average.setBounds(460, 400, 100,30);
		
		
		this.add(javaScore);
		this.add(sqlScore);
		this.add(total);
		this.add(average);
		
		
		calcBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int java=Integer.parseInt(javaScore.getText());
				int sql=Integer.parseInt(sqlScore.getText());
				int t=java+sql;
				int a=t/2;
				
				total.setText(Integer.toString(t));
				average.setText(Integer.toString(a));
			}
		});
		
		
		
		this.setVisible(true);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
	}

}
