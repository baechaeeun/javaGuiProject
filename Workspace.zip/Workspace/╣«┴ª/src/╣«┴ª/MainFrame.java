package 문제;

public class MainFrame {

	public static void main(String[] args) {
		new ScoreFrame();

	}

}
