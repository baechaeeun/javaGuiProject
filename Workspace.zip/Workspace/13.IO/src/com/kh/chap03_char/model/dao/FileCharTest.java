package com.kh.chap03_char.model.dao;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class FileCharTest {
	
	// 프로그램 --> 파일 (출력 : 프로그램 내의 파일 내보내기 )
	public void fileSave() {
		
		//FileWriter : 파일로 데이터를 2byte 단위로 출력하기 ( 한글 (2byte) 깨지지 않는다.)
		//1. FileWriter 객체 생성 --> 해당 파일이 없으면 자동으로 파일이 만들어지고 연결통로 만들어준다.
		//						해당파일이 기존에 있다면 연결 통로만 만들어진다.
		
		FileWriter fw=null;
		try {
			fw=new FileWriter("b_char.txt",true);
			
			fw.write("와 재밌다");
			fw.write('A');
			fw.write(' ');
			fw.write("\n");
			
			char[] cArr= {'a','p','p','l','e'};
			fw.write(cArr);
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				fw.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
	}
	
	public void fileOpen() {
		//FileReader : 파일로부터 데이터를 2byte 단위로 입력받기
		
		//1. FileReader 객체생성 --> 파일과의 연결 통로 만들어짐
		
		FileReader fr = null;
		
		try {
			fr=new FileReader("b_char.txt"); //스트림생성 //FileNotFoundException
			
			int value=0;
			while((value = fr.read())!=-1){ //IOException
				System.out.println((char)value);
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				fr.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}

}
