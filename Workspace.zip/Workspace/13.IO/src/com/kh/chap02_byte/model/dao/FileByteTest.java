package com.kh.chap02_byte.model.dao;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class FileByteTest {
	/* 스트림의 특징
	 * - 단방향 : 입력이면 입력 / 출력이면 출력만 가능!! 입력과 출력을 동시다발적으로 한다면 하나의 스트림으로 안됨
	 * 입력 스트림, 출력 스트림 따로 열어야함
	 * - 선입선출 : 통로가 곧 파이프같은 개념이기 때문에 먼저 보낸 값이 먼저 나옴 ! 시간지연
	 * 
	 * * 스트림의 구분
	 * > 통로의 사이즈 (1byte짜리 / 2byte짜리)
	 * 		- 바이트 스트림 : 1byte짜리 왔다갔다 할 수 있을 정도으 ㅣ사이즈! (좁은 통로) => 
	 * 입력(InputeStream)/출력(OutputStream)
	 * 		-문자 스트림 : 2byte짜리 왔다 갔다 할 수 있을 정도의 사이즈! (좀더 넓은 통로)=>
	 * 입력(Reader)/출력(Writer)
	 * 
	 * >외부매체와 직접 연결하는 유무
	 *  -기반스트림 : 외부 매체와 직접적으로 연결하는 통로
	 *  -보조스트림 : 말그대로 보조역할만 하는 통로(속도를 빠르게 한다거나, 그 외에 유용한 기능들을 제공을 한다거나)
	 *  따라서 보조스트림 단독으로는 사용 불가!! 반드시 외부매체와 연결되어있는 기반 스트림은 기본적으로 있어야됨
	 */
	
	public void fileSave() {
		FileOutputStream fout=null;
		
		try {
			// true : 미작성시 --> 기존 해당 파일이 있을 경우 덮어 씌워짐 ( 기본값 false)
			// true : 작성시 --> 기존에 해당 파일이 있을 경우 이어서 작성됨.
			fout = new FileOutputStream("a_byte.txt",true);
			
		//2. 파일에 데이터를 출력하고자 할때 write() 메소드 사용
			//1byte 단위로 출력이 되기 때문에 -128~127사이의 숫자만 출력이 가능
			//(단, 파일에 기록되는 것은 해당 숫자의 고유한 문자가 기록)
			fout.write(97); //a 문자가 저장
			fout.write('b'); //b 문자가 저장
			//fout.write('강'); 한글은 2byte 여서 꺠져서 저장 (바이트 스트림이기 때문에 제한)
			
			byte[] bArr= {99,100,101}; //cde가 저장
			fout.write(bArr);
			
			//write(byte[] b, int off, int length);
			fout.write(bArr, 0 , 1); 
			
			fout.close();
			
		}catch(FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				fout.close(); //3. 스트림 이용 다했으면 반드시 닫아주기 !!
			}catch(IOException e){
				e.printStackTrace();
			}
		}	
	}
	
	//프로그램 <-- 파일 (입력 : 파일로부터 데이터 받아오기 )
	public void fileRead() {
		//FileInputStream : 파일로부터 데이터를 1바이트 단위로 입력받는 스트림
		
		//1. FileInputStream 객체 생성 --> 해당 파일과의 연결 통로가 만들어 진다. 파일이 존재하지 않으면 FileNotFoundException 발생
		
		FileInputStream fis=null;
		try {
			fis = new FileInputStream("a_byte.txt");
			
			//2. 파일로부터 데이터를 입력받고자 할때 read() 메소드사용 - 1byte 단위로 읽어오게 된다. 파일의 끝을 만나면 01 값을 받아온다.
			/*
			System.out.println(fis.read());
			System.out.println(fis.read());
			System.out.println(fis.read());
			System.out.println(fis.read());
			System.out.println(fis.read());
			System.out.println(fis.read());
			System.out.println(fis.read());*/
			
			int value = 0; // 변수 하나 만들어놓고 read()하면서 닫아준다. EOF(파일의 끝) 을 만나면 -1
			while((value = fis.read())!=-1) {
				//System.out.println(value); // 아스키코드 숫자값
				System.out.println((char)value);//문자로 강제 형변환
			}
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				fis.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}
}
