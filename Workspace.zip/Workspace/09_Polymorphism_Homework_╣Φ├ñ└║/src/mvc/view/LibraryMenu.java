package mvc.view;

import java.util.Scanner;

import mvc.controller.LibraryManager;
import mvc.model.vo.Book;
import mvc.model.vo.Member;

public class LibraryMenu {
	private LibraryManager lb=new LibraryManager();
	private Scanner sc=new Scanner(System.in);
	
	public void mainMenu() {
		System.out.println("이름을 입력하세요 : ");
		String name=sc.nextLine();
		System.out.println("나이를 입력하세요 : ");
		int age=sc.nextInt();sc.nextLine();
		System.out.println("성별을 입력하세요 : ");
		char gender=sc.nextLine().charAt(0);
		
		lb.insertMember(new Member(name,age,gender));
		
		while(true) {
			System.out.println("====메뉴====");
			System.out.println("1. 마이페이지 ");
			System.out.println("2. 도서 전체 조회");
			System.out.println("3. 도서 검색");
			System.out.println("4. 도서 대여하기");
			System.out.println("0. 프로그램 종료하기");
			
			int menu=sc.nextInt(); sc.nextLine();
			
			switch(menu) {
			
			case 1:
				System.out.println(lb.myInfo().toString());
				break;
			case 2:
				selectAll();
				break;
			case 3:
				searchBook();
				break;
			case 4:
				rentBook();
				break;
			case 0:
				return;
			default:
				break;
			}
		}
		
	}
	
	public void selectAll() {
		Book[] bList=lb.selectAll();
		
		for(int i=0;i<bList.length;i++) {
			System.out.println(i+"번 도서 : "+bList[i].toString());
		}
		
	}
	public void searchBook() {
		System.out.print("검색할 제목 키워드 : ");
		String keyWord=sc.nextLine();
		
		Book[] searchList=lb.searchBook(keyWord);
		
		for(Book b:searchList) {
			if(b!=null)
				System.out.println(b.toString());
		}
		
	}
	
	public void rentBook() {
		selectAll();
		
		System.out.print("대여할 도서 번호 선택 : ");
		int num=sc.nextInt();sc.nextLine();
		
		switch(lb.rentBook(num)) {
		case 0:
			System.out.println("성공적으로 대여되었습니다.");
			break;
		case 1:
			System.out.println("나이 제한으로 대여 불가능입니다.");
			break;
		case 2:
			System.out.println("성공적으로 대여되었습니다. 요리학원 쿠폰이 발급되었습니다. 마이페이지를 통해 확인하세요");
			break;
			default:
				break;
		}
	}
	

}
