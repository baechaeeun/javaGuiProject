package mvc.run;

import mvc.view.LibraryMenu;

public class Run {
	public static void main(String args[]) {
		LibraryMenu lm = new LibraryMenu();
		lm.mainMenu();
	}
}
