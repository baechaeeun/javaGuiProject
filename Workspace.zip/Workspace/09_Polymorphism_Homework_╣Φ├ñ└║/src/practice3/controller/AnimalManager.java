package practice3.controller;

import practice3.model.vo.Animal;
import practice3.model.vo.Cat;
import practice3.model.vo.Dog;

public class AnimalManager {
	public static void main(String args[]) {
		Animal [] a=new Animal[5];
		
		a[0]=new Cat("a","페르시안","A","초록");
		a[1]=new Dog("b","말티즈",12);
		a[2]=new Dog("c","포메라니안",14);
		a[3]=new Dog("d","시츄",15);
		a[4]=new Cat("e","스핑크스","B","분홍");
		
		for(int i=0;i<a.length;i++) {
			a[i].speak();
		}
	}

}
