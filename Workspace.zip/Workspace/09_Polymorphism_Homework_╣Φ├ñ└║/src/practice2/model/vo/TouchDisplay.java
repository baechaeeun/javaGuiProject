package practice2.model.vo;

public interface TouchDisplay {

	public abstract void touch();
}
