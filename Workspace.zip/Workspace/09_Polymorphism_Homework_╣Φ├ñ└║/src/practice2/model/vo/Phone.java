package practice2.model.vo;

public interface Phone {
	
	public abstract void makeacall();
	public abstract void takeaCall();

}
