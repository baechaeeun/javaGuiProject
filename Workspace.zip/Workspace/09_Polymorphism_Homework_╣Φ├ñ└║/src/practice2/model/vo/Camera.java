package practice2.model.vo;

public interface Camera {
	
	public abstract void picture();

}
