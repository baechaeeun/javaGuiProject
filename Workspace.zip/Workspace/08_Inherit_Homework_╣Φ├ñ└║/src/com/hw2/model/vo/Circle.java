package com.hw2.model.vo;

public class Circle extends Point{
	private int radius;
	
	public Circle() {}

	public Circle(int x,int y,int radius) {
		super(x,y);
		this.radius = radius;
	}
	
	
	public int getRadius() {
		return radius;
	}

	public void setRadius(int radius) {
		this.radius = radius;
	}

	public void draw() {
		System.out.println("(x,y) : ("+super.getX()+", "+super.getY()+")");
		System.out.println("면적 : "+String.format("%.1f", (double)radius*radius*3.14));
		System.out.println("둘레 : "+String.format("%.1f", (double)2*radius*3.14));
		
	}
	

}
