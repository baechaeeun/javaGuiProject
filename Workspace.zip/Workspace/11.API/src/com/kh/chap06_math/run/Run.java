package com.kh.chap06_math.run;

public class Run {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//static - 프로그램 시작할 때 딱 한번 static 영역에 올려 객체 생성해서 사용할 필요없이 Math.로 바로 접근
		
		//상수필드
		System.out.println("파이 : "+Math.PI);
		
		//절대값
		int num1=-10;
		System.out.println(Math.abs(num1));
		
		//올림
		double num2=4.349;
		System.out.println(Math.ceil(num2));
		
		//반올림
		System.out.println(Math.round(num2));
		
		//버림
		System.out.println(Math.floor(num2));
		
		//가장 가까운 정수값
		System.out.println(Math.rint(num2));
		
		//제곱근(루트)
		System.out.println(Math.sqrt(num2));
		
		//제곱 --> pow
		System.out.println(Math.pow(2, 10));
	}

}
