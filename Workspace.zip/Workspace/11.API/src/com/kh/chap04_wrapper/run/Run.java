package com.kh.chap04_wrapper.run;

import com.kh.chap04_wrapper.controller.A_WrapperTest;
import com.kh.chap04_wrapper.controller.B_WrapperString;

public class Run {

	public static void main(String[] args) {
		/*A_WrapperTest a=new A_WrapperTest();
		
		a.method1();*/
		
		B_WrapperString b=new B_WrapperString();
		b.method1();

	}

}
