package com.kh.chap01_string_K.run;

public class Run {

	public static void main(String[] args) {
		
		//Run.method1(); // static 메소드라 new 연산자로 메소드 를 포함한 객체를 올릴 필요 없다.

		new Run().method2(); //no-static 메소드라 메소드를 포함한 객체를 올려야 한다.
	}

	private static void method1() {
		//1. 문자열을 리터럴로 생성
		String str="abc"; //heap 객체 생성
							//리터럴 방식으로 생성하면 -> constant poll에 저장이 된다.
							//-->동등한 값이 들어오면 기존 객체가 유지된다.
		
		String str1="abc";
		String str2="def";
		
		//2. 문자열을 new 생성자()로 생성
		String str3=new String("abc"); //heap에 객체 생성
		String str4=new String("abc");
		
		//str과 str1 비교
		System.out.println(str);
		System.out.println(str1);
		
		//주소값 출력을 위해 hash 코드 찍기 (String hashCode는 오버라이딩해서 안에 지닌 값이 같으면 같은 값을 반환 하도록 오버라이딩 됨)
		System.out.println(str.hashCode());
		System.out.println(str1.hashCode());
		
		System.out.println(System.identityHashCode(str));
		System.out.println(System.identityHashCode(str1));
		System.out.println(System.identityHashCode(str2));
		
		System.out.println(System.identityHashCode(str3));
		System.out.println(System.identityHashCode(str4));
		
		str3+="z";
		System.out.println(System.identityHashCode(str3));
		
	}
	public void method2() {
		String str = "abc";
		
		//charAt(해당 인덱스); 문자 뽑아내기
		System.out.println(str.charAt(2)); //"abc" -> c
		
		//concat : 문자열 합치기
		System.out.println(str.concat("def")); //abc -> "abcdef"
		
		
		//contains : 포함여부 확인
		System.out.println(str.contains("ab")); //"abc"에서 "ab"포함여부 확인
		
		//equals : 동등 여부 확인 (문자값이 일치)
		System.out.println(str.equals("abc"));
		
		//length : 문자열 길이 ( 문자열에 포함된 문자 개수)
		System.out.println(str.length());
		
		//split : 문자 구분 (특수기호를 기준으로 각각을 문자열 배열로 쪼개서 반환하는 메소드)
		String str1= "a,bc,de";
		String[] strArr=str1.split(",");
		
		for(int i=0;i<strArr.length;i++) {
			System.out.println(strArr[i]);
		}
		
		for(String a:strArr) {
			System.out.println(a);
		}
		
		//toUpperCase : 대문자로
		//toLowerCase : 소문자로
		//equalsIgnoreCase : 대소문자 상관없이 문자열 비교 - true,false 값 반환
		String strCase1 = "Abc";
		String strCase2 = "abc";
		
		System.out.println(strCase1.toUpperCase());
		System.out.println(strCase2.toUpperCase());
		
		System.out.println(strCase1.equalsIgnoreCase(strCase2));
		
		//trim : 공백제거
		String str2="             ab       c";
		System.out.println(str2);
		System.out.println(str2.trim());
		
	}

}
