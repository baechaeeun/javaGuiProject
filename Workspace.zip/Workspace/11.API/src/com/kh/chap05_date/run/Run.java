package com.kh.chap05_date.run;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class Run {

	public static void main(String[] args) {


		/* Date (java.util패키지)
		 * 날짜를 다루기 위해 제공되는 클래스
		 * 자바 초기에 급하게 만들어져서 완성도가 낮고, 다국적으로 쓰이기에는 적합하지 않다.
		 * 년도 + 1900, 월 +1 내부적으로 한다.
		 * 
		 */
		
		//현재 시각(Date 기본 생성) : 컴퓨터의 시간
		Date today = new Date();
		System.out.println(today);
		
		//내가 원하는 날짜(Date의 매개변수 있는 생성자)
		Date today1 = new Date(111,2,21); //2020.01.28 --> 120+1900,0+1,28
		System.out.println(today1);
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd E요일");
		System.out.println(sdf.format(today1));
		
		String curTime = new SimpleDateFormat("yyyyMMddHmmss").format(new Date());
		System.out.println("curTime"+curTime);
		
		//시간에 대해 원하는 값 뽑아보기
		System.out.println("시간 : "+today.getTime());
		System.out.println("날짜 : "+today.getDate());
		System.out.println("요일 : "+today.getDay());
		System.out.println("시 : "+today.getHours());
		System.out.println("분 : "+today.getMinutes());
		System.out.println("달 : "+today.getMonth()+1); //주의
		System.out.println("초 : "+today.getSeconds());
		System.out.println("년 : "+today.getYear()+1900); //주의


		//2. Calendar
		// 월만 +1 (년도는 직접 입력)
		// 년은 뽑고자하는 년도 직접 입력
		// TimeZone 기능 제고 o
		// 
		Calendar calendar = Calendar.getInstance(); //기본생성자가 protected 이므로 new로 생성
		
		calendar.set(2020,0,8); //set 메소드를 통해서 시간 설정 // 월 주의 -1 값
		
		//시간에 대해 원하는 값 뽑기
		
		System.out.println("날짜 : "+calendar.get(GregorianCalendar.DATE));
		System.out.println("요일 : "+calendar.get(GregorianCalendar.DAY_OF_WEEK));
		System.out.println("시 : "+calendar.get(GregorianCalendar.HOUR));
		System.out.println("분 : "+calendar.get(GregorianCalendar.MINUTE));
		System.out.println("달 : "+calendar.get(GregorianCalendar.MONTH+1));
		System.out.println("초 : "+calendar.get(GregorianCalendar.SECOND));
		System.out.println("년 : "+calendar.get(GregorianCalendar.YEAR));
		
		SimpleDateFormat sdf1=new SimpleDateFormat("yyyy-MM-dd E요일 hh:mm:ss");
		System.out.println(sdf1.format(calendar.getTime()));
		
		GregorianCalendar gc = new GregorianCalendar();// 현재시간
		
		System.out.println("날짜 : "+gc.get(GregorianCalendar.DATE));
		System.out.println("요일 : "+gc.get(GregorianCalendar.DAY_OF_WEEK));
		System.out.println("시 : "+gc.get(GregorianCalendar.HOUR));
		System.out.println("분 : "+gc.get(GregorianCalendar.MINUTE));
		System.out.println("달 : "+gc.get(GregorianCalendar.MONTH+1));
		System.out.println("초 : "+gc.get(GregorianCalendar.SECOND));
		System.out.println("년 : "+gc.get(GregorianCalendar.YEAR));
		
		gc.set(2020,4,27); //2020 05 27
		System.out.println(gc.getTime());
		
		// 윤년이란 ? 년도가 4의 배수이면서 100의 배수가 아니거나
		// 400의 배수가 되는 해가 윤년
		
		//1)그해의 연도가 4의 배수가 아니면 평년으로 2월은 28일만 있다.
		//2)만약 연도가 4의 배수면서 100의 배수가 아니면 윤일을 도입한다.(2/29)
		//3)만약 연도가 100의 배수이면서 400의 배수가 아닐 때 이 해는 평년으로 생각한다.
		//4)만약 연도가 400의 배수면 윤일(2/29)를 도입한다.
		
		//2)의 예
		//2008년 (윤년,366일)
		
		//3)의 예
		//2300년 (평년,365일)
		
		//4)의 예
		//2400년 (윤년, 366일)
		
		
		
	}

}
