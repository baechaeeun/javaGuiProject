package com.kh.chap03_stringTokenizer.run;

import java.util.StringTokenizer;

public class Run {

	public static void main(String[] args) {
		
		/* 
		 * - StringTokenizer
		 * 	: String(문자열)을 어떤 특수 기호를 기준으로 Token(구분자로 파싱한 문자열) 단위로 나눠서 처리할 때 쓰임
		 * 		(split 메소드와 유사하나 split 메소드를 쓰면 String 배열로 처리,
		 * 		StringTokenizer는 자체 클래스 객체로 저장)
		 */
		
		String str=" 환불원정대,이효리,제시,화사,엄정화";
		StringTokenizer st=new StringTokenizer(str,",");
		System.out.println(st.countTokens()); //토큰개수리턴
		
		int i=0;
		while(st.hasMoreTokens()) { //커서 다음에 토큰이 있는지 확인한다.
			String whstr = st.nextToken();//문자열을 하나씩 빼온다
			System.out.println(whstr);
			System.out.println(i++);
		
		}
		
	}

}
