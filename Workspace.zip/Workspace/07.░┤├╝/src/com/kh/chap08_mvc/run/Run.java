package com.kh.chap08_mvc.run;

import com.kh.chap08_mvc.view.ProductMenu;

public class Run {

	public static void main(String[] args) {

		new ProductMenu().mainMenu();
		

	}

}
