package com.kh.chap08_mvc.view;

import java.util.Scanner;

import com.kh.chap08_mvc.controller.ProductController;

public class ProductMenu {
/* MVC 패턴 중 View 패키지 : 사용자가 보게 될 화면을 담당하는 부분
 * Scanner, print 구문
 */
	
	private Scanner sc=new Scanner(System.in); // 입력하기 위한 Scanner 객체를 전역변수로 미리 생성해놓기
	private ProductController pc=new ProductController(); 
	//사용자가 키보드로 값을 입력하고 어떤 기능을 요청할 경우에 이 해당 클래스에서
	//처리하는 것이 아니라 controller 에서 처리하도록 코딩
	// controller의 메소드를 호출할 것이기 때문에 미리 생성
	
	//1. 프로그램 시작과 동시에 실행될 메인 메뉴
	public void mainMenu() {
		System.out.println("제품명 : ");
		String pName = sc.nextLine();
		
		System.out.println("브랜드명 : ");
		String pBrand=sc.nextLine();
		
		System.out.println("가격 : ");
		int pPrice=sc.nextInt();
		
		
		pc.insertProduct(pName,pBrand,pPrice);
		
		int i=0;
		while(true) {
			System.out.println("=====메인메뉴=====");
			System.out.println("1. 제품 정보 조회");
			System.out.println("2. 제품 정보 수정");
			System.out.println("3. 종류하기");
			
			i++;
			
			int num=sc.nextInt();
			sc.nextLine();
			
			switch (num) {
			case 1:
				System.out.println(pc.selectProduct().information());
				break;

			case 2:
				updatePrice();
				break;
			case 3:
				System.out.println("프로그램 종료합니다");
				return;
				
			default:
				System.out.println("메뉴를 다시 선택해주세요");
				break;
			}
		}
		
	}
	
	private void updatePrice() {
		System.out.println("수정 할 가격 입력 : ");
		int nPrice=sc.nextInt();
		
		pc.updatePrice(nPrice);
	}
}
