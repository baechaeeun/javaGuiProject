package com.kh.chap08_mvc.controller;

import com.kh.chap08_mvc.model.vo.Product;

public class ProductController {

	private Product pro = null;
	
	public void insertProduct(String pName, String pBrand, int pPrice) {
	
		pro=new Product(pName,pBrand,pPrice);
	}
	
	public Product selectProduct() {
		return pro;
	}

	public void updatePrice(int nPrice) {
		pro.setPrice(nPrice);
		
	}

}
