package com.kh.chap08_mvc.model.vo;
//vo : 테이블 컬럼, 데이터등을 전달하고 관리하는 value object
public class Product {

	//alt + shift + s
	private String name;
	private String brand;
	private int price;
	
	public Product () {
		
	}
	public Product(String name, String brand, int price) {
		this.name = name;
		this.brand = brand;
		this.price = price;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	
	public String information() {
		return "name = "+name+"brand = "+brand+"price: "+price;
	}
	
	
}
