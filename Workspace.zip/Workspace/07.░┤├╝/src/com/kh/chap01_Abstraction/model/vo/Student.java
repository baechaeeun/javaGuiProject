package com.kh.chap01_Abstraction.model.vo;
//vo : value object 자바빈 형태로 구현한 클래스, 계층간 데이터를 교환하기 위한 자바 빈즈

/*클래스의 구조 : 구조체 + 함수 결합
 * 
 * 
 * public class 클래스명{
 * 		//필드부
 * 
 * 		//생성자부
 * 
 *		//메소드부
 * 
 * 
 */
public class Student { //구조체
		//필드부
		//접근제한자 [예약어] 자료형 변수명
		//접근제한자 : 접근할수 있는 범위를 제한할 수 있다. (public > protected > default > private)
	
	public String name;
	public int age;
	public double height;
	public int kor;
	public int math;
	
	//생성자부
	
	//메소드부
	
}
