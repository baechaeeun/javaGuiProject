package com.kh.chap06_constructor.model.vo;

public class User {
	private String userId;
	private String userPwd;
	private String userName;
	private int age;
	private char gender;
	
	/* 생성자 : 다른 패키지나 사용하고자 하는 클래스에서 현재 클래스를 통한 객체를 생성할 때 사용하는 메소드
	 * 
	 * [접근제한자] 클래스명 ([매개변수, 매개변수, ...]){...}
	 * 접근제한자 : public (다른 클래스에서 생성하려는 목적이므로)
	 * 
	 * 생성자를 작성하는 목적
	 * 1. 객체를 생성해주기 위한 목적(대/소문자 구분)
	 * 2. 반환형이 존재하지 않는다. (메소드와 유사해서 헷갈릴 수 있음)
	 * 3. 매개변수 생성자를 명시적으로 작성하게되면 기본생성자를 JVM이 자동으로 만들어주지 않는다.
	 * 		즉, 기본 생성자를 항상 기본적으로 작성하는 습관을 길러야한다.
	 * 
	 */
	
	//기본생성자 --> public 클래스명 () {}
	
	public User () {
		//기본생성자(매개변수 없는 생성자) 단지 생성만을 목적
		//기본생성자를 생략하는 겨우 -> JVM이 자동으로 만들어 줬기 때문에 항상 객체 생성이 가능했다.
		
	}
	
	//매개변수 생성자 (사용자가 만듦) --> public 클래스명 (매개변수) {
	// this.필드변수명 = 매개변수
	//}
	public User(String userId, String userPwd, String userName) {
		this.userId=userId;
		this.userPwd = userPwd;
		this.userName=userName;
		
		//나머지 필드부분은 JVM의 초기 값으로 들어가 있을 것이다.
		
		/* this :
		 * 인스턴스 자신을 가리키는 참조 변수, 인스턴스의 주소가 저장되어 있음.
		 */
	}
	
	public User(String userId, String userPwd, String userName, int age, 
			char gender) {
		
		this(userId, userPwd,userName);
		
		/* 위와 같이 중복되는 동일한 초기화하는 내용의 생성자가 존재하는 경우
		 * this() 생성자 사용 가능
		 * 같은 크래스 내에서는 생성자에서 다른 생성자 호출이 가능
		 * 단, 반드시 첫 줄에 작성되어야 한다. (그리고 단 한번만 호출이 가능하다)
		 */
		
		this.age=age;
		this.gender=gender;
	}
	/*오버로딩 : 동일한 메소드 명을 사용하는 것
	 * 단 접근 제한자든 반환형이든 다 떠나서 매개변수의 자료형과 개수, 순서가 다르게 작성되어야 한다.
	 */
	
	public String information() {
		return "ID : "+userId+", 비밀번호 : "+userPwd+", 이름 : "+userName+", 나이 : "
				+age+", 성별 : "+gender;
	}
	
	public void setAge(int i) {
		this.age=i;
	}
	
}
