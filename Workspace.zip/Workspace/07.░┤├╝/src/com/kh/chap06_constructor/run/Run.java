package com.kh.chap06_constructor.run;

import com.kh.chap06_constructor.model.vo.User;

public class Run {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		User u1=new User();		
		System.out.println(u1.information());
		
		User u2=new User("user02", "pass02", "유재석");
		System.out.println(u2.information());
		
		User u3=new User("user02","pass02","유재석",19,'F');
		System.out.println(u3.information());
	}

}
