package com.kh.chap03_class.run;

import java.util.Scanner;

import com.kh.chap03_class.model.vo.Person;
import com.kh.chap03_class.model.vo.Product;

public class Run {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Person p=new Person();//다른패키지 -> import
		
		//값 넣기
		p.setId("user01");
		p.setPwd("pass01");
		p.setName("김희선");
		p.setAge(23);
		p.setGender('F');
		p.setPhone("010-1234-1234");
		p.setEmail("green@nate.com");
		
		System.out.println(p.information());
		
		Scanner sc=new Scanner(System.in);
		System.out.println("변경할 이름 : ");
		String name=sc.nextLine();
		
		p.setName(name);
		
		System.out.println(p.information());
		
		
		Product p1=new Product();
		p1.setName("갤럭시");
		p1.setPrice(900000);
		p1.setBrand("삼성");
		
		Product p2=new Product();
		p2.setName("아이폰");
		p2.setPrice(1000000);
		p2.setBrand("애플");
		
		System.out.println(p1.information());
		System.out.println(p2.information());
		
		//DftProduct b=new DftProduct(); default 클래스는 패키지 외부에서 접근 불가 (생성불가)
		
	}

}
