package com.kh.chap03_class.model.vo;

public class Product {

	private String pName;
	private int price;
	private String brand;
	
	public Product() {
		
	}
	
	public void setName(String pName) {
		this.pName=pName;
	}
	public String getName() {
		return pName;
	}
	public void setPrice(int price) {
		this.price=price;
	}
	public int getPrice() {
		return price;
	}
	public void setBrand(String brand) {
		this.brand=brand;
	}
	public String getBrand() {
		return brand;
	}
	public String information() {
		return pName+" "+price+" "+brand;
	}
	DftProduct a=new DftProduct();
}

class DftProduct{
	private String pName;
	
	public void setPName(String pName) {
		this.pName=pName;
	}
	
}
