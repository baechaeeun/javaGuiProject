package com.kh.chap03_class.model.vo;

import java.util.Scanner;

public class Run {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Person p=new Person();//다른패키지 -> import
		
		//값 넣기
		p.setId("user01");
		p.setPwd("pass01");
		p.setName("김희선");
		p.setAge(23);
		p.setGender('F');
		p.setPhone("010-1234-1234");
		p.setEmail("green@nate.com");
		
		System.out.println(p.information());
		
		Scanner sc=new Scanner(System.in);
		System.out.println("변경할 이름 : ");
		String name=sc.nextLine();
		
		p.setName(name);
		
		System.out.println(p.information());
		
	}

}
