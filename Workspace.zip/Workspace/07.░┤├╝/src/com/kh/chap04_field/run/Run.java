package com.kh.chap04_field.run;

import com.kh.chap04_field.model.vo.FieldTest1;

public class Run {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		FieldTest1 f1=new FieldTest1();
		
		f1.test(10);
	}

}
