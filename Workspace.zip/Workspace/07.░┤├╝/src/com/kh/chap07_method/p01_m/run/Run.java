package com.kh.chap07_method.p01_m.run;

import com.kh.chap06_constructor.model.vo.User;
import com.kh.chap07_method.p01_m.controller.NonStaticMethod;
import com.kh.chap07_method.p01_m.controller.StaticMethod;

public class Run {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		NonStaticMethod test=new NonStaticMethod();
		
		test.method1();
		
		String str=test.method2();
		System.out.println("str : "+str);
		
		test.method3(10,20); //반드시 전달 값은 매개변수의 타입과 순서, 개수 일치하는 값을 넘겨줘야 함

		int result=test.method4(3, 5);
		
		System.out.println("result : "+result);
		
		User u1=new User("user01","pass01","홍길동");
		System.out.println(u1.information());
		
		test.method(u1);
		
		System.out.println(u1.information());
		
		
		
		// ----------------StaticMethod--------------------
		// 객체생성할필요없음
		// 이미 프로그램 시작 시 static 영역에 메소드 저장되었기 때문
		// 사용법 클래스명, 메소드명 ([전달값])
		
		StaticMethod.method1();
		System.out.println(StaticMethod.method2());
		
		StaticMethod.method3("전지현");
		System.out.println(StaticMethod.method4("윤"));
	}

}
