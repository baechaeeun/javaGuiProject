package com.kh.chap05_initBlock.model.vo;

public class Product {

	//멤버변수 == 인스턴스변수
	private String pName = "은하수"; //명시적 초기화
	private int price = 9000000;
	
	//클래스 변수
	private static String brand="생성";
	
	
	static { //static 블록으로 프로그램 시작 시 단 한번만 초기화, 클래스 초기화
		//pName="오로라"; 인스턴스 변수는 static 블럭에서 초기화 못함
		
		brand = "사과";
	}
	
	
	{ //인스턴스 블록 - 인스턴스 변수를 초기화 시키는 블럭으로 객체 생성시 마다 초기화
		//생성자에서 공통적으로 수행되는 작업에 사용되며 생성될 때 마다 생성자보다 먼저 실행된다.
		pName="오로라";
		price=100;
		
		brand="오렌지";
		//인스턴스 블럭에서는 static 필드도 초기화 가능
		//하지만 static 초기화 블럭은 프로그램 시작 시에 초기화를 하기 때문에
		//객체 생성 이후 값을 초기화 하는 인스턴스 초기화 블럭 값으로 덮어쓰게 된다.
	}
	
	
	
	public Product() { //생성자
	}
	
	
	public String getpName() {
		return pName;
	}
	public int getPrice() {
		return price;
	}
	public void setpName(String pName) {
		this.pName=pName;
	}
	public void setPrice(int price) {
		this.price=price;
	}
	public static void setBrand(String brand) {
		Product.brand=brand;
	}
	public static String getBrand() {
		return brand;
	}
	
	public String information() {
		return "Product pName : "+pName+", price : "+price+", brand : "+brand;
	}
}
