package com.kh.chap05_initBlock.run;

import com.kh.chap05_initBlock.model.vo.Product;

public class Run {

	public static void main(String[] args) {
		Product p = new Product();
		
		System.out.println(p.information());
		
		// 순서대로 해보자
		// 1. JVM이 정한 기본 값으로 객체 생성됨
		// 2. 명시적 초기화
		// 3. 클래스 
		// 4. 
		
		/* 클래스 변수의 초기화 순서
		 * JVM이 정한 기본 값 -> 명시적 초기값 -> 초기화 블록
		 * 
		 * 인스턴스 변수의 초기화 순서
		 * JVM이 정한 기본 값 -> 명시적 초기값 -> 초기화 블록  -> 매개변수가 있는 생성자
		 */

	}

}
