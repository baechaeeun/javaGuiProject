package com.kh.dimension;

import java.util.Scanner;

public class DimensionArray {

	//이차원 배열 : 일차원 배열 여러개를 하나로 묶은것이 2차원배열
	
	public void method1() {
		/*
		 * 1. 이차원 배열 선언
		 * 	  자료형 배열명[][];
		 *   자료형 [] 배열명[];
		 *   자료형[][] 배열명;
		 *   
		 */
		
		int arr1[][];
		int[] arr2[];
		int[][] arr;
		
		/*2. 이차원 배열 할당
		 * 
		 * 배열명 = new 자료형[행크기][열크기]
		 * 
		 */
		arr=new int[3][5];
		
		//할당을 하게 되면 heap 영역에 해당 크기 만큼의 공간 할당
		
		//행의 길이를 알려고 한다면
		System.out.println("행의 길이 : "+arr.length);
		
		//각 행별 열의 길이를 알려고 한다면
		System.out.println("열의 길이 : "+arr[0].length);
		System.out.println("열의 길이 : "+arr[1].length);
		System.out.println("열의 길이 : "+arr[2].length);
		
		
		//*****
		//*****
		//*****
		
		
		//바깥쪽 for문 --> 행의 갯수만큼 반복
		
		for(int i=0;i<3;i++) {
			for(int j=0;j<5;j++) {
				System.out.print("*");
			}
			System.out.println();
		}
		
		for(int i=0;i<arr.length;i++) {
			for(int j=0;j< arr[i].length;j++) {
				System.out.print(arr[i][j]);
			}
			System.out.println();
		}
	}
	public void method2() {
		int [][] arr=new int [3][5];
		
		//1 2 3 4 5
		//6 7 8 9 10
		//11 12 13 14 15
		
		for(int i=0;i<3;i++) {
			for(int j=0;j<5;j++) {
				arr[i][j]=j+1+5*i;
				System.out.print(arr[i][j]+" ");
			}
			System.out.println();
		}
	}
	
	public void method3() {
		//이차원 배열의 할당과 동시에 초기화
		
		int arr[][]= {{1,2,3,4,5},{6,7,8,9,10},{11,12,13,14,15}};
		
		for(int i=0;i<3;i++) {
			for(int j=0;j<5;j++) {
				System.out.print(arr[i][j]+" ");
			}
			System.out.println();
		}
	}
	
	public void method4() {
		//가변 배열
		//행의 크기는 정해졌으나 각 행에 대한 열의 갯수가 정해지지 않은 상태
		//자료형이 같은 1차원 배열 여러개를 하나로 묶은 것이 2차원 배열
		//이 묶여있는 1차원 배열의 크기가 꼭 같지 않아도 됨
		
		int [][] arr=new int[3][];
		
		arr[0] = new int[2]; //0행은 2열
		arr[1] = new int[1]; //1행은 1열
		arr[2] = new int[3]; //2행은 3열
		
		//각 행에 또 다른 배열을 참조할 수 있도록 한다.
		
		for(int i=0; i<arr.length;i++) {
			for(int j=0;j<arr[i].length;j++) {
				System.out.print(arr[i][j]+" ");
			}
			System.out.println();
		}
		
		arr[0][0]=1;
		
		
	}
	
	public void method5() {
		//가변배열의 할당과 동시에 초기화
		
		int[][] arr = { { 1, 2 }, { 3 }, { 4, 5, 6 } };

		for (int i = 0; i < arr.length; i++) {
			for (int j = 0; j < arr.length; j++) {
				System.out.print(arr[i][j] + " ");
			}
			System.out.println();
		}

	}
	
	public void method6() {
		//Scanner 를 이용해서 국어점수와 영어 점수를 3번 찍어서 각각 평균을 구하라
		//double[][] arr=new double[2][4]; 합 제일 마지막 열에 담기
		
		Scanner sc=new Scanner(System.in);
		
		double[][] arr=new double[2][4];
		
		for(int i=0;i<arr.length;i++) {
			for(int j=0;j<arr[i].length-1;j++) {
				if(i==0)
					System.out.print("국어 점수를 입력하세요 : ");
				else
					System.out.print("영어 점수를 입력하세요 : ");
				arr[i][j]=sc.nextDouble();
				sc.nextLine();
				arr[i][3]+=arr[i][j];
			}
		}
		
		System.out.println("국어 점수 : "+arr[0][3]/3);
		System.out.println("영어 점수 : "+arr[1][3]/3);
	}
	
	public void method7() {
		//1부터 10사이의 랜덤값을 3행 3열에 넣으려고 하는데 중복을 제거해서 넣자.
		
		int [][] arr1=new int[3][3];
		int [] arr2=new int[9];
		
		for(int i=0;i<arr2.length;i++) {
			arr2[i]=(int)(Math.random()*10+1);
			for(int j=0;j<i;j++) {
				if(arr2[i]==arr2[j]) {
					i--;
					break;
				}
			}
		}
		
		int value=0;
		for(int i=0;i<arr1.length;i++) {
			for(int j=0;j<arr1[i].length;j++) {
				arr1[i][j]=arr2[value];
				value++;
			}
		}
		
		for(int i=0;i<arr1.length;i++) {
			for(int j=0;j<arr1[i].length;j++) {
				System.out.print(arr1[i][j]+" ");
			}
			System.out.println();
		}
	}
	
	public void bingo() {
		//빙고 판이 5행 5열,, 일차원 배열 25칸에 난수를 발생시켜서 중복값 없이 넣어준다.
		Scanner sc=new Scanner(System.in);
		
		int arr[]=new int[25];
		
		for(int i=0;i<arr.length;i++) {
			arr[i]=(int)(Math.random()*25+1);
			
			for(int j=0;j<i;j++) {
				if(arr[i]==arr[j]) {
					i--;
					break;
				}
			}
		}
		
		int value=0;
		int newArr[][]=new int[5][5];
		for (int i = 0; i < newArr.length; i++) {
			for (int j = 0; j < newArr[i].length; j++) {
				newArr[i][j]=arr[value++];
				System.out.print(newArr[i][j]+" ");
			}
			System.out.println();
		}
		
		System.out.println("==========빙고게임시작==========");
		
		int count=0;
		while(true) {
			System.out.print("정수를 입력하시오 : ");
			int num=sc.nextInt();
			sc.nextLine();
			
			count++;
			for(int i=0;i<5;i++) {
				for(int j=0;j<5;j++) {
					if(newArr[i][j]==num)
						newArr[i][j]=0;
					System.out.println(newArr[i][j]+" ");
				}
				System.out.println();
			}
			
			System.out.print("게임을 끝내시겠습니까(Y/N) : ");
			
			
		}
	}
}
