package com.kh.array.practice;
import java.util.*;

public class ArrayPractice {
	public void practice1() {
		Scanner sc=new Scanner(System.in);
		
		int [] arr=new int[10];
		
		for(int i=0;i<10;i++) {
			arr[i]=i+1;
			System.out.print(arr[i]+" ");
		}
		
		
	}
	public void practice2() {
		Scanner sc=new Scanner(System.in);
		
		int [] arr=new int[10];
		
		for(int i=0;i<10;i++) {
			arr[i]=10-i;
			System.out.print(arr[i]+" ");
		}
	}
	
	public void practice3() {
		Scanner sc=new Scanner(System.in);
		System.out.print("양의 정수 : ");
		int n=sc.nextInt();
		int arr[]=new int[n];
		sc.nextLine();
		
		for(int i=0;i<n;i++) {
			arr[i]=i+1;
			System.out.print(arr[i]+ " ");
		}
	}
	
	public void practice4() {
		String arr[]=new String[5];
		
		arr[0]="사과";
		arr[1]="귤";
		arr[2]="포도";
		arr[3]="복숭아";
		arr[4]="참외";
		
		System.out.println(arr[1]);
		
	}
	
	public void practice5() {
		Scanner sc=new Scanner(System.in);
		
		System.out.print("문자열 : ");
		String arr=sc.nextLine();
		System.out.print("문자 : ");
		char ch=sc.nextLine().charAt(0);
		
		System.out.print(arr+"에 "+ch+"가 존재하는 위치(인덱스) : ");
		
		int num=0;
		for(int i=0;i<arr.length();i++) {
			if(arr.charAt(i)==ch) {
				System.out.print(i+" ");
				num++;
			}
		}
		System.out.println();
		System.out.println(ch+" 개수 : "+num);
		
	}
	
	public void practice6() {
		Scanner sc=new Scanner(System.in);
		String arr[]=new String[7];
		arr[0]="월요일";
		arr[1]="화요일";
		arr[2]="수요일";
		arr[3]="목요일";
		arr[4]="금요일";
		arr[5]="토요일";
		arr[6]="일요일";
		
		System.out.print("0~6 사이 숫자 입력 : ");
		int num=sc.nextInt();
		
		if(num<0||num>6) {
			System.out.println("잘못 입력하셨습니다.");
			return;
		}
		
		System.out.println(arr[num]);
	}
	
	public void practice7() {
		Scanner sc=new Scanner(System.in);
		
		System.out.print("정수 : ");
		int n=sc.nextInt();
		sc.nextLine();
		int arr[]=new int[n];
		
		int sum=0;
		for(int i=0;i<n;i++) {
			System.out.print("배열 "+i+"번째 인덱스에 넣을 값 : ");
			arr[i]=sc.nextInt();
			sc.nextLine();
			sum+=arr[i];
		}
		
		for(int i=0;i<n;i++) {
			System.out.print(arr[i]+ " ");
		}
		System.out.println();
		System.out.println("총 합 : "+sum);
	}
	
	public void practice8() {
		Scanner sc=new Scanner(System.in);
		
		while (true) {
			System.out.print("정수 : ");
			int n = sc.nextInt();

			if (n % 2 != 1 || n < 3) {
				System.out.println("다시 입력하세요.");
				continue;
			}
			
			int arr[]=new int[n];
			for(int i=0;i<n/2+1;i++) {
				arr[i]=i+1;
				System.out.print(arr[i]+ ", ");
			}
			for(int i=n/2+1;i<arr.length-1;i++) {
				arr[i]=arr.length-i;
				System.out.print(arr[i]+ ", ");
			}
			System.out.print(1);
			
			break;
		}
	}
	
	public void practice9() {
		Scanner sc=new Scanner(System.in);
		
		String arr[]= {"양념","뿌링클","황금올리브"};
		System.out.print("치킨 이름을 입력하세요 : ");
		String menu=sc.nextLine();
		
		boolean check=false;
		for(int i=0;i<arr.length;i++) {
			if(arr[i].equals(menu)) {
				check=true;
				System.out.println(menu+"치킨 배달 가능");
			}
		}
		
		if(!check)
			System.out.println(menu+"치킨은 없는 메뉴입니다.");
	}
	
	public void practice10() {
		int arr[]=new int[10];
		
		for(int i=0;i<10;i++) {
			arr[i]=(int)(Math.random()*10+1);
			System.out.print(arr[i]+" ");
		}
	}
	
	public void practice11() {
		int arr[]=new int[10];
		
		for(int i=0;i<10;i++) {
			arr[i]=(int)(Math.random()*10+1);
			System.out.print(arr[i]+" ");
		}
		
		int max=0;
		int min=11;
		
		for(int i=0;i<10;i++) {
			if(max<arr[i])
				max=arr[i];
			if(min>arr[i])
				min=arr[i];
		}
		
		System.out.println();
		System.out.println("최대값 : "+max);
		System.out.println("최소값 : "+min);
	}
	
	public void practice12() {
		int arr[]=new int[10];
		
		for(int i=0;i<10;i++) {
			arr[i]=(int)(Math.random()*10+1);
			for(int j=0;j<i;j++) {
				if(arr[i]==arr[j]) {
					i--;
					break;
				}
			}
		}
		for(int i=0;i<10;i++) {
			System.out.print(arr[i]+" ");
		}
	}
	
	public void practice13() {
		Scanner sc=new Scanner(System.in);
		
		System.out.print("주민등록번호(-포함) : ");
		String str=sc.nextLine();
		char [] arr=new char[str.length()];
		
		for (int i = 0; i < str.length(); i++) {
			if (i > 7) {
				arr[i] = '*';
			} else {
				arr[i] = str.charAt(i);
			}
			System.out.print(arr[i]);
		}
	}
	
	public void practice14() {
		int arr[]=new int[6];
		
		for(int i=0;i<6;i++) {
			arr[i]=(int)(Math.random()*45+1);
			for(int j=0;j<i;j++) {
				if(arr[i]==arr[j]) {
					i--;
					break;
				}
			}
		}
		
		Arrays.sort(arr);
		
		for(int i=0;i<6;i++) {
			System.out.print(arr[i]+" ");
		}
	}
}
