package com.kh.run;

import com.kh.array.A_Array;
import com.kh.array.B_ArrayCopy;
import com.kh.array.C_ArraySort;
import com.kh.array.D_Overlap;

public class Run {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		/*
		 * A_Array a=new A_Array(); a.method5();
		 */
		
		/*
		 * B_ArrayCopy b=new B_ArrayCopy(); b.method5();
		 */
		
		/*
		 * C_ArraySort c=new C_ArraySort(); c.method5();
		 */
		
		D_Overlap d=new D_Overlap();
		d.method3();
	}

}
