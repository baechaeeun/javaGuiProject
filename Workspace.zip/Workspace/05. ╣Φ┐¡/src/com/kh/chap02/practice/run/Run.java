package com.kh.chap02.practice.run;

import com.kh.chap02.practice.example.LoopPractice;

public class Run {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		LoopPractice l=new LoopPractice();
		
		l.practice12();

	}

}
