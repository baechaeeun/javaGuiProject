package com.kh.chap02.practice.example;

import java.util.Scanner;

public class LoopPractice {
	public void practice1() {
		Scanner sc=new Scanner(System.in);
		System.out.print("1이상의 숫자를 입력하세요 : ");
		int num=sc.nextInt();
		sc.nextLine();
		
		if(num<1)
			System.out.println("잘못 입력하셨습니다.");
		
		else {
			for (int i = 1; i <= num; i++) {
				System.out.print(i + " ");
			}
		}
	}
	
	public void practice2() {
		Scanner sc=new Scanner(System.in);
	
		
		while (true) {
			System.out.print("1이상의 숫자를 입력하세요 : ");
			int num=sc.nextInt();
			sc.nextLine();
			
			if (num < 1) {
				System.out.println("잘못 입력하셨습니다. 다시 입력해주세요");
				continue;
			}

			else {
				for (int i = 1; i <= num; i++) {
					System.out.print(i + " ");
				}
				break;
			}
		}
		
	}
	
	public void practice3() {
		Scanner sc=new Scanner(System.in);
		System.out.print("1이상의 숫자를 입력하세요 : ");
		int num=sc.nextInt();
		sc.nextLine();
		
		if(num<1)
			System.out.println("잘못 입력하셨습니다.");
		
		else {
			for (int i = num; i >= 1; i--) {
				System.out.print(i + " ");
			}
		}
	}
	public void practice4() {
		Scanner sc=new Scanner(System.in);
		

		while (true) {
			System.out.print("1이상의 숫자를 입력하세요 : ");
			int num=sc.nextInt();
			sc.nextLine();
			
			if (num < 1) {
				System.out.println("잘못 입력하셨습니다. 다시 입력해주세요");
				continue;
			}

			else {
				for (int i = num; i >= 1; i--) {
					System.out.print(i + " ");
				}
				break;
			}
		}
	}
	
	public void practice5() {
		Scanner sc = new Scanner(System.in);

		System.out.print("정수를 하나 입력하세요 : ");
		int num = sc.nextInt();

		int sum = 0;

		for (int i = 1; i <= num; i++) {
			sum += i;

			if (i != num) {
				System.out.print(i + " + ");
			} else {
				System.out.println(i + " = " + sum);
			}

		}
	}
	
	public void practice6() {
		Scanner sc=new Scanner(System.in);
		
		System.out.print("첫 번째 숫자 : ");
		int num1= sc.nextInt();
		sc.nextLine();
		if(num1<1) {
			System.out.println("1이상의 숫자만을 입력해주세요");
			return;
		}
		
		System.out.print("두 번째 숫자 : ");
		int num2= sc.nextInt();
		sc.nextLine();
		if(num2<1) {
			System.out.println("1이상의 숫자만을 입력해주세요");
			return;
		}
		
		int tmp;
		if(num1>num2) {
			tmp=num1;
			num1=num2;
			num2=tmp;
		}
		
		for(int i=num1;i<=num2;i++) {
			System.out.print(i+" ");
		}
	}
	
	public void practice7() {
		Scanner sc=new Scanner(System.in);
		
		while (true) {

			System.out.print("첫 번째 숫자 : ");
			int num1 = sc.nextInt();
			sc.nextLine();
			if (num1 < 1) {
				System.out.println("1 이상의 숫자만을 입력해주세요");
				continue;
			}

			System.out.print("두 번째 숫자 : ");
			int num2 = sc.nextInt();
			sc.nextLine();
			if (num2 < 1) {
				System.out.println("1 이상의 숫자만을 입력해주세요");
				continue;
			}

			int tmp;
			if (num1 > num2) {
				tmp = num1;
				num1 = num2;
				num2 = tmp;
			}

			for (int i = num1; i <= num2; i++) {
				System.out.print(i + " ");
			}

			break;
		}
	}
	
	public void practice8 () {
		
		Scanner sc=new Scanner(System.in);
		
		System.out.print("숫자 : ");
		int dan=sc.nextInt();
		sc.nextLine();
		
		System.out.println("===== "+dan+" =====");
		for(int i=1;i<=9;i++) {
			System.out.println(dan+" * "+i+" = "+dan*i);
		}
		
	}
	
	public void practice9() {
		Scanner sc=new Scanner(System.in);
		
		System.out.print("숫자 : ");
		int dan=sc.nextInt();
		sc.nextLine();
		
		if(dan<2||dan>9) {
			System.out.println("2~9 사이의 숫자만 입력해주세요");
			return;
		}
		
		for(int i=dan;i<=9;i++) {
			System.out.println("===== "+i+"단 =====");
			for(int j=1;j<=9;j++) {
				System.out.println(dan+" * "+i+" = "+dan*i);
			}
		}
	}
	
	public void practice10() {
		Scanner sc=new Scanner(System.in);
		
		while (true) {
			System.out.print("숫자 : ");
			int dan = sc.nextInt();
			sc.nextLine();

			if (dan < 2 || dan > 9) {
				System.out.println("2~9 사이의 숫자만 입력해주세요");
				continue;
			}

			for (int i = dan; i <= 9; i++) {
				System.out.println("===== " + i + "단 =====");
				for (int j = 1; j <= 9; j++) {
					System.out.println(dan + " * " + i + " = " + dan * i);
				}
			}
			break;
		}
		
	}
	public void practice11() {
		Scanner sc=new Scanner(System.in);
		
		System.out.print("시작 숫자 : ");
		int start=sc.nextInt();
		sc.nextLine();
		System.out.print("공차 : ");
		int gap=sc.nextInt();
		sc.nextLine();
		
		int sum=start;
		for(int i=1;i<=10;i++) {
			System.out.print(num+" ");
			sum+=gap;
		}
	}
	
	public void practice12() {
		Scanner sc = new Scanner(System.in);

		while (true) {
			System.out.print("연산자(+, -, *, /, %) : ");
			char op;
			String str=sc.nextLine();
			if(str.equals("exit")) {
				System.out.println("프로그램을 종료합니다.");
				break;
			}
			else {
				op = str.charAt(0);
				if(op!='+'&&op!='-'&&op!='*'&&op!='/'&&op!='%') {
					System.out.println("없는 연산자입니다. 다시 입력해주세요");
					continue;
				}
			}
			
			System.out.print("정수1 : ");
			int num1 = sc.nextInt();
			sc.nextLine();
			
			System.out.print("정수2 : ");
			int num2 = sc.nextInt();
			sc.nextLine();
			
			if(op=='/'&&num2==0) {
				System.out.println("0으로 나눌 수 없습니다. 다시 입력해주세요.");
				continue;
			}

			switch (op) {
			case '+':
				System.out.println(num1 + " + " + num2 + " = " + (num1 + num2));
				break;
			case '-':
				System.out.println(num1 + " - " + num2 + " = " + (num1 - num2));
				break;
			case '*':
				System.out.println(num1 + " * " + num2 + " = " + (num1 * num2));
				break;
			case '/':
				System.out.println(num1 + " / " + num2 + " = " + (num1 / num2));
				break;
			case '%':
				System.out.println(num1 + " % " + num2 + " = " + (num1 % num2));
				break;
			}

			break;

		}
	}

}
