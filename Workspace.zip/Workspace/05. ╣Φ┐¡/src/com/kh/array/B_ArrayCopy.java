package com.kh.array;

import java.util.Arrays;

public class B_ArrayCopy {
	/* 배열의 복사
	 * -얕은 복사 : 배열의 주소만 복사
	 * -깊은 복사 : 동일한 새로운 배열을 하나 생성해서 실제 내부 값들을 복사
	 */
	
	public void method1() {
		int [] origin= {1,2,3,4,5};
		
		System.out.println("원본 배열 출력");
		
		for(int i=0;i<origin.length;i++) {
			System.out.println(origin[i]+" ");
		}
		
		int [] copy=origin;
		//복사본출력
		System.out.println();
		System.out.println("복사본 배열 출력");
		for(int i=0;i<copy.length;i++) {
			System.out.println(copy[i]+" ");
		}
		
		copy[2]=99;
		
		System.out.println("---복사본 배열값 변경 후---");
		
		System.out.println("원본 배열 출력");
		
		for(int i=0;i<origin.length;i++) {
			System.out.println(origin[i]+" ");
		}
		
		//복사본출력
		System.out.println();
		System.out.println("복사본 배열 출력");
		for(int i=0;i<copy.length;i++) {
			System.out.println(copy[i]+" ");
		}
		
		System.out.println("origin의 주소값 "+origin.hashCode());
		System.out.println("copy의 주소값 "+origin.hashCode());
		
		
	}
	
	public void method2() {
		//1. for문 방법
		//새로운 배열을 생성해서 반복문을 통해 실제 값을 집어 넣는 방법.
		
		int [] origin = {1,2,3,4,5};
		
		int [] copy = new int[5];
		
		for(int i = 0;i<origin.length;i++) {//반복문을 통해서 origin에 있는 값들을 copy배열에 대입
			copy[i]=origin[i];
		}
		
		System.out.println("복사본 배열 확인");
		
		for(int i=0;i<copy.length;i++) {
			System.out.println(copy[i]);
		}
		
		copy[2]=99;
	}
	
	public void method3() {
		//2. 새로운 배열을 생성하고 System 클래스에서의 arraycopy() 메소드를 이용한 복사
		int[] origin = {1,2,3,4,5};
		int[] copy=new int [10]; //10개 공간 생성
		
		//System.arraycopy(원본배열명, 복사시작할 인덱스, 복사본 배열명, 복사본 배열의 복사될 시작 위치, 복사 길이)
		System.arraycopy(origin, 0, copy, 2, origin.length);
		/* origin 배열을 copy 배열에 복사하는데 이때
		 * origin 배열의 0번 인덱스부터 마지막에 넣은 길이만큼 copy 배열 2번 인덱스부터 채우겠다.
		 */
		
		System.out.println();
		
		//확인
		System.out.println("복사본배열 출력");
		for(int i = 0; i<copy.length;i++) {
			System.out.println(copy[i]+" ");
		}
		
		System.out.println();
		
		System.out.println("origin길이"+origin.length);
		System.out.println("copy길이"+copy.length);
		
		System.out.println("originhashcode"+origin.hashCode());
		System.out.println("copyhashcode"+copy.hashCode());
		
		
		
	}
	
	public void method4() {
		//3. Array 클래스에서 제공하는 copyOf() 메소드를 사용
		//* Arrays 클래스는 배열이용할때 유용한 메소드를 모아놓은 클래스
		
		int[] origin= {1,2,3,4,5};
		
		//복사본 배열 = Arrays.copyOf(원본 배열명, 복사할 길이)
		int [] copy = Arrays.copyOf(origin, 4);
		
		
		System.out.println("원본 배열 출력");
		for(int i=0;i < origin.length;i++) {
			System.out.println(origin[i]+" ");
		}
		
		System.out.println("복사본 배열 출력");
		for(int i=0;i < copy.length;i++) {
			System.out.println(origin[i]+" ");
		}
		
		System.out.println();
		
		System.out.println("origin길이"+origin.length);
		System.out.println("copy길이"+copy.length);
		
		System.out.println("originhashcode"+origin.hashCode());
		System.out.println("copyhashcode"+copy.hashCode());
	}
	
	/* System.arraycopy() 메소드는 내가 복사하고자 할때 인덱스와 개수를 지정하고 싶을때 사용, 복사본 배열의 크기가 그대로 유지
	 * copy = Arrays.copyOf() 메소드는 내가 복사하고자 하는 것을 복사하고 크기도 다시 지정하고 싶을 떄 사용
	 */
	
	public void method5() {
		//4. clone() 메소드를 이용한 복사, 시작 인덱스 지정안됨, 원본 배열 통째로 복사해 새로운 배열에 할당
		
		int [] origin = {1,2,3,4,5};
		int [] copy = origin.clone();
		
		System.out.println("복사본 배열 출력");
		for(int i=0;i < copy.length;i++) {
			System.out.println(origin[i]+" ");
		}
		
		System.out.println();
		
		System.out.println("origin길이"+origin.length);
		System.out.println("copy길이"+copy.length);
		
		System.out.println("originhashcode"+origin.hashCode());
		System.out.println("copyhashcode"+copy.hashCode());
	}
	
}
