package com.kh.array;

import java.util.Arrays;
import java.util.Collections;
import java.util.Scanner;

public class D_Overlap {
	public void method1() {
		int []arr=new int[ 5];
		
		Scanner sc=new Scanner(System.in);
		
		for (int i = 0; i < arr.length; i++) {
			System.out.println(i + "번째 정수값 : ");
			arr[i] = sc.nextInt();
			for (int j = 0; j < i; j++) {
				System.out.println(i + "  " + j);
				if (arr[i] == arr[j]) {
					System.out.println("중복 값이 존재합니다.");
					i--;
					break;
				}
			}
		}
		
		for(int i=0;i<arr.length;i++) {
			System.out.println(arr[i]+" ");
		}
	}
	
	public void method2() {
		int[] arr = new int[5];
		Scanner sc = new Scanner(System.in);
		// 임의의 1부터 10사이의 난수를 발생시켜서 중복 없이 출력

		for (int i = 0; i < arr.length; i++) {
			// System.out.println(i + "번째 정수값 : ");
			arr[i] = (int) (Math.random() * 10 + 1);
			System.out.println(i + "번째 정수값 : " + arr[i]);
			for (int j = 0; j < i; j++) {
				// System.out.println(i + " " + j);
				if (arr[i] == arr[j]) {
					System.out.println("중복 값이 존재합니다.");
					i--;
					break;
				}
			}
		}

		for (int i = 0; i < arr.length; i++) {
			System.out.println(arr[i] + " ");
		}

	}
	
	public void method3() {
		//임의의 1부터 10사이의 난수를 발생시켜서 중복 제거하고 오름차순
		int[] arr = new int[5];
		Scanner sc = new Scanner(System.in);

		for (int i = 0; i < arr.length; i++) {
			// System.out.println(i + "번째 정수값 : ");
			arr[i] = (int) (Math.random() * 10 + 1);
			System.out.println(i + "번째 정수값 : " + arr[i]);
			for (int j = 0; j < i; j++) {
				// System.out.println(i + " " + j);
				if (arr[i] == arr[j]) {
					System.out.println("중복 값이 존재합니다.");
					i--;
					break;
				}
			}
		}
		Arrays.sort(arr);
		System.out.println(Arrays.toString(arr));
		
		/*
		 * for(int i=0;i<arr.length;i++) { //2. 비교 대상을 정하는 for 문 for(int j=0;j<i;j++) {
		 * // 이제 비교를 통해서 오름차순 정렬 // 비교 주체가 비교 대상보다 작을 경우 값을 교환
		 * 
		 * if(arr[i]>arr[j]) { System.out.println("== 교환 발생 ==");
		 * 
		 * int temp=arr[i]; arr[i]=arr[j]; arr[j]=temp; } } }
		 */
		
		System.out.println(Arrays.toString(arr));
		
	}
}
