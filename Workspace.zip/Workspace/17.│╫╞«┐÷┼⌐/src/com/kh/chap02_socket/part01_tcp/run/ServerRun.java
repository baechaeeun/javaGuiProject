package com.kh.chap02_socket.part01_tcp.run;

import com.kh.chap02_socket.part01_tcp.sample.TCPServer;

public class ServerRun {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TCPServer ts=new TCPServer();
		ts.serverStart();
		

	}

}
