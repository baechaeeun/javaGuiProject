package com.kh.chap02_socket.part02_chat.thread;

import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.Scanner;

public class Sender implements Runnable{

	private String name; // 데이터를 보내는 사용자명
	private DataOutputStream out; //데이터 출력용 스트림
	
	private Scanner sc;
	
	
	//Sender 객체 생성 시 매개변수로 socket과 name을 받아온다.
	//server 에서 생성 : 요청을 수락한 Client의 소켓, 서버명을 받아올 것이다.
	//client 에서 생성 : 연결된 server의 소켓, 클라이언트 명을 받아올 것이다.
	public Sender(Socket socket,String name) {
		this.name = name;
		
		try {
			out = new DataOutputStream(socket.getOutputStream());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	

	//스레드 처리 작업
	//채팅을 한번에 입력할 것이 아니기 때문에 무한 루프를 이용해서 sc로 데이터를 입력받고
	//입력받은 내용을 연결된 출력 스트림을 통해서 출력한다.

	@Override
	public void run() {
		// TODO Auto-generated method stub
		sc = new Scanner(System.in);
		
		while(true) {
			try {
				out.writeUTF(name+">"+sc.nextLine());
			} catch (IOException e) {
				break;//서버나 클라이언트 중 한쪽이 먼저 종료하면 에러 발생해서 종료 시킴
			}
		}
	}

}
