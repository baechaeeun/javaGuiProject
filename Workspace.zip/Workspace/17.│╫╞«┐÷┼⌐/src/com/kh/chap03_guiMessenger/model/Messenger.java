package com.kh.chap03_guiMessenger.model;

import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;

import com.kh.chap03_guiMessenger.view.MyFrame;

public class Messenger {

	private MyFrame f;
	private DatagramSocket socket;
	private InetAddress address=null;
	private final int myPort;
	private final int otherPort;
	
	public Messenger(int myPort,int otherPort) {
		this.myPort = myPort;
		this.otherPort=otherPort;
		
		try {
			address=InetAddress.getByName("127.0.0.1");
			//IPv4에서의 ip루프백 주소는 127.0.0.1, 자기자신을 연결할 때 사용 (로컬컴퓨터를 원격컴퓨터인것처럼 
			//통신할 수 있어 테스트 목적으로 사용
			
			socket = new DatagramSocket(myPort);
			f=new MyFrame(address,otherPort,socket);
			
			
			
		} catch (UnknownHostException | SocketException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public MyFrame getMyFrame() {
		return f;
	}
	
}
