package com.kh.chap03_guiMessenger.view;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

import javax.swing.JFrame;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class MyFrame extends JFrame implements ActionListener{
	
	private DatagramSocket socket;
	private DatagramPacket packet;
	private JTextField textField;
	private JTextArea textArea;
	private InetAddress address;
	private int otherPort;
	
	public MyFrame(InetAddress address, int otherPort, DatagramSocket socket) {
		this.address=address;
		this.otherPort=otherPort;
		this.socket=socket;
		
		textField = new JTextField(30);
		textField.addActionListener(this);
		
		textArea = new JTextArea(10,30);
		textArea.setEditable(false); //수정안되게
		
		this.add(textField,BorderLayout.PAGE_END);
		this.add(textArea,BorderLayout.CENTER);
		
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setVisible(true);
		this.pack();
		
		
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		String str = textField.getText();
		byte[] buffer = str.getBytes();//UDP방식은 byte[] 데이터로 통신
		DatagramPacket sendPacket = new DatagramPacket(buffer,buffer.length,address,otherPort);
		//순서 : 보낼 바이트 배열, 그 배열의 얼마만큼의 데이터, 상대방 아이피, 상대방 포트넘버
		
		try {
			socket.send(sendPacket);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		textArea.append("SENT : "+str+"\n");//보낸 내용을 textArea에 출력
		textField.selectAll(); //다음번에 기존 내용 안지워도 되게 자동 선택되게 하기
		textArea.setCaretPosition(textArea.getDocument().getLength());
	}
	
	public void process() {
		while(true) {
			byte[] buf = new byte[256];
			packet = new DatagramPacket(buf,buf.length);
			
			try {
				socket.receive(packet); //inputStream 같은 것!
				textArea.append("RECIEVE : "+new String(buf)+"\n");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
	}
	
	
	

}
