package com.kh.chap01_inet.sample;

import java.net.InetAddress;
import java.net.UnknownHostException;

public class InetSample {

	public void ipSample() {
		try {
			InetAddress localIP=InetAddress.getLocalHost();
			
			System.out.println("내 pc 명 : "+localIP.getHostName()); //호스트의 이름
			System.out.println("내 IP : "+localIP.getHostAddress()); //호스트의 ip 주소 반환
			
			
			System.out.println();
			
			//도메인명을 통해 ip 주소 반환
			InetAddress neverIp=InetAddress.getByName("www.naver.com");
			
			System.out.println("네이버 서버 명 : "+neverIp.getHostName()); //호스트의 이름
			System.out.println("네이버  서버: "+neverIp.getHostAddress()); //호스트의 ip 주소반환
		
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		/*
		 * 1. 네트워크란?
		 * net+work의 합성어 : net(그물)+work(일)
		 * 단일로 쓰여진 매체를 통신이라는 매개체를 통하여 서로 연결되어 있는 환경
		 * 
		 * 2. 네트워킹이란?
		 * 두 대 이상의 컴퓨터를 케이블로 연결하여 네트워크를 구성하는 작업
		 * 
		 * 3. 네트워킹의 목적
		 * 여러개의 통신기기등을 서로 연결하여 데이터를 손쉽게 주고 주고 받거나
		 * 도는 자원(프린터 등)등을 공유하기 위함
		 * 추가적으로 빠른 데이터 교환 목적도 있음
		 * 
		 * 4. 네트워크에서 필요한 개념
		 * 서버(Server) : 서비스를 제공하는 컴퓨터
		 * 클라이언트(Client) : 서비스를 사용하는(제공받는) 컴퓨터
		 * 
		 * 5. 네트워크 통신흐름 (소켓통신)
		 * (서버 -> 클라이언트로 갈때)
		 * 서버 -> 소켓 -> 포트 -> Ip -> 네트워크 -> Ip -> 포트 -> 소켓 -> 클라이언트의 프로세스
		 * 
		 */
	}

}
