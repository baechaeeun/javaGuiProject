package com.kh.chap01_inet.run;

import com.kh.chap01_inet.sample.InetSample;

public class Run {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new InetSample().ipSample();

	}

}
