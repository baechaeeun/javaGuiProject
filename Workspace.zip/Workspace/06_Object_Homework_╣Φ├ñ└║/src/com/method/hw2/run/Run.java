package com.method.hw2.run;

import com.method.hw2.controller.NonStaticSample;

public class Run {

	public static void main(String[] args) {
		NonStaticSample n=new NonStaticSample();
		
		int arr[]=n.intArrayAllocation(5);
		n.display(arr);
		n.sortDescending(arr);
		n.sortAscending(arr);
		System.out.println(n.countChar("apple", 'p'));
		System.out.println(n.totalValue(7, 13));
		System.out.println(n.pCharAt("programming", 3));
		System.out.println(n.pConcat("JAVA", "programming"));

	}

}
