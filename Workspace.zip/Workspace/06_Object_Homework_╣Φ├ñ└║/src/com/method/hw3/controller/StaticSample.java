package com.method.hw3.controller;

public class StaticSample {
	private static String value;
	
	public StaticSample() {
	}

	public StaticSample(String value) {
		this.value = value;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		StaticSample.value = value;
	}
	
	public static void toUpper() {
		char arr[]=value.toCharArray();
		String tmp="";
		
		for(int i=0;i<arr.length;i++) {
			if(!(arr[i]>=65&&arr[i]<=90))
				arr[i]+=32;
			tmp+=arr[i];
		}
		value=tmp;
	}
	
	public static void setChar(int index,char c) {
		value=value.substring(0, index)+c+value.substring(index+1, value.length());
	}
	
	public static int valueLength() {
		return value.length();
	}
	
	public static String valueConcat(String str) {
		return str+value;
	}
	
	

}
