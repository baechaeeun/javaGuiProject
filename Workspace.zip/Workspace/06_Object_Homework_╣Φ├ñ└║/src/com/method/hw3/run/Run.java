package com.method.hw3.run;

import com.method.hw3.controller.StaticSample;

public class Run {

	public static void main(String[] args) {
		StaticSample s=new StaticSample("JAVA");
		
		System.out.println(s.getValue());
		s.toUpper();
		System.out.println(s.getValue());
		System.out.println(s.valueLength());
		System.out.println(s.valueConcat("PROGRAMMING"));
		s.setChar(0, 'C');
		System.out.println(s.getValue());
		

	}

}
