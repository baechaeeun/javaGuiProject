package com.method.hw1.controller;

import java.util.Arrays;

public class NonStaticSample {
	
	
	public void printLottoNumbers() {
		int arr[]=new int[6];
		
		for(int i=0;i<arr.length;i++) {
			arr[i]=(int)(Math.random()*45+1);
			for(int j=0;j<i;j++) {
				if(arr[i]==arr[j]) {
					i--;
					break;
				}
			}
		}
		
		Arrays.sort(arr);
		
		System.out.print("1. 랜덤 값 : ");
		for(int i=0;i<arr.length;i++) {
			System.out.print(arr[i]+" ");
		}
		System.out.println();
	}
	public void outputChar(int num, char c) {
		System.out.print(c+"문자 "+num+"개 출력 : ");
		for(int i=0;i<num;i++) {
			System.out.print(c+" ");
		}
		System.out.println();
	}
	public char alphabette() {
		
		while (true) {
			int al = (int) (Math.random() * 122 + 1);
			if ((al >= 65 && al <= 90) || (al >= 97 && al <= 122)) {
				return (char)al;
			}
		}
	}
	
	public String mySubstring(String str,int index1, int index2) {
		if(str==null)
			return null;
		
		return str.substring(index1, index2);
	}

}
