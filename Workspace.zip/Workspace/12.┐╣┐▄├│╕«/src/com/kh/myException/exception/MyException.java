package com.kh.myException.exception;

public class MyException extends Exception{
	
	public MyException() {
		
	}
	
	public MyException(String string) {
		super(string);
	}

}
