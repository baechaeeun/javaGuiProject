package com.kh.myException.run;

import java.util.Scanner;

import com.kh.myException.exception.MyException;

public class Run {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc=new Scanner(System.in);
		System.out.println("정수를 하나 입력하시오 : ");

		int num=sc.nextInt();
		try {
			checkNum(num);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private static void checkNum(int num) throws Exception{
		if(num<10) {
			throw new Exception(num+"은 10보다 작은 수잖아~");
		}else {
			System.out.println(num+"은 10보다 크거나 같은 수구나");
		}
		
	}

}
