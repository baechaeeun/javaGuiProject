package com.kh.exception.controller;

import java.util.Scanner;

public class A_UnCheckedException {
	private Scanner sc=new Scanner(System.in);
	
	public void method1() {
		System.out.println("정수1 : ");
		int num1=sc.nextInt();
		
		System.out.println("정수2 : ");
		int num2=sc.nextInt();
		
		//int result=num1/num2;
		
		//if문처리
		int result = 0;
		
		if(num2 !=0) {
			result=num1/num2;
		}
		System.out.println(result);
		
		//try-catch
		/* try{
		 * 	에외가 발생될 수 있는 구문;
		 * }catch(발생될 예외 클래스 매개변수){
		 * 		해당 예외가 발생되는 경우 처리할 구문;
		 * }
		 */
		int result1=0;
		try {
			result1= num1/num2;
		}catch(Exception e) {
			System.out.println("0으로 나눌 수 없습니다.");
		}
		
		System.out.println(result1);
	
	}
	public void method2() { //-음수 넣어보기
		System.out.println("배열의 길이 : ");
		int num=sc.nextInt();
		
		/*if (num > 0) {
			int arr[] = new int[num];
		}
		else {
			System.out.println("양수를 입력하세요~");
		}*/
		
		try {
			int arr[] = new int[num];
		}catch (NegativeArraySizeException e) {
			System.out.println("양수를 입력하세요~");
		}
	
	}
	
	public void classNArrayEx() {
		try {
			//ClassCastException : 잘못된 자료형 변환시 발생하는 예외클래스
			Object obj = 'a'; //char => AutoBoxing -> Character -> 다형성 -> Object
			String str=(String)obj; //런타임에러
			
			//ArrayIndexOutOfBoundsException : 배열의 범위를 넘어 갔을때 발생하는 예외클래스
			int[] arr=new int[2];
			arr[0]=1;
			arr[1]=2;
			arr[2]=3; //런타임에러
			
			//NullPointerException : Null인 참조형 변수에 접근해서 메소드를 쓸려고 할 때 발생
			String str1 = null;
			int length = str1.length();
			
			
		} // 나란히 작성하는 경우 형제레벨만 함께 사용
		/*catch(ClassCastException e) {
			System.out.println("잘못 형변환 했네, 복습하자");
		}catch(ArrayIndexOutOfBoundsException e) {
			System.out.println("배열크기 잘못지정했네, 복습하자");
		}catch(NullPointerException e) {
			System.out.println("객체없이 메소드 쓸려고 하네, 복습하자");
		}*/catch(Exception e) {
			e.printStackTrace();
			System.out.println("e.getMessage()"+e.getMessage());
			System.out.println("e.toString()"+e.toString());
		}finally {
			System.out.println("여전히 실행하는군");
		}
	}

}
