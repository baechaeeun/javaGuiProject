package com.kh.exception.controller;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class CheckedException {
	/* 
	 * CheckedException 은 반드시 예외처리를 해줘야 하는 예외들이다.
	 * 조건문, 소스코드 수정으로 해결이 안된다 --> 예측불가
	 * 주로 외부매개체 입출력 시 발생
	 * 
	 * IOException 입출력과정 중 문제가 생겼을 때 던져지는 예외
	 */
	
	public void method1() throws Exception {
		try {
			method2();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			System.out.println("  종료~~ !!");
		}
	}

	private void method2() throws Exception{
		
		//1. try-catch() 처리 : 여깃허 바로 예외를 처리하겠다라는 거
			//try : 예외가 발생할 가능성이 있는 코드를 블록 내에 작성
			//catch : (발생될 예외클래스 매개변수) : try 구문에서 발생하면 어떻게 처리를 할 건지 작성
			//finally : try-catch문 수행 후 반드시 꼭 실행해야 하는 코드들을 작성
		
		byte [] aa= {'a','b','c'};
		try {
			System.out.write(aa);
		}catch(IOException e) {
			e.printStackTrace();
		}
		
	}
	
	public void method3() {
		BufferedReader br=null;
		try {
			br = new BufferedReader(new FileReader(""));
		}catch(FileNotFoundException e) {
			e.printStackTrace();
			
			
		}
	}
	
	//try-with-resource
	//반납할 close 자원이 있는 경우 try-with-resource 구분으로 처리할 수 있다.
	//꼭 반납해야 하는 객체의 경우 try() 안에서 객체를 생성하고 이 생성한 객체는 close 해주지 않아도 자동 close 된다.
	public void method4() throws IOException {
		try (BufferedReader br = new BufferedReader(new FileReader("D:\\test.txt"))) {

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	public void method5() throws Exception{
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("아무 문자열을 입력해주세요");
		
		String str=br.readLine();
		System.out.println(br);
		
		if("a".equals(str)) {
			throw new Exception(str);
		}
	}
}
