package com.kh.part02_scheduling.model.thread;

//스레드 스케줄링
//싱글코어환경에서 우선순위 방식을 사용하면 우선순위가 높은 스레드일수록 더 많은 양의 실행 시간이 주어진다.
//멀티코어에서는 차이가크게 나타나지 않는다.
public class Thread3 implements Runnable{

	@Override
	public void run() {
		// TODO Auto-generated method stub
		
		//우선순위가 그나마 적용되게 하기 위한 delay 코드(지연코드)
		for(int i=0;i<Integer.MAX_VALUE;i++) {
			
			for(int j=0;j<Integer.MAX_VALUE;j++) {
				
			}
		}
		
		System.out.println(Thread.currentThread().getName());
	}
	
}
