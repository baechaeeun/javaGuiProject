package com.kh.part03_control.thread;

public class Thread4 implements Runnable{

	//sleep(); 지정한 시간동안 스레드를 일시정지 시키는 메소드
	//일시정지하고자하는 스레드 내부에서 사용(run,main)
	//static으로 선언되어 있기 때문에 Thread, sleep()으로 호출
	@Override
	public void run() {
		try {
			for (int i = 1; i <= 10; i++) {
				Thread.sleep(1000); // 매개변수 단위가 1/1000초 우리가 1000을 작성하면 -->1초
				
				System.out.println(i + "초");
			}
			System.out.println("카운트 종료");
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
