package practice2.model.run;

import practice2.model.thread.Heart2;
import practice2.model.thread.Star2;

public class Race {

	// 처음부터 얼만큼 움직였는지를 누적시킬 public static형 int 변수
	// static이니까 값이 객체에 상관없이 static영역에 유지되고 공유됨
	public static int tot1 = 0;
	public static int tot2 = 0;

	public static void main(String[] args) {
		Heart2 h2 = new Heart2();
		Star2 s2 = new Star2();
		Thread th1 = new Thread(h2);
		Thread th2 = new Thread(s2);

		try {
			th1.start();
			Thread.sleep(500);
			th2.start();

			th1.join();
			th2.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		String str = Race.tot1 > Race.tot2 ? "♡승!" : (Race.tot1 < Race.tot2 ? "☆승!" : "무승부!");
		System.out.println(str);

	}

}
