package com.kh.run;

import com.kh.operater.A_LogicalNegation;
import com.kh.operater.B_InDecrease;
import com.kh.operater.C_Arithmetic;
import com.kh.operater.D_Comparision;
import com.kh.operater.E_Logical;
import com.kh.operater.F_Compound;
import com.kh.operater.G_Triple;

public class Run {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//A_LogicalNegation a=new A_LogicalNegation();
		//a.method2();
		
//		B_InDecrease b=new B_InDecrease();
//		b.method4();
		
//		C_Arithmetic c=new C_Arithmetic();
//		c.method2();
		
//		D_Comparision d= new D_Comparision();
//		d.method1();
		
//		F_Compound f=new F_Compound();
//		f.method();
		
		G_Triple g=new G_Triple();
		g.method6();

	}

}
