package com.kh.operater;

import java.util.Scanner;

public class E_Logical {
	/* 논리연산자
	 * - 두 논리값을 연산하는 연산자
	 * - 논리연산자의 결과 값도 논리 값
	 * 
	 * 논리값 && 논리값 : 왼쪽, 오른쪽 둘다 true 인 경우 true
	 * 논리값 || 논리값 : 왼쪽, 오른쪽 둘 중에 하나라도 true 일 경우 true
	 * 
	 */
	
	public void method1() {
		Scanner sc=new Scanner(System.in);
		
		System.out.print("정수 하나 입력 : ");
		int num = sc.nextInt();
		//num값이 1이상이고 100이하인가요? result = (1<=num <=100)
		boolean result;
		
		result = (num >= 1) && (num <=100); //&& : 이고 
		
		System.out.println("사용자가 입력한 값이 1 이상 100 이하의 값입니까 : "+result);
		
		//&& : 두 개의 조건이 모두 true 여야 && 연산의 결과 값이 최종적으로 true
		// 둘 중에 하나라도 false 이면 &&의 결과 값은 false
		
	}
	public void method2() {
		Scanner sc=new Scanner(System.in);
		System.out.println("문자하나입력 : ");
		char ch=sc.nextLine().charAt(0);
		
		boolean result=(ch >= 'A') && (ch <= 'Z');
		System.out.println("사용자가 입력한 값이 대문자입니까 : "+result);
		
	}
	public void method3() {
		Scanner sc=new Scanner(System.in);
		
		//사용자가 입력한 값이 'y'인지 또는 'Y'인지 확인하기
		
		System.out.println("계속하시려면 y 혹은 Y를 입력하세요 : ");
		char ch = sc.nextLine().charAt(0);
		
		boolean result = ch=='y' || ch=='Y';
		System.out.println(result);
	}
	/* 
	 * && : 두개의 조건이 모두 true 여야 결과 값이 true(AND)
	 * 
	 * true && true => true
	 * true && false => false
	 * false && true => false
	 * false && false => false
	 * 
	 * --> && 연산자를 기준으로 앞의 결과가 false 값이 나오면 뒤의 조건은 굳이 실행하지 않는다.(short cut)
	 * 
	 * 
	 * || : 두개의 조건이 하나라도 true 라면 true (OR)
	 * 
	 * true || true => true
	 * true || false => false
	 * false || true => true
	 * false || false => false
	 * 
	 * --> || 연산자를 기준으로 앞의 결과가 true 가 나오면 뒤의 조건은 실행하지 않는다.
	 */
	
	public void method4() {
		int num = 10;
		System.out.println("&& 연산전의 num 값 : "+num);
		
		boolean result1 = (num < 5) && (++num > 0);
		
		System.out.println("result1 : "+result1);
		System.out.println("&& 연산 후의 num 값 : "+num);
		
		boolean result2 = (num < 20) && (++num > 0);
		
		System.out.println("result2 : "+result2);
		System.out.println("|| 연산 후의 num 값 : "+num);
		// ||연산자 기준으로 이미 앞에서 true 이기 때문에 뒤의 연산은 수행되지 않는다.
		
		
	}
}
