package com.kh.operater;

public class D_Comparision {
	//비교 연산자(관계연산자)
	/* 두 값을 비교하는 연산자, 다른말로 관계연산자
	 * 비교 연산자는 조건을 만족하면 true(참), 만족하지 않으면 false(거짓) 을 반환
	 * 
	 * 
	 * a < b : a 가 b 보다 작은가?
	 * a > b : a 가 b 보다 큰가?
	 * a == b : a 와 b 가 같은가?
	 * a != b : a 와 b 가 다른가?
	 * a <= b : a 가 b보다 작거나 같은가?
	 * a >= b : a 가 b보다 크거나 같은가?
	 * 
	 */
	
	public void method1() {
		int a = 10;
		int b = 25;
		
		System.out.println("a == b : "+(a == b));
		System.out.println("a <= b : "+(a <= b));
		System.out.println("a > b : "+(a > b));
		
		//산술 + 비교
		
		System.out.println("a는 짝수인가 : "+(a % 2 == 0));
		System.out.println("b는 짝수인가 : "+(b % 2 == 0));
		
		System.out.println("a는 홀수인가 : "+(a % 2 == 1));
		System.out.println("b는 홀수인가 : "+(b % 2 == 1));
	}
	
}
