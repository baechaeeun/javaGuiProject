package com.kh.operater;

public class B_InDecrease {
	/*
	 * 증감연산자 (단독으로 사용시에는 그냥 1증가)
	 * ++ : 값을 1증가 시키는 연산자
	 * 		++값(전위연산자), 값++(후위연산자)
	 * -- : 값을 1 감소 시키는 연산자
	 * 		--값(전위연산자), 값--(후위연산자)
	 * 
	 * 	(증감연산자)값 : 전위연산자 ---> 선증감 후처리
	 * 	값(증감연산자) : 후처리연산자 ---> 선처리 후증감
	 * 		*/
	
	public void method1() {
		int num1=10;
		
		System.out.println("전위 연산자 적용 전 num1의 값 : "+num1);
		System.out.println("1회 수행후 num1의 값 : "+ ++num1);
		System.out.println("2회 수행후 num1의 값 : "+ ++num1);
		System.out.println("3회 수행후 num1의 값 : "+ ++num1);
		System.out.println("전위 연산자 적용 후 num1의 값 : "+ num1);
		
		
		System.out.println("=============================");
		
		int num2=10;
		
		System.out.println("전위 연산자 적용 전 num1의 값 : "+num2);
		System.out.println("1회 수행후 num1의 값 : "+ num2++);
		System.out.println("2회 수행후 num1의 값 : "+ num2++);
		System.out.println("3회 수행후 num1의 값 : "+ num2++);
		System.out.println("전위 연산자 적용 후 num1의 값 : "+ num2);
		
	}
	
	public void method2() {
		//전위연산자
		int a=10;
		int b=++a;
		System.out.println("a : "+a+"b : "+b);
		
		int c=10;
		int d=c++;
		System.out.println("c : "+c+"d : "+d);
		
		System.out.println("================");
		
		int num = 20;
		
		System.out.println("현재 num : "+num);
		System.out.println("++ num : "+ ++num);
		System.out.println("num ++: "+ num++);
	}
	
	public void method3() {
		int num1=20;
		int result=num1++ *3;
		
		System.out.println("result : "+result);
		System.out.println("num1 : "+num1);
		
		int num2=20;
		int result2=++num2*3;
		
		System.out.println("result2 : "+result2);
		System.out.println("num2 : "+num2);
	}
	
	public void method4() {
		int a=10;
		int b=20;
		int c=30;
		
		System.out.println(a++); //10(11)
		System.out.println((++a)+(b++)); //12 + 20 = 32 (12,21)
		System.out.println((a++)+(--b)+(--c)); //12+20+29(13,20,29)
		
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
		
		a++;
		
	}
}
