package com.kh.operater;

import java.util.Scanner;

public class G_Triple {
	/* 삼항연산자 : 항목이 3개인 연산자
	 * 
	 * 조건식 ? 조건식이 참일 경우 값1 : 조건식이 거짓일 경우 값2
	 * 
	 * 이때, 조건식은 반드시 true, false 가 나오게끔 작성해야 한다.
	 * 주로 조건식에는 비교, 논리 연산자가 사용된다.
	 * 
	 */
	
	public void method1() {
		Scanner sc=new Scanner(System.in);
		
		System.out.print("정수 값 입력 : ");
		int num=sc.nextInt();
		
		System.out.println(num + "은 "+((num>0)?"양수이다":"음수이다"));
	}
	
	public void method2() {
		//사용자가 키보드로 입력한 정수의 값이 홀수인지 짝수인지 판별 후 출력
		
		Scanner sc=new Scanner(System.in);
		
		System.out.print("정수를 입력하세요 : ");
		int num=sc.nextInt();
		
		System.out.println(num%2==0 ? "짝수입니다." : "홀수입니다.");
		
	}
	public void method3() {
		//사용자한테 키보드로 정수 값 두개를 입력받아서
		//두 정수 값의 곱셈 결과가 100 이상인 경우 "결과가 100이상입니다."
		//아닌 경우 "결과가 100보다 작습니다."
		
		Scanner sc=new Scanner(System.in);
		
		System.out.print("정수 값을 입력하세요 : ");
		int a=sc.nextInt();
		System.out.print("정수 값을 입력하세요 : ");
		int b=sc.nextInt();
		
		System.out.println(a*b>=100 ? "결과가 100 이상입니다." : "결과가 100보다 작습니다.");
	}
	
	public void method4() {
		//사용자가 입력한 영문자가 대문자인지 소문자인지 판별 후 출력
		
		Scanner sc=new Scanner(System.in);
		
		System.out.print("영어 문자를 입력하세요 : ");
		
		char a=sc.nextLine().charAt(0);
		String result="";
		
		if(a>='a'&&a<='z')
			result="소문자입니다.";
		else if(a>='A'&&a<='Z')
			result="대문자입니다.";
		
		System.out.println(result);
		
	}
	public void method5() {// 삼항연산자 중첩
		// 키보드로 입력받은 정수가 0인지 아닌지 판별한 후
		// 0이 아닌 경우 양수인지 음수인지 판별해서 출력
		
		Scanner sc=new Scanner(System.in);
		
		System.out.print("정수를 입력하세요 : ");
		int n=sc.nextInt();
		
		String st=n==0?"0입니다.":(n>0?"양수입니다.":"음수입니다.");
		System.out.println(st);
	}
	
	public void method6() {
		//키보드로 정수를 입력받고 + 또는 - 를 입력 받아 계산 결과를 출력하기
		//단 + 또는 - 이외의 숫자를 입력하는 경우 "잘못입력하였습니다."
		
		/*
		 * Scanner sc=new Scanner(System.in);
		 * 
		 * System.out.print("정수1를 입력하세요 : "); int a=sc.nextInt(); sc.nextLine();
		 * System.out.print("+,-를 입력하세요 : "); char b=sc.nextLine().charAt(0);
		 * System.out.print("정수2를 입력하세요 : "); int c=sc.nextInt(); sc.nextLine();
		 * 
		 * String result= (b=='+'?(a+c+""):(b=='-'?(a-c+""):"잘못입력하였습니다."));
		 * System.out.println(result);
		 */
		
		
		int a=5;
		int b=10;
		int c=(++a)+b;
		int d=c/a;
		int e=c%a;
		int f=e++;
		int g=(--b)+(d--);
		int h=2;
		int i=a++ + b / (--c/f) * (g-- - d) %(++e+h);
		
		System.out.println("a : "+a);
		System.out.println("b : "+b);
		System.out.println("c : "+c);
		System.out.println("d : "+d);
		System.out.println("e : "+e);
		System.out.println("f : "+f);
		System.out.println("g : "+g);
		System.out.println("h : "+h);
		System.out.println("i : "+i);
	}
	
}
