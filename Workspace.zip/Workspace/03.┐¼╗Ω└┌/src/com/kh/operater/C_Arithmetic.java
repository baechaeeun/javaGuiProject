package com.kh.operater;

public class C_Arithmetic {
	//우리가 흔히 계산할 때 쓰는 산술 연산자 (*,+,-,/,%)
	
	public void method1() {
		int num1 = 10;
		int num2 = 3;
		
		System.out.println("num1 + num2 = " +(num1+num2));
		System.out.println("num1 - num2 = " +(num1-num2));
		System.out.println("num1 * num2 = " +(num1*num2));
		System.out.println("num1 / num2 = " +(num1/num2)); //나누기 몫
		System.out.println("num1 % num2 = " +(num1%num2));	//나누기 나머지
		
		//% 나중에 조건문에서 짝수인지 홀수인지 구분
		// 값 % 2 == 0 짝수
		// 값 % 2 == 1 홀수
		
		// 그리고 배수 물어볼 때 (5의 배수냐?)
		// 값 % 5 == 0
		
	}
	
	public void method2 () {
		double a = 35;
		double b = 10;
		
		System.out.println("a = "+a);
		System.out.println("b = "+b);
		
		double sum = a+b;
		System.out.println("a+b = "+sum);
		
		double sub = a-b;
		System.out.println("a-b = "+sub);
		
		double mul = a*b;
		System.out.println("a*b = "+mul);
		
		double div = a/b;
		System.out.println("a/b = "+div);
		//몫 이라고 해서 정수만 생각할수 있는데 
		//double 로 받으면 소숫저 까지 표현  그래서 3.5 (int = 3)
		//나누기는 받는 자료형에 따라 몫의 값이 달라진다.
		
		double mod = a%b;
		System.out.println("a%b = "+mod);
		
		int c = 27;
		
		double result = a + a*b % c - a / b;
		//1. a * b 350
		//2. 350 % c = 26
		//3. a / b
		//4. a + 26.0 - 3.5 = 57.5
		
		System.out.println(result);
	}
}
