package com.kh.operater;

public class F_Compound {
	
	/* 복합대입연산자 : 산술 연산자와 대입 연산자를 함께 사용하는 연산자
	 * 				연산 처리 속도가 훨씬 빠름
	 * 
	 * +=, -=, *=, /=, %=
	 * 
	 * a=a+3; => a+=3;
	 * a=a-3; => a-=3;
	 * a=a*3; => a*=3;
	 * a=a/3; => a/=3;
	 * a=a%3; => a%=3;
	 * 
	 */
	public void method() {
		int num =12;
		
		System.out.println("num : "+num);
		
		//num 을 3 증가 시키기
		num=num+3;
		System.out.println("3 증가시킨 num : "+num);//15
		
		//num 을 3증가 시키기
		num+=3;
		System.out.println("또 3 증가시킨 num"+num);//18
		
		//num 5 감소시키기
		num -= 5;
		System.out.println("5 감소시킨 num"+num);//13
		
		//num을 6배 증가 시키기
		num *= 6;
		System.out.println("6배 증가시킨 num"+num);//78
		
		//num을 2배 감소
		num/=2;
		System.out.println("2배 감소시킨 num"+num);//39
		
		num%=2;
		System.out.println("num을 4로 나눈 나머지"+num);//3
		
		// 증감 연산자 (++, --) 와 비슷해 보이지만 증감 연산자는 값을 1씩만 증감이 된다.
		// 복합 대입 연산자는 내가 원하는 숫자만큼 증감 시킬 수 있다.
		
		String str = "Hello";
		System.out.println("str : "+str);
		
		str += "World";
		System.out.println("최종 str : "+str);
		
		str += 1;
		System.out.println("최종 str : "+str);
		
		
	}
	
}
