package com.kh.run;

import com.kh.first.B_ValuePrinter;

public class RunB {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		B_ValuePrinter b= new B_ValuePrinter(); //ctrl+shift+o
		
		//b.printValue();
		
		b.sumStringNumber();
	}

}
