package com.kh.run;

import com.kh.first.A_MethodPrinter;

public class RunA {

	public static void main(String[] args) {
		
		//1)실행할 메소드가 있는 클래스를 생성(new)해야함.
		//[표현법] 클래스명 사용할이름  = new 클래스명();
		A_MethodPrinter a=new A_MethodPrinter();
		
		a.methodA();
		//b.methodA();

	}

}
