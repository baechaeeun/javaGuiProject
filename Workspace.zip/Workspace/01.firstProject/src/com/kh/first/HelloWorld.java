package com.kh.first;

public class HelloWorld {
//ctrl+shift+F 자동 정렬
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Hi");
		System.out.println(args[1]);
		System.out.println(args[0]);
		System.out.println("안녕하세요");
		System.out.print("안녕하세요\n");
		System.out.print("안녕하세요");
		
	}

}
