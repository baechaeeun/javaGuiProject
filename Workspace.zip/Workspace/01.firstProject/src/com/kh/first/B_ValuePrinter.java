package com.kh.first;

/*원칙
 * 1. 클래스명 --> 대문자로 시작
 * 2. 패키지명 --> 소문자로 시작
 * 3. 메소드명 --> 소문자로 시작
 * 4. 변수명 --> 소문자로 시작
 * B_ValuePrinter 단어가 여러개일때는 단어 앞자리는 대문자, 뒤에는 소문자로 적어야함.
 * 
 * */
public class B_ValuePrinter {

	public void printValue() {
		System.out.println(123);
		System.out.println(1.23);

		System.out.println('a');
		System.out.println('b');

		System.out.println("안녕하세요");
		System.out.println("반가워요");

		System.out.println(123 + 456);
		System.out.println(1.23);

		System.out.println('a' + 1);

		System.out.println("하이" + 'a');
		System.out.println("안녕하세요" + 123);
		System.out.println("하이" + 111 + 222);
	}
	public void sumStringNumber() {
		System.out.println(9+9); //18
		System.out.println(9+"9"); //99
		System.out.println("9"+9); //99
		
		System.out.println(9+9+"9"); //189
		System.out.println(9+"9"+9); //999
		System.out.println("9"+9+9); //918,999
		System.out.println("9"+(9+9)); //918
		
		
	}
}
