package com.kh.first;

public class A_MethodPrinter {
	public void methodA() {// 메소드 명은 소문자
		System.out.println("메소드 A 출력!");
		methodB();
	}

	public void methodB() {// 메소드 명은 소문자
		System.out.println("메소드 B 출력!");
		methodC(123);

	}

	public void methodC(int ival) {// 메소드 명은 소문자
		System.out.println("메소드 C 출력!     :     "+ival);

	}
}
