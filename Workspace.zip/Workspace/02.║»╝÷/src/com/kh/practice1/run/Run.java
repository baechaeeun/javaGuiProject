package com.kh.practice1.run;

import com.kh.practice1.example.VariablePractice;

public class Run {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			VariablePractice a=new VariablePractice();
			
			a.method2();
	}

}
