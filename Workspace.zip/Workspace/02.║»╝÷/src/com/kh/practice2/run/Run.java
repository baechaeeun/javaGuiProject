package com.kh.practice2.run;

import com.kh.practice2.example.CastingPractice;

public class Run {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CastingPractice c=new CastingPractice();
		c.method3();
	}

}
