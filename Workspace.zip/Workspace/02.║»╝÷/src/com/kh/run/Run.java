package com.kh.run;

import com.kh.variable.A_Variable;
import com.kh.variable.C_Overflow;
import com.kh.variable.D_Cast;
import com.kh.variable.E_Printf;
import com.kh.variable.F_KeyboardInput;

public class Run {

	public static void main(String[] args) {

		//A_Variable a = new A_Variable();

		//a.initVariable();
		/*
		 * boolean v1=false; char v2='가'; double v3=3.14; int v4=30; String v5="aaa";
		 * 
		 * System.out.println(v1); //false System.out.println(v2); //가
		 * System.out.println(v3); //3.14 System.out.println(v4); //30
		 * System.out.println(v5); //aaa
		 */		
		
		//C_Overflow c=new C_Overflow();
		//c.overflow();
		
//		D_Cast d=new D_Cast();
//		d.stringTest();
		
		/*
		 * E_Printf e=new E_Printf(); e.printMethod();
		 */
		
		F_KeyboardInput f=new F_KeyboardInput();
		f.inputScanner2();
		
	}

}
