package com.kh.variable;

public class B_Constant {
	public void finalConstant() {
		int age = 20;
		age = 30;

		final int AGE = 20;
		// AGE=30; 오류발생( 상수는 한번 지정한 값을 변경할 수 없음)

	}
}
