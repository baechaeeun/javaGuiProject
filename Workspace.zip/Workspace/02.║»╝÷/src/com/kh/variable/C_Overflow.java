package com.kh.variable;

public class C_Overflow {
	
	public void printVariableSize() {// 변수별 사이즈 출력
		System.out.println("byte 크기 : " + Byte.MAX_VALUE+"byte");
		System.out.println("short 크기 : " + Short.BYTES+"byte");
		System.out.println("int 크기 : " + Integer.BYTES+"byte");
		System.out.println("long 크기 : " + Long.BYTES+"byte");
		System.out.println("float 크기 : " + Float.MAX_VALUE+"byte");
		System.out.println("double 크기 : " + Double.MAX_VALUE+"byte");
		System.out.println("char 크기 : " + Character.MAX_VALUE+"byte");
		
		
	}
	
	public void overflow() {
		//byte 자료형 값 저장 범위 : -128 ~ 127
		
		byte bNum= 127; // 에러, 범위를 벗어났음
		
		byte result=(byte)(bNum+3);
		
		System.out.println(result);
		
		int num1= 1000000;
		int num2=700000;
		
		int result2=num1*num2;
		System.out.println(result2);
		
		//해결방법 --> 더큰자료형으로 변경 해주면 됨
		
		long result3= num1*(long)num2;
		System.out.println(result3);
		
	}

}
