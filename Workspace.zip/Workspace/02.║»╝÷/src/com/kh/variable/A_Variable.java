package com.kh.variable;

public class A_Variable {
	// 변수란 ? --> 어떤값을 메모리에 기록하기위한 공간 (박스같은개념)
	// 변수를 사용하는 이유 : 가독성이 좋아지고 , 유지보수가 용이하다.
	public void printValue() {
		System.out.println("변수사용전");
		System.out.println(2 * 3.14159246456123 * 10);
		System.out.println(3.14159246456123 * 10 * 10);
		System.out.println(3.14159246456123 * 10 * 10 * 20);
		System.out.println(24 * 3.14159246456123 * 10 * 10);

		System.out.println("변수사용후");
		
		double pi = 3.14159246456123;
		int r = 10;
		int h = 20;
		System.out.println(2 * pi * r);
		System.out.println(pi * r * r);
		System.out.println(pi * r * r * h);
		System.out.println(24 * pi * r * r);
	}
	
	public void declareVariable() {
		/*
		 * 1. 변수의 선언(저장할 값을 기록하기 위해 변수를 메모리 공간에 확보해 놓는 과정) = 박스
		 * 2. 자료형 변수명;
		 * 
		 * 
		 * 자료형은 : 어떤 값을 담아낼지, 어떤 크기의 값을 담아낼지
		 * 변수명 : 변수의 이름
		 * 
		 * 변수명은 반드시 첫글자가 소문자여야한다. 하지만 여러 단어가 엮이는 경우 연결되는 단어의 첫글자는 대문자!!
		 * 동일한 변수명으로 선언이 불가능하다.
		 * {} 블럭 내에서만 활용 가능하다. == 지역변수
		 * 
		 */
		
		//자료형(1~3 기본형 8개)
		//1. 논리형
		boolean isTrue; //1byte
		
		//2. 숫자형
		//2-1. 정수형
		
		byte bNum; //1byte
		short sNum; //2byte
		int iNum; //4byte --> 정수형중에 가장 대표적인 자료형(기본형) 약 -21억~21억
		long lNum; //8byte
		
		//2_2. 실수형
		
		float fNum; //4byte
		double dNum; //8byte --> 실수형 중 가장 대표저인 자료형 (기본형) 소수점 15자리, 정확하게 표현가능
		
		//3. 문자형
		char ch; //2byte
		
		//4. 문자열(참조자료형)
		String str;
		
		/*
		 * 변수에 값대입
		 * 박스에 값을 담는 것, 위에서 선언한 변수에 값을 넣는다.
		 * 
		 * 변수명 = 값;
		 */
		
		isTrue=true; //논리형변수 true, false 저장
		
		bNum = 1;
		sNum=2;
		iNum=5;
		lNum=8L; //long 변수에는 l 또는 L을 붙여서 long 자료형 이라는 것을 표현
		
		fNum=4.0f; //반드시 f 
		dNum=8.0d; //d 안붙여도되고, 8.0
		
		ch='A'; //따옴표
		str="AERE"; //쌍따옴표
		str="A"; //쌍따옴표
		
		System.out.println("isTrue 값 : "+isTrue);
		System.out.println("bNum 값 : "+bNum);
		System.out.println("sNum 값 : "+sNum);
		System.out.println("iNum 값 : "+iNum);
		System.out.println("lNum 값 : "+lNum);
		System.out.println("fNum 값 : "+fNum);
		System.out.println("dNum 값 : "+dNum);
		System.out.println("ch 값 : "+ch);
		System.out.println("str 값 : "+str);
		
		
	}
	public void initVariable() {
		/*
		 * 변수 선언과 동시에 초기화 == 박스 만드는것과 동시에 값을 담는다.
		 * 자료형 변수명 = 값
		 */	
		
		//1. 논리형
		boolean isTrue = false;
		
		//2_1숫자 (정수형)
		byte bNum = 1;
		short sNum = 2;
		int iNum = 4;
		long lNum = 8;
		
		//2_2 숫자(실수형)
		float fNum = 4.0f;
		double dNum = 8.0d;
		
		char ch = '가';
		
		String str = "B_오전반";
		
		System.out.println("isTrue 값 : "+isTrue);
		System.out.println("bNum 값 : "+bNum);
		System.out.println("sNum 값 : "+sNum);
		System.out.println("iNum 값 : "+iNum);
		System.out.println("lNum 값 : "+lNum);
		System.out.println("fNum 값 : "+fNum);
		System.out.println("dNum 값 : "+dNum);
		System.out.println("ch 값 : "+ch);
		System.out.println("str 값 : "+str);
		
		
		//변수 명명규칙
		int number;
		
		//1)변수명이 같으면 에러가 발생
		//int number1;
		
		//2)대문자로 시작하면 안됨..
		int Number;
		
		//3)예약어(이미 자바에서 사용되고 있는 키워드를 사용할 수 없다)
		
		 //int void; 
		 //int class; 
		 //int char;
		 
		//4)숫자가능하지만 숫자로 시작하면 안됨.
		int age1;
		//int 1age; (x)
		
		//5)특수문자 가능 ( 단 _ $  이외의 특수문자는 사용 불가)
		int number_1;
		int number$1;
		
		//6)단어시작은 소문자, 연결되는 단어 첫글자는 대문자
		String userName;
		String username; //(x);
		
		
		
	}
}
