package com.kh.variable;

public class E_Printf {
	public void printMethod() {
		//System.out.println("포맷", 출력하고자 하는 값);
		/* 출력하고자 하는 값들이 제시된 포맷(형식)에 맞춰서 출력,, --->한줄 띄어쓰기는 안함
		 * 
		 * %d : 정수
		 * %c : 문자
		 * %s : 문자열 또는 문자도 가능
		 * %f : 실수 (소숫점 아래 6자리)
		 * 
		 * \t : 정해진 공간만큼 띄어쓰기
		 * \n : 출력하고 다음 라인으로 옮김
		 * 
		 * */
		
		int iNum1=10;
		int iNum2=20;
		
		System.out.printf("%d\n", iNum1); //10
		System.out.printf("%d\n", iNum1,iNum2);
		System.out.printf("%d %d\n", iNum1,iNum2);
		
		System.out.printf("%d + %d = %d\n", iNum1, iNum2,iNum1+iNum2);
		System.out.printf("%5d\n", iNum1); //5칸 공간중에 오른쪽에 붙는다. (- 이면 왼쪽)
		
		
		float fNum=1.2345458f;
		double dNum=4.53;
		
		System.out.printf("%f\t%f\n",fNum,dNum);// %f - 실수값을 소수점아래 6자리까지 보여줌,
												//소수점 6재자리 이후는 반올림 되고, 소수점 아래 값이 없으면 0으로 채움
		
		System.out.printf("%.3f\t%.3f\n",fNum,dNum);
		
		char ch='a';
		String str="Hello";
		
		System.out.printf("%c %s\n",ch, str);
		System.out.printf("%c %s\n",ch, ch); //%s에는 char형도 가능
		System.out.printf("%C %S\n",ch, str); //대문자도 가능
		
		
	}
}
