package com.kh.variable;
import java.util.Scanner;

public class F_KeyboardInput {
	//1. 사용자가 키보드로 입력한 값을 기록하는 방법 -->Scanner
	
	public void inputScanner1() {
		/* sc.nextLine()메소드를 제외한 다른 메소드들(sc.next(), sc.nextXXX()은 해당 값만
		 * 읽어오고, 사용자가 입력한'엔터'는 버퍼에 남아있다.
		 * 
		 * sc.nextLine() : 사용자가 입력한 한줄을 모두 읽어옴, 즉 엔터까지 모두 읽어온다.
		 * 
		 * 예로, sc.nextInt() 일 떄, 숫자를 입력하고 엔터를 누르면 
		 * age 에 숫자 값은 저장이 되고, '엔터'는 버퍼에 남아 있다가
		 * 아래에 sc.nextLine() 이 있다고 하면 이때 엔터를 읽어오게 된다.
		 * 
		 * sc.next(), sc.nextXXX() 메소드뒤에 sc.nextLine() 메소드를 한번 더 사용해서 버퍼에
		 * 남아있는 엔터를 실행시켜주자. (->한줄 내려감)
		*/
		Scanner sc=new Scanner(System.in); //System.in 입력받은 값을 byte 단위로 받아들이겠다.
		
		//System.out.print("당신의 이름은 무엇입니까 : ");
		//String name=sc.next(); //공백 전까지
		System.out.print("당신의 이름1은 무엇입니까 : ");
		String name1=sc.nextLine();
		
		System.out.print("당신의 나이는 무엇입니까 : ");
		int age=sc.nextInt(); //정수
		
		System.out.print("당신의 키는 몇입니까 : ");
		double height=sc.nextDouble(); //실수
		
		System.out.println(/*name + */"이름"+name1+"님은"+age+"세이며, 키는 "+height+"cm입니다.");
	}
	
	public void inputScanner2() {
		//Scanner : 키보드로 입력받기 위해
		
		//문자열을 입력받을 때 : sc.nextLine()
		//정수형 입력받을때 : sc.nextInt();
		//실수형 입력받을때 : sc.nextDouble();
		
		//byte, boolean 등등 기본자료형 입력받을 때도 마찬가지로 nextXXX() 형태로 쓰면 된다.
		Scanner sc=new Scanner(System.in);
		
		System.out.print("이름 : ");
		String name = sc.nextLine();
		
		System.out.print("성별(M/F) : ");
		
		char gender=sc.nextLine().charAt(0);
		
		System.out.print("나이 : ");
		int age=sc.nextInt();
		
		System.out.print("키 : ");
		double height=sc.nextDouble();
		
		System.out.println(name+" 님의 개인정보");
		System.out.println("성별 : "+gender);
		System.out.println("나이 : "+age);
		System.out.println("키 : "+height);
	}
	/*정리
	 * 1. 콘솔창에 (모니터로) 출력할 때 : System.out.println()메소드 이용
	 * 2. 콘솔창에 (키보드로) 입력받기 위해 : Scanner sc=new Scanner(System.in);
	 * sc.nextLine(), sc.nextInt(), sc.nextDouble(), sc.next(),,
	 * 
	 * 이때, sc.next() 또는 sc.nextXXX 메소드 뒤에 sc.nextLine() 메소드를 적어서
	 * 버퍼에 남은 엔터값을 실행시켜주는 과정 필수
	 * 
	 * char 문자 값을 입력받기 위해서는 sc.nextLine() 메소드를 통해서 문자열을 먼저 받아주고
	 * 그 뒤에 .charAt(0) 메소드를 통해서 문자로 변환해주는 순서로 진행 . (0)  (indext) int형 
	*/

}
