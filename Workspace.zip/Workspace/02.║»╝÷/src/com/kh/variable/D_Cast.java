package com.kh.variable;

public class D_Cast {
	
	//형변환 : 값의 자료형을 바꾸는 것
	
	/* 처리 방법 (형변환이 필요한 상황) 
	 * 1. 대입 연산자를 기준으로 오른쪽, 왼쪽이 같은 자료형이어야 함
	 * ->즉, 같은 자료형에 해당하는 값이 대입가능하다. 다른 자료형의 값을 대입하고자 한다면 형 변환이 필수이다.
	 * 자료형 변수명 = (자료형) 값;
	 * 
	 * 같은자료형끼리 계산--> 계산결과도 같은 자료형으로 나옴
	 * 값 + 값 --> 두 값이 같은 자료 형이어야 한다.
	 * 
	 * 형변환 종류
	 * 1. 자동(묵시적) 형변환 --> 자동으로 형변환이 이루어져서 우리가 형변환 시켜줄 필요가 없다.
	 * 
	 * 2. 강제(명시적) 형변환 --> 잗ㅇ으로 형변환이 안돼서 우리가 직접 형변환을 해주어야 한다.
	 * 						(바꿀자료형) 값
	 * 
	 * boolean 형변환 불가능, (true, false 값만 가진다)
	 * 
	 * 
	 * */
	
	//자동형변환
	public void rule1() {
		/* 자동형변환 
		 * 값의 범위가 작은 자료형과 큰 자료형 간의 연산 (대입, 계산) 시 컴파일러가 자동으로 범위가 작은 자료형을 큰 자료형으로 변환 처리
		 * */
		
		int i1=2;
		double d1=i1;
		
		System.out.println("d1  :  "+d1);
		
		int i2=12;
		double d2=3.3;
		
		double result=i2+d2;
		System.out.println("result  :   "+result);
		
		int i3=3333;
		long l3=i3;
		System.out.println("l3  :   "+l3);
		
		int i4=2147483647;
		long l4=1000000000L;
		long result2=i4+l4;
		System.out.println("result2  :   "+result2);
		
		//long(8byte)->flat(4byte)
		//자동형변환이 가능한이유 --> 표현할 수 있는 범위가 더 크다.
		long l5=1000000000L;
		float f5=l5;
		
		System.out.println(f5);
		
		//char(2byte)->int(4byte) : char 라는 자료형에 숫자가 들어오면 해당 숫자와 일치하는 문자를 유니코드 표에서 찾아서 출력 ..
		int num='A';
		System.out.println(num);
		
		//5. char 자료형에 정수 값이 저장 가능
		char ch=65;
		System.out.println(ch);
		
		short s=1;
		int i=s;
		
		//char ch=-65; //음수 저장 불가 --> 0~65535
		//byte, short, char ===> int 형 변환
		
		//char--
		/* 0~127 아스키 문자( 특수기호, 알파벳 할당) , 44032~ (한글)
		 * 
		 * */
		
		int ch2 = '가';
		System.out.println(ch2);
		
		char c2=(char)ch2;
		System.out.println(c2);
	}
	
	public void rule2() {
		//강제 형변환 : 큰 크기의 자료형을 작은 크기의 자료형으로 바꾸는 것(형변환 생략 불가능)
		
		double d=4.0;
		float f=(float)d;
		System.out.println(f);
		
		int iNum=10;
		double dNum=5.89;
		
		//에러 해결 방법
		//방법 1. 수행결과를 int 형으로 강제 형변환
		int iSum=(int)(iNum+dNum);
		System.out.println("iSum:    "+iSum);
		
		//방법 2. double형 값을 int 형으로 강제 형변환
		int iSum2 = (iNum+(int)dNum);
		
		//방법3. 연산결과를 double 형으로 받음
		
		double dSum = iNum + dNum;
		System.out.println("dSum :    "+dSum);
		
		//byte, short 연산
		byte bNum=1;
		short sNum=2;
		
		byte bSum=(byte)(bNum + sNum);
		short sSum=(short) (bNum+sNum);
		
		System.out.println("bSum   : "+bSum);
		System.out.println("sSum   : "+sSum);
		
		int sum2= bNum+sNum;
		System.out.println("sum2  : "+sum2);
	}
	
	public void stringTest() {
		//string pool에서는 이미 값이 있으면 주소 생성 안함.
		String s="안녕하세요";//heap(string pool)에 생성
		String s1="안녕하세요";//heap(string pool)에 이미 존재
		String s2=new String("안녕하세요");//heap새로생성
		
		System.out.println(System.identityHashCode(s));
		System.out.println(System.identityHashCode(s1));
		System.out.println(System.identityHashCode(s2));
		
		String t="정지훈";//heap(string pool)에 생성
		String t1="이효리";//heap(string pool)에 생성
		String t2=new String ("유재석");//heap새로생성
		String t3="유재석";//heap(string pool)에 새로생성
		String t4="이효리";//heap(string pool)에 이미존재
		
		System.out.println(System.identityHashCode(t));
		System.out.println(System.identityHashCode(t1));
		System.out.println(System.identityHashCode(t2));
		System.out.println(System.identityHashCode(t3));
		System.out.println(System.identityHashCode(t4));
		
		System.out.println(s );
		System.out.println(s1 );
		System.out.println(s2 );
		
		System.out.println(t );
		System.out.println(t1 );
		System.out.println(t2 );
	}
}
