package buyApplicaion;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Iterator;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import buyApplicaion.MainFrame;
import buyApplicaion.Users;

public class RewardHistory extends JPanel {

	public RewardHistory(MainFrame mf) {
		setLayout(null);
		setBounds(0, 0, 500, 800);
		setSize(500,800);
		
		JLabel jl2=new JLabel("멤버쉽 관리");
		jl2.setForeground(Color.blue);
		add(jl2,BorderLayout.NORTH);
		jl2.setBounds(220, 50, 500, 20);
		
		JButton b11=new JButton("나의멤버쉽");
		b11.setBackground(Color.white);
		add(b11);
		b11.setBounds(50,80,200,30);
		
		JButton b12=new JButton("history");
		b12.setBackground(Color.white);
		b12.setBounds(250,80,200,30);
		add(b12);
	
	
		
		b11.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				mf.change("myReward");
			}
		});
		b12.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				mf.change("rewardHistory");
				
			}
		});
		
		
		JPanel jp41 = new JPanel();
		jp41.setBounds(0,150,500,100);
		JButton b31=new JButton("주문 내역");
		b31.setBackground(Color.white);
		b31.setPreferredSize(new Dimension(480,50));
		jp41.add(b31);
		this.add(jp41);
		
        //적립내역 표 만들기 
		JPanel jp42 = new JPanel();
		jp42.setBounds(0,250,500,100);
		
		String[] headings=new String [3];
		headings[0]="커피주문";
		headings[1]="수량";
		headings[2]="등급";
		
		int num=mf.getUserManager().getUserNow().getBuy().size();
		String[][] data = new String[num][3];
		
		
		Iterator it=mf.getUserManager().getUserNow().getBuy().keySet().iterator();
		Iterator it2=mf.getUserManager().getUserNow().getBuy().values().iterator();
		int i=0;
		while(it.hasNext()) {
			data[i][0]=(String)it.next();
			data[i][1]=Integer.toString((int)it2.next());
			data[i][2]=mf.getUserManager().getUserNow().getLevel();
			
			i++;
		}
		

       JTable table = new JTable(data, headings);
       table.setPreferredScrollableViewportSize(new Dimension(450,300));
       table.setFillsViewportHeight(true);
       
       jp42.add(new JScrollPane(table));
        this.add(jp42);
        
        
    	JButton back =new JButton("←메인화면으로");
		back.setBackground(Color.white);
		back.setBounds(10, 500,130,30);
		add(back);
		
		back.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				mf.change("mainPanel");
			}
		});  
        
       
	}

	}
