package buyApplicaion;



import java.awt.Color;
import java.awt.Image;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;


public class ContentViewPanel extends JPanel {
	private MainFrame mf;	
	private JPanel backButtonPanel;
	private JPanel contentAreaPanel;
	private Board board;
	
	public static boolean buttonClicked = false;
	
	public ContentViewPanel(MainFrame mf, Board board) {
		this.mf = mf;
		setBoard(board);
		this.setLayout(null);
		this.setSize(500, 800);	
		this.add(contentAreaPanel = drawContentArea(board));
		this.add(backButtonPanel = drawBackButton());
	}
	
	public JPanel drawContentArea(Board board) {
		contentAreaPanel = new JPanel();
		contentAreaPanel.setLayout(null);
		contentAreaPanel.setBounds(40,100,400,500);
		contentAreaPanel.setBackground(Color.white);
		JLabel title = new JLabel(board.getBoardTitle());
		JLabel date = new JLabel("작성 날짜 : "+board.getBoardDate());
		JLabel content = new JLabel(board.getBoardContent());
		
		title.setSize(100, 20);
		title.setLocation(170,20);
		
		date.setForeground(Color.black);
		date.setSize(300,20);
		date.setLocation(200,60);
		
		content.setForeground(Color.black);
		content.setSize(300,200);
		content.setLocation(30,50);
		
		contentAreaPanel.add(title);
		contentAreaPanel.add(date);
		contentAreaPanel.add(content);
		
		return contentAreaPanel;
	}
	
	public Board getBoard() {
		return board;
	}

	public void setBoard(Board board) {
		this.board = board;
	}

	public JPanel drawBackButton() {
		backButtonPanel = new JPanel();
		backButtonPanel.setLayout(null);
		backButtonPanel.setBounds(40,40,170,50);
		backButtonPanel.setBackground(Color.LIGHT_GRAY);
		
		ImageIcon originImg = new ImageIcon("backbutton.png");
		Image img = originImg.getImage().getScaledInstance(50, 50, Image.SCALE_SMOOTH);
		ImageIcon adjustedImg = new ImageIcon(img);
		JButton button = new JButton("뒤로가기", adjustedImg);
		
		button.setBackground(Color.LIGHT_GRAY);
		button.setBorderPainted(false);
		button.setSize(150,50);
		button.setLocation(0,0);
		backButtonPanel.add(button);
		
		button.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				// TODO Auto-generated method stub
				mf.change("newsPanel");
			}
		});
		return backButtonPanel;
	}
}
