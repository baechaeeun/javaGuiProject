package buyApplicaion;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Iterator;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class PrintUser extends JPanel{
	
	public PrintUser(MainFrame mf) {
		setLayout(null);
		setBounds(0, 0, 500, 800);
		setSize(500,800);
		
		JLabel jl1=new JLabel("사용자 ID : "+mf.getUserManager().getUserNow().getId());
		jl1.setForeground(Color.blue);

		add(jl1,BorderLayout.NORTH);
		jl1.setBounds(220, 30, 500, 20);
		
		
		if(mf.getUserManager().getUserNow().getBuy().size()==0) {
			JLabel jl=new JLabel("주문 내역이 없습니다.");
			jl.setForeground(Color.blue);

			add(jl,BorderLayout.NORTH);
			jl.setBounds(220, 50+30*0, 500, 20);
			
			JLabel tmp=new JLabel("등급 : "+ mf.getUserManager().getUserNow().getLevel());
			add(tmp);
			tmp.setBounds(220, 50+30*1, 500, 20);
		}
		
		else {
			JLabel jl=new JLabel("주문 내역");
			jl.setForeground(Color.blue);

			add(jl,BorderLayout.NORTH);
			jl.setBounds(220, 10, 500, 20);
			
			int price=0;
			int i=0;
			
			Iterator it=mf.getUserManager().getUserNow().getBuy().keySet().iterator();
			Iterator it2=mf.getUserManager().getUserNow().getBuy().values().iterator();
			while(it.hasNext()) {
				JLabel tmp=new JLabel((String)it.next()+" : "+(int)it2.next());
				add(tmp);
				tmp.setBounds(220, 50+30*i, 500, 20);
				i++;
			}
			
			JLabel tmp=new JLabel("등급 : "+mf.getUserManager().getUserNow().getLevel());
			add(tmp);
			tmp.setBounds(220, 50+30*i, 500, 20);
			
		}
		
		
		JButton main =new JButton("이전화면으로");
		main.setBackground(Color.white);
		main.setBounds(0, 500,130,30);
		add(main);
		
		main.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				mf.change("mainPanel");
			}
		});
	}

}
