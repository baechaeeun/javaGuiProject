package buyApplicaion;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

public class Shop2_panel extends JPanel {
	
	public Shop2_panel(MainFrame mf) {
		setLayout(null);
		setBounds(0, 0, 500, 800);
		setSize(500,800);
		
		ImagePanel imagepanel = new ImagePanel((new ImageIcon("star2.png").getImage()));
		//imagepanel.setBounds(0, 100, 200, 400);
		imagepanel.setBackground(Color.white);
		
		JButton btnNewButton = new JButton("New button");
		btnNewButton.setBounds(156, 388, 183, 37);
		btnNewButton.setFont(new Font("한컴 백제 B", Font.PLAIN, 24));
		btnNewButton.setBackground(Color.WHITE);
		btnNewButton.setHorizontalAlignment(SwingConstants.CENTER);
		btnNewButton.setText("스타벅스 kh점");
		
		btnNewButton.setBorder(null);
		btnNewButton.setLayout(null);
		btnNewButton.setBorderPainted(false);
		btnNewButton.setContentAreaFilled(true);
		btnNewButton.setFocusPainted(false);
		add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("New button");
		btnNewButton_1.setBounds(89, 430, 297, 35);
		btnNewButton_1.setFont(new Font("한컴 백제 B", Font.PLAIN, 24));
		btnNewButton_1.setBackground(Color.WHITE);
		btnNewButton_1.setHorizontalAlignment(SwingConstants.CENTER);
		btnNewButton_1.setText("서울 강남구 테헤란로14길 6");
		btnNewButton_1.setBorder(null);
		btnNewButton_1.setLayout(null);
		btnNewButton_1.setFocusPainted(false);
		add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("주문하기");
		btnNewButton_2.setBounds(156, 605, 163, 37);
		btnNewButton_2.setFont(new Font("한컴 백제 B", Font.PLAIN, 24));
		add(btnNewButton_2);
		
		
		btnNewButton_2.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				mf.change("buyPanel");
			}
			
		});
		
		JButton back =new JButton("←메인화면으로");
		back.setBackground(Color.white);
		back.setBounds(0, 700,130,30);
		add(back);
		
		back.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				mf.change("mainPanel");
			}
		});
	add(imagepanel);
	}

}
