package buyApplicaion.b_app;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTable;


class ImagePanel extends JPanel{
	private Image img;
	
	public ImagePanel(Image img){
		this.img = img;
		setSize(new Dimension(img.getWidth(null),img.getHeight(null)));
		setPreferredSize(new Dimension(img.getWidth(null),img.getHeight(null)));
		setLayout(null);
	}
	
	public void paintComponent(Graphics g){
		g.drawImage(img, 0, 0, this);
	}
	
}

public class SearchPanel extends JPanel{
	
	
	private JButton star1_information;
	private JButton star2_information;
	private static Icon resizeIcon(ImageIcon icon, int resizedWidth, int resizedHeight) {
	       Image img = icon.getImage();  
	       Image resizedImage = img.getScaledInstance(resizedWidth, resizedHeight,  java.awt.Image.SCALE_SMOOTH);  
	       return new ImageIcon(resizedImage);
	}

	public SearchPanel(MainFrame mf) {

		setLayout(null);
		setBounds(0,0,500,800);
		setSize(500,800);
		
		ImagePanel SearchPanel = new ImagePanel(new ImageIcon("./image/map3.png").getImage());
		

		star2_information = new JButton("스타벅스 kh점");
		star2_information.setBackground(Color.white);
		star2_information.setFont(new Font("한컴 백제 M", Font.PLAIN, 16));
		star2_information.setBounds(40,560, 163, 37);
		star2_information.setFocusPainted(false);
		SearchPanel.add(star2_information);
		star2_information.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			mf.change("shop2_panel");
				
			}
		});
		

		
		JButton star1_btn = new JButton();
		ImageIcon icon = new ImageIcon("./image/icon.png");
		star1_btn.setLayout(null);
		star1_btn.setBorderPainted(false);
		star1_btn.setContentAreaFilled(false);
		star1_btn.setFocusPainted(false);
		star1_btn.setOpaque(false);
		star1_btn.setBounds(200, 400, 40, 40);
		int offset = star1_btn.getInsets().left;
		star1_btn.setIcon(resizeIcon(icon, star1_btn.getWidth() - offset, star1_btn.getHeight() - offset));

		SearchPanel.add(star1_btn);
		SearchPanel.setOpaque(false);
		
		JButton star2_btn = new JButton();
		ImageIcon icon1 = new ImageIcon("./image/icon.png");
		star2_btn.setLayout(null);
		star2_btn.setBorderPainted(false);
		star2_btn.setContentAreaFilled(false);
		star2_btn.setFocusPainted(false);
		star2_btn.setOpaque(false);
		star2_btn.setBounds(80, 600, 40, 40);
		int offset1 = star2_btn.getInsets().left;
		star2_btn.setIcon(resizeIcon(icon1, star2_btn.getWidth() - offset1, star2_btn.getHeight() - offset1));

		SearchPanel.add(star2_btn);
		SearchPanel.setOpaque(false);
		

		star1_information = new JButton("스타벅스 역삼역점");
		star1_information.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			mf.change("shop1_panel");
				
			}
		});
		star1_information.setBackground(new Color(255, 255, 255));
		star1_information.setFont(new Font("한컴 백제 M", Font.PLAIN, 16));
		star1_information.setBounds(140, 370, 163, 37);
		star1_information.setFocusPainted(false);
		SearchPanel.add(star1_information);
	
		
		
		JButton back =new JButton("←메인화면으로");
		back.setBackground(Color.white);
		back.setBounds(0, 700,130,30);
		add(back);
		
		back.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				mf.change("mainPanel");
			}
		});
		
		add(SearchPanel);
	

		
		
	}
}
