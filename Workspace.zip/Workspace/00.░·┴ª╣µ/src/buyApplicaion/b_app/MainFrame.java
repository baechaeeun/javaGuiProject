package buyApplicaion.b_app;


import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;

import buyApplicaion.BagList;
import buyApplicaion.Buy;
import buyApplicaion.BuyPanelCake;
import buyApplicaion.BuyPanelDrink;
import buyApplicaion.BuyPanelFood;
import buyApplicaion.BuyPanelItem;
import buyApplicaion.LoginOrAssign;
import buyApplicaion.MenuBag;
import buyApplicaion.MenuCloser;
import buyApplicaion.PrintUser;
import buyApplicaion.UserManager;

public class MainFrame extends JFrame{
	
	private static MainPanel mainPanel;
	private static BuyPanelDrink buyPanelDrink;
	private static BuyPanelCake buyPanelCake;
	private static BuyPanelFood buyPanelFood;
	private static BuyPanelItem buyPanelItem;
	private static MenuCloser menuCloser;
	private static UserManager userManager;
	private static LoginOrAssign loginOrAssign;
	private static PrintUser printUser;
	private static SearchPanel searchPanel;
	private static Shop1_panel shop1_panel;
	private static Shop2_panel shop2_panel;
	/*private static NewsPanel newsPanel;
	private static MembershipPannel membershipPanel;*/
	private static Buy buy;
	private static BagList bagList;
	private static ArrayList<MenuBag> menuBagList;

	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		MainFrame mf=new MainFrame();
		
		mf.mainPanel=new MainPanel(mf);
		mf.buyPanelDrink=new BuyPanelDrink(mf);
		mf.buyPanelFood=new BuyPanelFood(mf);
		mf.buyPanelItem=new BuyPanelItem(mf);
		mf.buyPanelCake=new BuyPanelCake(mf);
		mf.menuBagList=new ArrayList<MenuBag>();
		mf.userManager=new UserManager();
		mf.shop1_panel=new Shop1_panel(mf);
		mf.shop2_panel=new Shop2_panel(mf);
		mf.searchPanel=new SearchPanel(mf);
/*		mf.NewsPanel=new NewsPanel(mf);
		mf.MembershipPannel=new membershipPanel(mf);*/
		
		mf.add(new LoginOrAssign(mf));
		
		mf.setSize(500,800);
		mf.getContentPane().setLayout(null);
		mf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		mf.setVisible(true);

	}
	
	public static UserManager getUserManager() {
		return userManager;
	}

	public static void setUserManager(UserManager userManager) {
		MainFrame.userManager = userManager;
	}

	public void change(String panelName) {
		switch(panelName) {
		case "mainPanel":
			getContentPane().removeAll();
			getContentPane().add(mainPanel);
			revalidate();
			repaint();
			break;
			
		case "buyPanelDrink":
			getContentPane().removeAll();
			getContentPane().add(buyPanelDrink);
			revalidate();
			repaint();
			break;
			
		case "buyPanelFood":
			getContentPane().removeAll();
			getContentPane().add(buyPanelFood);
			revalidate();
			repaint();
			break;
			
		case "buyPanelItem":
			getContentPane().removeAll();
		getContentPane().add(buyPanelItem);
			revalidate();
			repaint();
			break;
			
		case "buyPanel":
			getContentPane().removeAll();
			getContentPane().add(buyPanelDrink);
			revalidate();
			repaint();
			break;
			
		case "buyPanelCake":
			getContentPane().removeAll();
			getContentPane().add(buyPanelCake);
			revalidate();
			repaint();
			break;
			
			
		case "SearchPanel":
			getContentPane().removeAll();
			getContentPane().add(searchPanel);
			revalidate();
			repaint();
			break;
	/*	case "NewsPanel":
			getContentPane().removeAll();
			getContentPane().add(NewsPanel);
			revalidate();
			repaint();
			break;
			
		case "MembershipPannel":
			getContentPane().removeAll();
			getContentPane().add(MembershipPannel);
			revalidate();
			repaint();
			break;*/
			
		case "buy":
			buy=new Buy(this);
			getContentPane().removeAll();
			getContentPane().add(buy);
			revalidate();
			repaint();
			break;
			
		case "bagList":
			bagList=new BagList(this.getMenuBagList(),this);
			getContentPane().removeAll();
			getContentPane().add(bagList);
			revalidate();
			repaint();
			break;
			
		case "loginOrAssign":
			loginOrAssign=new LoginOrAssign(this);
			getContentPane().removeAll();
			getContentPane().add(loginOrAssign);
			revalidate();
			repaint();
			break;
			
		case "login":
			getContentPane().removeAll();
			getContentPane().add(new Login(this));
			revalidate();
			repaint();
			break;
			
		case "assign":
			getContentPane().removeAll();
			getContentPane().add(new Assign(this));
			revalidate();
			repaint();
			break;
		case "printUser":
			getContentPane().removeAll();
			getContentPane().add(new PrintUser(this));
			revalidate();
			repaint();
			break;
		case "shop1_panel":
			getContentPane().removeAll();
			getContentPane().add(shop1_panel);
			revalidate();
			repaint();
			break;
		case "shop2_panel":
			getContentPane().removeAll();
			getContentPane().add(shop2_panel);
			revalidate();
			repaint();
			break;
		}
		
	}

	public void changeMenupan(String menu,int price) {
		
		menuCloser=new MenuCloser(menu,price,this);
		getContentPane().removeAll();
		getContentPane().add(menuCloser);
		revalidate();
		repaint();

	}

	public static ArrayList<MenuBag> getMenuBagList() {
		return menuBagList;
	}

	public static void setMenuBagList(ArrayList<MenuBag> menuBagList) {
		MainFrame.menuBagList = menuBagList;
	}
}
