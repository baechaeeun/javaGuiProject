package buyApplicaion.b_app;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

public class Shop1_panel extends JPanel {
	
	private JButton textField;
	private JButton textField_1;
	private JButton btnNewButton_5;
	
	public Shop1_panel(MainFrame mf) {
		
		setLayout(null);
		setBounds(0, 0, 500, 800);
		setSize(500,800);
	
	
	ImagePanel shop1_panel = new ImagePanel((new ImageIcon("./image/star1.png").getImage()));
	
	
	

	
	textField = new JButton();
	textField.setFont(new Font("한컴 백제 B", Font.PLAIN, 24));
	textField.setBackground(Color.WHITE);
	textField.setHorizontalAlignment(SwingConstants.CENTER);
	textField.setText("스타벅스 역삼역점");
	textField.setBounds(135, 489, 216, 35);
	textField.setBorder(null);
	textField.setLayout(null);
	textField.setBorderPainted(false);
	textField.setContentAreaFilled(true);
	textField.setFocusPainted(false);
	add(textField);
	
	
	textField_1 = new JButton();
	textField_1.setFont(new Font("한컴 백제 B", Font.PLAIN, 24));
	textField_1.setBackground(Color.WHITE);
	textField_1.setHorizontalAlignment(SwingConstants.CENTER);
	textField_1.setText("서울 강남구 테헤란로 211");
	textField_1.setBounds(89, 523, 297, 35);
	textField_1.setBorder(null);
	textField_1.setLayout(null);
	textField_1.setFocusPainted(false);
	add(textField_1);
	
	btnNewButton_5 = new JButton("주문하기");
	btnNewButton_5.setBounds(160, 615, 163, 37);
	btnNewButton_5.setFont(new Font("한컴 백제 B", Font.PLAIN, 24));
	add(btnNewButton_5);
	
	btnNewButton_5.addActionListener(new ActionListener() {

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			mf.change("buyPanel");
		}
		
	});
	JButton back =new JButton("←메인화면으로");
	back.setBackground(Color.white);
	back.setBounds(0, 700,130,30);
	add(back);
	
	back.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			mf.change("mainPanel");
		}
	});
	

	add(shop1_panel);
	}

}
