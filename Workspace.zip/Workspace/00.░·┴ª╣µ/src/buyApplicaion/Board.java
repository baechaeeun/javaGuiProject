package buyApplicaion;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Board implements Serializable {
	private int boardNo;
	private String boardTitle;
	private Date boardDate;
	private String boardContent;	
	private String currDate;
	
	public Board() {
		
	}

	public Board(int boardNo, String boardTitle, Date boardDate, String boardContent) {
		this.boardNo = boardNo;
		this.boardTitle = boardTitle;
		this.boardDate = boardDate;
		SimpleDateFormat ft = new SimpleDateFormat("yyyy-MM-dd");
		this.currDate = ft.format(boardDate);
		this.boardContent = boardContent;
	}

	public int getBoardNo() {
		return boardNo;
	}

	public void setBoardNo(int boardNo) {
		this.boardNo = boardNo;
	}

	public String getBoardTitle() {
		return boardTitle;
	}

	public void setBoardTitle(String boardTitle) {
		this.boardTitle = boardTitle;
	}


	public String getBoardDate() {
		String boardDateS = new SimpleDateFormat("yyyy-MM-dd").format(boardDate).toString();
		return boardDateS;
	}
	
	public void setBoardDate(Date boardDate) {
		this.boardDate = boardDate;
	}
	
	public String getBoardContent() {
		return boardContent;
	}

	public void setBoardContent(String boardContent) {
		this.boardContent = boardContent;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "[No:"+boardNo+", Title:"+boardTitle+", Date:"+currDate+"]";
	}
}
