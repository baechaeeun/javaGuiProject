package buyApplicaion;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;


public class BoardDao {
	private ArrayList<Board> list = new ArrayList<Board>();
	public BoardDao() {
		
	}

	public int getLastBoard() {
		//처음 게시글 리스트에 아무런 데이터가 없을 경우에는 글번호로 0을 반환
		//그렇지 않을 경우 새로운 정수 리스트를 만들어 리스트 내 게시글들의 번호를 모두 담아준 후 제일 큰 숫자를 찾아 반환
		int max = 0;
		if(list.isEmpty()) {
			return max;
		}
		else{
			for(Board b : list) {
				if(b.getBoardNo()>max) {
					max=b.getBoardNo();
				}
			}
		}
		return max;
	}

	public void writeBoard(Board board) {
		list.add(board);
	}
	
	public ArrayList<Board> displayAllList(){
		return list;
	}
	
	public Board displayBoard(int no) {
		return list.get(no);
	}
	
	
	public void modifyTitle(int no, String title) {
		System.out.println("변경할 타이틀 매개변수로 잘 받았나 확인 : "+title);
		//title 변경이 적용이 안되는 이유가 뭘까	
		list.get(no).setBoardTitle(title);
	}
	
	public void modifyContent(int no, String content) {
		//수정할 내용 content 지정되어야 함
		list.get(no).setBoardContent(content);
	}
	
	public void deleteBoard(int no) {
		list.remove(no);
		//해당 글 번호 뒤의 모든 번호들 -1씩 해줄 것
		for(int i= no;i<list.size();i++) {
			int currNo = list.get(i).getBoardNo();
			list.get(i).setBoardNo(--currNo);
		}
	}
	
	public ArrayList<Board> searchBoard(String title){
		ArrayList<Board> found = new ArrayList<Board>();
		for(Board b : list) {
			if(b.getBoardTitle().contains(title)) {
				found.add(b);
			}
		}
		return found;
	}
	public void saveListFile() {
		try {
			ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("board_list.dat"));
			for(int i=0;i<list.size();i++) {
				oos.writeObject(list.get(i));
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			System.out.println("저장이 완료되었습니다.");
		}
	}
}
