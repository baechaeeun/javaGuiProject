package buyApplicaion;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class Login extends JPanel{
	
	public Login(MainFrame mf) {
		
		setLayout(null);
		setBounds(0, 0, 500, 800);
		setSize(500,800);
		
		JLabel jl=new JLabel("로그인");
		jl.setForeground(Color.blue);

		add(jl,BorderLayout.NORTH);
		jl.setBounds(220, 10, 500, 20);
		
		JLabel jl1=new JLabel("ID : ");
		jl1.setForeground(Color.blue);

		add(jl1,BorderLayout.NORTH);
		jl1.setBounds(100, 50, 100, 20);
		
		JTextField ID=new JTextField();
		add(ID);
		ID.setBounds(250, 50, 100, 20);
		
		//****
		JLabel jl2=new JLabel("password : ");
		jl2.setForeground(Color.blue);

		add(jl2,BorderLayout.NORTH);
		jl2.setBounds(100, 100, 100, 20);
		
		JTextField password=new JTextField();
		add(password);
		password.setBounds(250, 100, 100, 20);
		
		JButton assign =new JButton("로그인");
		assign.setBackground(Color.white);
		assign.setBounds(350, 500,130,30);
		add(assign);
		
		assign.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(!mf.getUserManager().login(ID.getText(),password.getText())) {
					JOptionPane.showMessageDialog(null, "없는 아이디거나 비밀번호가 일치하지 않습니다.");
					mf.getUserManager().printList();
				}
				
				else {
					mf.change("mainPanel");
				}
			}
		});
		
		
		JButton main =new JButton("←뒤로가기");
		main.setBackground(Color.white);
		main.setBounds(0, 500,130,30);
		add(main);
		
		main.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				mf.change("loginOrAssign");
			}
		});
	}

}
