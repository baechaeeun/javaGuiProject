package buyApplicaion;

import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class MainFrame extends JFrame{
	
	private static MainPanel mainPanel;
	private static BuyPanelDrink buyPanelDrink;
	private static BuyPanelCake buyPanelCake;
	private static BuyPanelFood buyPanelFood;
	private static BuyPanelItem buyPanelItem;
	private static MenuCloser menuCloser;
	private static UserManager userManager;
	private static LoginOrAssign loginOrAssign;
	private static PrintUser printUser;
	/*private static SearchPanel searchPanel;
	private static NewsPanel newsPanel; */
	private static Myreward myReward; //멤버쉽
	private static RewardHistory1 rewardHistory; //멤버쉽2
	private static Buy buy;
	private static BagList bagList;
	private static ArrayList<MenuBag> menuBagList;
	private static NewsPanel newsPanel;
	private static Board board;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*
		 * BoardManager bm = new BoardManager(); bm.writeBoard(); bm.saveListFile();
		 */
		MainFrame mf=new MainFrame();
		
		mf.mainPanel=new MainPanel(mf);
		mf.buyPanelDrink=new BuyPanelDrink(mf);
		mf.buyPanelFood=new BuyPanelFood(mf);
		mf.buyPanelItem=new BuyPanelItem(mf);
		mf.buyPanelCake=new BuyPanelCake(mf);
		mf.menuBagList=new ArrayList<MenuBag>();
		mf.userManager=new UserManager();
		//mf.myReward = new Myreward(mf);  //멤버쉽1
		//mf.rewardHistory = new RewardHistory1(mf);  //멤버쉽2
		
		/*mf.SearchPanel=new SearchPanel(mf);
		mf.NewsPanel=new NewsPanel(mf); 
		*/
	
		
		mf.add(new LoginOrAssign(mf));
		
		mf.setSize(500,800);
		mf.getContentPane().setLayout(null);
		mf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		mf.setVisible(true);

	}
	
	public static UserManager getUserManager() {
		return userManager;
	}

	public static void setUserManager(UserManager userManager) {
		MainFrame.userManager = userManager;
	}

	public void change(String panelName) { //화면전환
		switch(panelName) {
		case "mainPanel":
			getContentPane().removeAll();
			getContentPane().add(mainPanel);
			revalidate();
			repaint();
			break;
			
		case "buyPanelDrink":
			getContentPane().removeAll();
			getContentPane().add(buyPanelDrink);
			revalidate();
			repaint();
			break;
			
		case "buyPanelFood":
			getContentPane().removeAll();
			getContentPane().add(buyPanelFood);
			revalidate();
			repaint();
			break;
			
		case "buyPanelItem":
			getContentPane().removeAll();
			getContentPane().add(buyPanelItem);
			revalidate();
			repaint();
			break;
			
		case "buyPanel":
			getContentPane().removeAll();
			getContentPane().add(buyPanelDrink);
			revalidate();
			repaint();
			break;
			
		case "buyPanelCake":
			getContentPane().removeAll();
			getContentPane().add(buyPanelCake);
			revalidate();
			repaint();
			break;
			
			
		/*case "SearchPanel":
			getContentPane().removeAll();
			getContentPane().add(SearchPanel);
			revalidate();
			repaint();
			break;
		case "NewsPanel":
			getContentPane().removeAll();
			getContentPane().add(NewsPanel);
			revalidate();
			repaint();
			break; */
			
		case "myReward":  //멤버쉽1 화면전환
			getContentPane().removeAll();
			getContentPane().add(new Myreward(this));
			revalidate();
			repaint();
			break;
		
		case "RewardHistory": //멤버쉽2 화면전환
			getContentPane().removeAll();
			getContentPane().add(new RewardHistory(this));
			revalidate();
			repaint();
			break;	
			
		case "buy":
			buy=new Buy(this);
			getContentPane().removeAll();
			getContentPane().add(buy);
			revalidate();
			repaint();
			break;
			
		case "bagList":
			bagList=new BagList(this.getMenuBagList(),this);
			getContentPane().removeAll();
			getContentPane().add(bagList);
			revalidate();
			repaint();
			break;
			
		case "loginOrAssign":
			loginOrAssign=new LoginOrAssign(this);
			getContentPane().removeAll();
			getContentPane().add(loginOrAssign);
			revalidate();
			repaint();
			break;
			
		case "login":
			getContentPane().removeAll();
			getContentPane().add(new Login(this));
			revalidate();
			repaint();
			break;
			
		case "assign":
			getContentPane().removeAll();
			getContentPane().add(new Assign(this));
			revalidate();
			repaint();
			break;
		case "printUser":
			getContentPane().removeAll();
			getContentPane().add(new PrintUser(this));
			revalidate();
			repaint();
			break;
		case "newsPanel":
			getContentPane().removeAll();
			getContentPane().add(new NewsPanel(this));
			revalidate();
			repaint();
			break;
		case "contentViewPanel":
			getContentPane().removeAll();
			getContentPane().add(new ContentViewPanel(this,board));
			revalidate();
			repaint();
			break;
		case "shop1_panel":
			getContentPane().removeAll();
			getContentPane().add(new Shop1_panel(this));
			revalidate();
			repaint();
			break;
		case "shop2_panel":
			getContentPane().removeAll();
			getContentPane().add(new Shop2_panel(this));
			revalidate();
			repaint();
			break;
		case "SearchPanel":
			getContentPane().removeAll();
			getContentPane().add(new SearchPanel(this));
			revalidate();
			repaint();
			break;
		}
		
	}
	
	public void setBoard(Board board) {
		this.board = board;
	}
	public void changeMenupan(String menu,int price) {
		
		menuCloser=new MenuCloser(menu,price,this);
		getContentPane().removeAll();
		getContentPane().add(menuCloser);
		revalidate();
		repaint();

	}

	public static ArrayList<MenuBag> getMenuBagList() {
		return menuBagList;
	}

	public static void setMenuBagList(ArrayList<MenuBag> menuBagList) {
		MainFrame.menuBagList = menuBagList;
	}
}
