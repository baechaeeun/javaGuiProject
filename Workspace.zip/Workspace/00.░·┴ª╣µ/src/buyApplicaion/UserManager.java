package buyApplicaion;

import java.util.ArrayList;
import java.util.Iterator;

public class UserManager {
	
	private static ArrayList<Users> userList;
	private static Users userNow;
	private static int userNum;
	
	public UserManager() {
		userList=new ArrayList<Users>();
		userNow=null;
		userNum=0;
	}

	public static ArrayList<Users> getUserList() {
		return userList;
	}

	public static void setUserList(ArrayList<Users> userList) {
		UserManager.userList = userList;
	}

	public static Users getUserNow() {
		return userNow;
	}

	public static void setUserNow(Users userNow) {
		UserManager.userNow = userNow;
	}
	
	public static void plusUser(Users userNow) {
		userList.add(userNow);
		userNum++;
	}
	
	public static boolean login(String id, String password) {
		
		for(Users u:userList) {
			if(id.equals(u.getId())) {
				if(password.equals(u.getPassword())) {
					userNow=u;
					return true;
				}
			}
		}
		
		return false;
	}
	
	public static void printList() {
		for(Users u:userList) {
			System.out.print(u.getId()+ " "+u.getPassword());
			System.out.println();
		}
	}
	
	public static void renewBuy(String name) {
		
		//음료당 주문 건수 갱신
		if(userNow.getBuy().containsKey(name)){
			userNow.getBuy().put(name,userNow.getBuy().get(name)+1);
		}
		else {
			userNow.getBuy().put(name,1);
		}
		
		//등급 올리기
		int num=0;
		Iterator it=userNow.getBuy().values().iterator();
		while(it.hasNext()) {
			num+=(int)it.next();
		}
		
		if(num<10) {
			userNow.setLevel("silver");
		}
		else if(num>=10&&num<20) {
			userNow.setLevel("gold");
		}
		else if(num>=20&&num<30) {
			userNow.setLevel("vip");
		}
		else if(num>=30&&num<40) {
			userNow.setLevel("vvip");
		}
	}
	
	public static void printUser() {
		
		Iterator it=userNow.getBuy().keySet().iterator();
		Iterator it2=userNow.getBuy().values().iterator();
		while(it.hasNext()) {
			System.out.println((String)it.next()+" : "+(int)it2.next());
		}
		System.out.println("등급 : "+userNow.getLevel());
	}
	
public static void rewardHistory() {
		
		Iterator it=userNow.getBuy().keySet().iterator();
		Iterator it2=userNow.getBuy().values().iterator();
		while(it.hasNext()) {
			System.out.println((String)it.next()+" : "+(int)it2.next());
		}
		System.out.println("등급 : "+userNow.getLevel());
	}

public static void myRreward() {
	
	Iterator it=userNow.getBuy().keySet().iterator();
	Iterator it2=userNow.getBuy().values().iterator();
	while(it.hasNext()) {
		System.out.println((String)it.next()+" : "+(int)it2.next());
	}
	System.out.println("등급 : "+userNow.getLevel());
}

	

}
