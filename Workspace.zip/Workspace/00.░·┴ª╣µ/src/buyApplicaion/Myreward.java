package buyApplicaion;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Iterator;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;



public class Myreward extends JPanel{
		
	public Myreward(MainFrame mf) {
		setLayout(null);
		setBounds(0, 0, 500, 800);
		setSize(500,800);
		
		JLabel jl2=new JLabel("멤버쉽 관리");
		jl2.setForeground(Color.blue);
		add(jl2,BorderLayout.NORTH);
		jl2.setBounds(220, 50, 500, 20);
		
		JButton b11=new JButton("나의멤버쉽");
		b11.setBackground(Color.white);
		add(b11);
		b11.setBounds(50,80,200,30);
		
		JButton b12=new JButton("history");
		b12.setBackground(Color.white);
		b12.setBounds(250,80,200,30);
		add(b12);
	
	
		
		b11.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				mf.change("myReward");
			}
		});
		b12.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				mf.change("RewardHistory");
				
			}
		});
		
	
		JPanel jp01 = new JPanel();
		jp01.setBounds(0,150,500,50);

		JLabel label01 = new JLabel(mf.getUserManager().getUserNow().getId()+  "님은" );
		label01.setBounds(100, 160, 400, 20);
		JLabel label02 = new JLabel(mf.getUserManager().getUserNow().getLevel()+ "회원 입니다." );
		label02.setBounds(100, 200, 400, 20);
		
		label01.setBackground(Color.white);
		jp01.setPreferredSize(new Dimension(500,50));
		add(label01);
		add(label02);
		this.add(jp01);
		
		JLabel label1 = new JLabel("- 회원등급 안내-");
		label1.setBounds(180, 220, 444, 77);
		add(label1);
		
		JTextArea textArea = new JTextArea();
		textArea.setText("1. 회원등급은 총 4가지로 나뉘어져 있습니다. \n (silver, gold, vip, vvip) "
				+ "\n 2. 신규회원은 silver 등급입니다."
				+ "\n 3.음료를 기준으로 10잔 적립시 마다 회원등급이 올라갑니다. \n "
				+ "4. 회원 승급은 다음날 00시 기준으로 승급됩니다.");
		textArea.setBounds(30, 280, 510, 150);
		add(textArea);
		
			
			
		JButton back =new JButton("←메인화면으로");
		back.setBackground(Color.white);
		back.setBounds(10, 500,130,30);
		add(back);
		
		back.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				mf.change("mainPanel");
			}
		});
		
		
		
	
	}
		
	}
	
