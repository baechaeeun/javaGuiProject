package buyApplicaion;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Tmp extends JPanel{
	
	public Tmp(MainFrame mf) {
		
		setLayout(null);
		setBounds(0, 0, 500, 800);
		setSize(500,800);
		
		JLabel jl2=new JLabel("멤버쉽 관리");
		jl2.setForeground(Color.blue);
		add(jl2,BorderLayout.NORTH);
		jl2.setBounds(220, 50, 500, 20);
		
		JButton b11=new JButton("나의멤버쉽");
		b11.setBackground(Color.white);
		add(b11);
		b11.setBounds(50,80,200,30);
		
		JButton b12=new JButton("history");
		b12.setBackground(Color.white);
		b12.setBounds(250,80,200,30);
		add(b12);
		
		b11.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				mf.change("myReward");
			}
		});
		b12.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				mf.change("rewardHistory");
				
			}
		});
		
		
	}

}
