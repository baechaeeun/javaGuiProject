package buyApplicaion;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class LoginOrAssign extends JPanel{
	
	public LoginOrAssign(MainFrame mf) {
		
		setLayout(null);
		setBounds(0, 0, 500, 800);
		setSize(500,800);
		
		JLabel jl=new JLabel("로그인/회원가입");
		jl.setForeground(Color.blue);

		add(jl,BorderLayout.NORTH);
		jl.setBounds(220, 10, 500, 20);
		
		JButton login =new JButton("로그인");
		login.setBackground(Color.white);
		login.setBounds(100, 100,130,30);
		add(login);
		
		login.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				mf.change("login");
			}
		});
		
		JButton assign =new JButton("회원가입");
		assign.setBackground(Color.white);
		assign.setBounds(300, 100,130,30);
		add(assign);
		
		assign.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				mf.change("assign");
			}
		});
	}

}
