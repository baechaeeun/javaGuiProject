package buyApplicaion;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;


public class NewsPanel extends JPanel{	
	private JPanel titlePanel;
	private JPanel contentList;
	private JPanel searchPanel;
	private JPanel sortPanel;
	private MainFrame mf;

	private ArrayList<Board>contents;

	private String keyword;
	private String sortSelected;
	
	public NewsPanel(MainFrame mf) {
		this.mf = mf;
		setLayout(null);
		setSize(500, 800);
		
		add(titlePanel = drawTitle());
		titlePanel.setLocation(100, 50);
		
		setContentList(); //역직렬화한 콘텐츠 리스트로 contents 배열리스트 초기화
		add(contentList = drawContentList());
		contentList.setLocation(50,130);
		System.out.println(contents);
		add(searchPanel = drawSearchBox());
		searchPanel.setLocation(140, 500);
		
		add(sortPanel = drawSortBox());
		sortPanel.setLocation(60, 500);	
		
		System.out.println("패널 모두 생성 완료");
		
		JButton main =new JButton("←메인화면으로");
		main.setBackground(Color.white);
		main.setBounds(30, 550,130,30);
		add(main);
		
		main.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				mf.change("mainPanel");
			}
		});
	}
	
	public JPanel drawSortBox() {
		sortPanel = new JPanel();
		String[] options = {"전체","제목","내용"};
		JComboBox<String> sortOption = new JComboBox<String>(options);
		sortOption.setBackground(Color.white);
		sortOption.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				JComboBox box = (JComboBox)e.getSource();
				sortSelected = (String)box.getSelectedItem();
				System.out.println(sortSelected+" 옵션이 선택됨");
			}
		});
		sortPanel.add(sortOption);
		sortPanel.setSize(100, 100);
		
		return sortPanel;
	}
	
	public ArrayList<Board> titleSearch(String keyword) {
		setContentList();
		ArrayList<Board> found = new ArrayList<Board>();
		for(Board b : contents) {
			if(b.getBoardTitle().contains(keyword)) {
				found.add(b);
			}
		}
		return found;
		
	}
	public ArrayList<Board> contentSearch(String keyword) {
		setContentList();
		ArrayList<Board> found = new ArrayList<Board>();
		for(Board b : contents) {
			if(b.getBoardContent().contains(keyword)) {
				found.add(b);
			}
		}
		return found;
	}
	public ArrayList<Board> allKeywordsSearch(String keyword) {
		ArrayList<Board> found = new ArrayList<Board>();
		for(Board b : contents) {
			if(b.getBoardTitle().contains(keyword)||b.getBoardContent().contains(keyword)) {
				found.add(b);
			}
		}
		return found;
	}
	
	public JPanel drawSearchBox() {
		searchPanel = new JPanel();
		
		JTextField searchArea = new JTextField(15);
		JButton searchButton = new JButton("검색");
		searchButton.setSize(10,10);
		
		searchArea.addKeyListener(new KeyAdapter() {
			public void keyReleased(KeyEvent e) {
				keyword = searchArea.getText();
			}			
		});
		
		searchButton.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				if(sortSelected == null) {
					sortSelected = "전체";
					System.out.println("Current Selected : "+sortSelected);
				}
				else if(sortSelected.equals("제목")) {
					System.out.println("Current Selected : "+sortSelected);
					contents.clear();
					contents = titleSearch(keyword);
					System.out.println("입력 내용 : " + keyword);
					System.out.println("결과 : "+contents);
					contentList.removeAll();
					for(int i=0;i<contents.size();i++) {
						JButton newButton = new JButton(contents.get(i).toString()); 
						newButton.setPreferredSize(new Dimension(280, 28));
						newButton.setBackground(Color.white);
						newButton.setBorderPainted(false);
						newButton.setForeground(Color.black);
						newButton.setFont(new Font("휴먼모음T",Font.BOLD,10));
						int contentNum = i;
						newButton.addMouseListener(new MouseAdapter() {
							@Override
							public void mouseClicked(MouseEvent e) {
								// TODO Auto-generated method stub
								mf.setBoard(contents.get(contentNum));
								mf.change("contentViewPanel");
							}
						});
						contentList.add(newButton);
					}
					contentList.repaint();
					contentList.revalidate();
				}
				else if(sortSelected.equals("내용")) {
					System.out.println("Current Selected : "+sortSelected);
					contents.clear();
					contents = contentSearch(keyword);
					System.out.println("입력 내용 : "+keyword);
					contents = contentSearch(keyword);
					System.out.println("결과 : "+contents);
					
					contentList.removeAll();
					for(int i=0;i<contents.size();i++) {
						JButton newButton = new JButton(contents.get(i).toString()); 
						newButton.setPreferredSize(new Dimension(280, 28));
						newButton.setBackground(Color.white);
						newButton.setBorderPainted(false);
						newButton.setForeground(Color.black);
						newButton.setFont(new Font("휴먼모음T",Font.BOLD,10));
						int contentNum = i;
						newButton.addMouseListener(new MouseAdapter() {
							@Override
							public void mouseClicked(MouseEvent e) {
								// TODO Auto-generated method stub
								mf.setBoard(contents.get(contentNum));
								mf.change("contentViewPanel");
							}
						});
						contentList.add(newButton);
					}
					contentList.repaint();
					contentList.revalidate();
				}
				else {
					//전체 옵션 선택되었을 경우
					System.out.println("Current Selected : "+sortSelected);
					contents.clear();
					contents = allKeywordsSearch(keyword);
					System.out.println("입력 내용 : "+keyword);
					contents = contentSearch(keyword);
					System.out.println("결과 : "+contents);
					
					contentList.removeAll();
					for(int i=0;i<contents.size();i++) {
						JButton newButton = new JButton(contents.get(i).toString()); 
						newButton.setPreferredSize(new Dimension(280, 28));
						newButton.setBackground(Color.white);
						newButton.setBorderPainted(false);
						newButton.setForeground(Color.black);
						newButton.setFont(new Font("휴먼모음T",Font.BOLD,10));
						int contentNum = i;
						newButton.addMouseListener(new MouseAdapter() {
							@Override
							public void mouseClicked(MouseEvent e) {
								// TODO Auto-generated method stub
								mf.setBoard(contents.get(contentNum));
								mf.change("contentViewPanel");
							}
						});
						contentList.add(newButton);
					}
					contentList.repaint();
					contentList.revalidate();
				}
			}
		});
		
		searchPanel.add(searchArea);
		searchPanel.add(searchButton);
		searchPanel.setSize(250, 30);
	
		return searchPanel;
	}
	
	public JPanel drawTitle() {
		titlePanel = new JPanel();			
		JLabel title = new JLabel("공지사항");
		title.setForeground(Color.BLACK);
		title.setFont(new Font("Serif",Font.BOLD,40));
		
		Image img = new ImageIcon("boardIcon.png").getImage().getScaledInstance(30, 30, Image.SCALE_SMOOTH);
		JLabel boardImg = new JLabel(new ImageIcon(img));
		
		titlePanel.add(title);
		titlePanel.add(boardImg);
		titlePanel.setSize(250, 60);
		return titlePanel;
	}
	
	public void setContentList() {
		//역직렬화를 통해 게시판 콘텐츠 내용 불러오기
		this.contents = new ArrayList<Board>(); 
		ObjectInputStream ois;
		
		try {
			ois = new ObjectInputStream(new FileInputStream("board_list.dat"));
			int k=0;
			while(true) {
				contents.add((Board)ois.readObject());
				System.out.println(contents.get(k));
				k++;
			}
		} catch (IOException e) {
			System.out.println("IOException 발생");
		} catch (ClassNotFoundException e) {
			System.out.println("ClassNotFoundException 발생");
		} finally {
			//혹시나 콘텐츠 배열리스트 역직렬화 꼬여서 리스트 비어있으면 오류 출력
			if(contents.isEmpty()) {
				System.out.println("불러오기 오류");
			}
			else {
				System.out.println("불러오기 완료");
			}
			
		}
	}
	
	public JPanel drawContentList() {
		JPanel listPanel = new JPanel();
		listPanel.setSize(400,340);
		listPanel.setBackground(Color.white);
		JButton[] titleClickButtons = new JButton[contents.size()];
			for(int i=0;i<contents.size();i++) {
				JButton titleClick =  new JButton(contents.get(i).toString());
				titleClick.setPreferredSize(new Dimension(300, 28));
				titleClick.setBackground(Color.white);
				titleClick.setBorderPainted(false);
				titleClick.setForeground(Color.black);
				titleClick.setFont(new Font("휴먼모음T",Font.BOLD,10));
				titleClickButtons[i] = titleClick;
				int contentNum=contents.get(i).getBoardNo()-1;
				titleClickButtons[i].addMouseListener(new MouseAdapter() {
					@Override
					public void mouseClicked(MouseEvent e) {
						// TODO Auto-generated method stub
						mf.setBoard(contents.get(contentNum));
						mf.change("contentViewPanel");
					}
				});
				listPanel.add(titleClick);
			}
		return listPanel;
	}
}
