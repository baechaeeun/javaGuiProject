package buyApplicaion;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.Scanner;

import buyApplicaion.board.dao.BoardDao;
import buyApplicaion.board.model.Board;


public class BoardManager {
	private BoardDao bd = new BoardDao();
	private Scanner sc = new Scanner(System.in);
	public BoardManager() {
		
	}
	public void writeBoard() {
		int howMany = 0;
		while(howMany<10) {
			System.out.println("새 게시글 쓰기 입니다.");
			System.out.print("글 제목 : ");
			String title = sc.nextLine();
			
			Date date = new Date();
			SimpleDateFormat ft = new SimpleDateFormat("yyyy-MM-dd");
			String currDate = ft.format(date);
			System.out.println("작성 날짜 : "+currDate);
			
			StringBuilder sb = new StringBuilder();
			String currLine = null;
			System.out.println("글 내용 : ");
			
			while(true) {
				System.out.print("==>");
				currLine = sc.nextLine();
				if(currLine.equals("exit")) {
					break;
				}
				sb.append(currLine+"\n");
			}

			String content = sb.toString();
			int lastNum = bd.getLastBoard();
			bd.writeBoard(new Board(lastNum+1,title,date,content));
			
			howMany++;
		}
	}
	
	public void displayAllList() {
		Iterator it = bd.displayAllList().iterator();
		while(it.hasNext()) {
			System.out.println(it.next());
		}
	}
	
	public void displayBoard() {
		System.out.print("조회할 글 번호 : ");
		int no = sc.nextInt();
		//1번 글은 0번째 인덱스에 위치하기 때문에 실제로 들어갈 글번호 매개변수는 입력값-1로 받아줌
		//검색결과가 없는 경우는 IndexOutOfBoundsException 예외로 간주하여 예외처리
		try {
			Board temp = bd.displayBoard(no-1);
			System.out.println(temp);
		}catch(IndexOutOfBoundsException e){
			System.out.println("검색 결과가 없습니다.");
		}finally {
			sc.nextLine();
		}
	}
	
	public void modifyTitle() {
		System.out.print("수정할 글 번호 : ");
		int no = sc.nextInt();
		//마찬가지로 n번째 글의 인덱스 넘버는 n-1인 것에 주의
		try {
			bd.displayBoard(no-1);
			Board temp = bd.displayBoard(no-1);
			System.out.println("현재 글 제목 : "+ temp.getBoardTitle());		
		}catch(IndexOutOfBoundsException e) {
			System.out.println("조회된 글이 없습니다.");
			return;
			//오류 발생 : return 실행 후 다시 새로 글쓰기 1번메뉴 하면 버퍼가 꼬이는 문제 발생
			//이 경우 남아있던 버퍼가 글 제목 입력 부분을 먹어버린 것 같음
		}finally {
			sc.nextLine();
		}
		System.out.print("변경할 글 제목 : ");
		//원래 title 입력 후 sc.nextLine()을 했더니 bd.modifyTitle(no-1,title)에 들어갈 매개변수 title이 null이 되는 문제가 발생
		//예외 처리 구문의 finally{} 부분에 sc.nextLine();을 혹시나 해서 넣어봤더니 해결되었는데 이유를 잘 모르겠음...
		String title = sc.nextLine();
		bd.modifyTitle(no-1, title);
	}
	
	public void modifyContent() {
		System.out.print("수정할 글 번호 : ");
		int no = sc.nextInt();
		//마찬가지로 n번째 글의 인덱스 넘버는 n-1인 것에 주의
		try {
			bd.displayBoard(no-1);
			Board temp = bd.displayBoard(no-1);
			System.out.println("현재 글 내용 : \n"+ temp.getBoardContent());		
		}catch(IndexOutOfBoundsException e) {
			System.out.println("조회된 글이 없습니다.");
			return;
		}finally {
			sc.nextLine();
		}
		StringBuilder sb = new StringBuilder();
		String currLine = null;
		System.out.println("변경할 글 내용 : ");
		while(true) {
			System.out.print("==>");
			currLine = sc.nextLine();
			if(currLine.equals("exit")) {
				break;
			}
			sb.append(currLine+"\n");
		}

		String content = sb.toString();
		bd.modifyContent(no-1, content);
		//없을 경우 조회된 글이 없습니다 출력 어떻게?
	}
	
	public void deleteBoard() {
		System.out.print("삭제할 글 번호 : ");
		int no = sc.nextInt();
		sc.nextLine();
		
		System.out.println("해당 글 조회 : ");
		System.out.println(bd.displayBoard(no-1));
		while(true) {
			System.out.print("정말로 삭제하시겠습니까?(y/n) : ");
			char select = sc.nextLine().charAt(0);	
			if(select=='Y'||select=='y') {
				System.out.println("해당 글을 삭제합니다.");
				bd.deleteBoard(no-1);
				break;
			}
			else if(select=='n'||select=='N') {
				System.out.println("삭제 안함");
				break;
			}
			else {
				System.out.println("다시 입력하세요");
			}
		}
	}
	
	public void searchBoard() {
		System.out.print("검색할 제목 : ");
		String title = sc.nextLine();
		bd.searchBoard(title);
		ArrayList<Board>found = bd.searchBoard(title);
		System.out.println("검색 결과 : ");
		if(found.isEmpty()) {
			System.out.println("검색 결과가 없습니다.");
		}
		else {
			for(Board b : found) {
				System.out.println(b);
			}
		}
	}
	
	public void saveListFile() {
		bd.saveListFile();
	}
	
	/*
	 * public void sortList(int item, boolean isDesc) { ArrayList<Board> forSort =
	 * new ArrayList<Board>(); forSort.addAll(bd.displayAllList()); //먼저 모든 배열을 보여주기
	 * switch(item) { case 1: //번호순 정렬 if(isDesc==false) { //오름차순
	 * Collections.sort(forSort,new AscBoardNo()); for(Board b : forSort) {
	 * System.out.println(b); } } else { //내림차순 Collections.sort(forSort,new
	 * DescBoardNo()); for(Board b : forSort) { System.out.println(b); } } break;
	 * case 2: //날짜순 정렬 if(isDesc==false) { Collections.sort(forSort,new
	 * AscBoardDate()); for(Board b : forSort) { System.out.println(b); } } else {
	 * Collections.sort(forSort,new DescBoardDate()); for(Board b : forSort) {
	 * System.out.println(b); } } break; case 3: //제목 순서대로 정렬 if(isDesc==false) {
	 * Collections.sort(forSort,new AscBoardTitle()); for(Board b : forSort) {
	 * System.out.println(b); } } else { Collections.sort(forSort,new
	 * DescBoardTitle()); for(Board b : forSort) { System.out.println(b); } } break;
	 * } }
	 */
}
