package com.kh.chap03_event.part03_changePanel;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class MainFrame extends JFrame{
	//패널두개를 준비해서 패널 교체 (마우스 클릭)
	
	JPanel panel;
	
	public MainFrame() {
		this.setSize(300,200);
		this.setTitle("패널바꾸기");
		
		//파란색 패널 객체 만들기
		panel = new Panel1();
		
		//패널에 이벤트적용(익명클래스)
		panel.addMouseListener(new MouseAdapter() {

			@Override
			public void mouseClicked(MouseEvent e) {
				// TODO Auto-generated method stub
				replace(); //패널을 바꿔줄 기능을 구현한 메소드
			}
			
		});
		
		this.add(panel);
		
		this.setVisible(true);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		
	}
	protected void replace() {
		this.remove(panel);//기존의 파란 패널을 삭제
		this.panel=callPanel2();
		this.add(panel);//노란색 패널 객체를 프레임 부착
		
		this.repaint(); //repaint()메소드를 반드시 실행해야 패널이 바뀜
		
		
		
	}
	private JPanel callPanel2() {
		// TODO Auto-generated method stub
		return new Panel2();
	}
	public static void main(String[] args) {
		new MainFrame();
		

	}

}
