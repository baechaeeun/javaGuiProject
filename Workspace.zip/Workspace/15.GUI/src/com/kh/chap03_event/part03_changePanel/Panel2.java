package com.kh.chap03_event.part03_changePanel;

import java.awt.Color;

import javax.swing.JPanel;

public class Panel2 extends JPanel{
	
	public Panel2() {
		this.setSize(300,200);
		this.setBackground(Color.yellow);
	}
}
