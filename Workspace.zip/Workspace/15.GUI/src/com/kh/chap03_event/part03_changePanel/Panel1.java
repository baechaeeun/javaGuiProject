package com.kh.chap03_event.part03_changePanel;

import java.awt.Color;

import javax.swing.JPanel;

public class Panel1 extends JPanel{
	
	public Panel1() {
		this.setSize(300,200);
		this.setBackground(Color.blue);
		
		
	}

}
