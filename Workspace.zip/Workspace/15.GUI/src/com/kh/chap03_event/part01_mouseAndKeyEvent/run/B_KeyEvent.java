package com.kh.chap03_event.part01_mouseAndKeyEvent.run;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JFrame;
import javax.swing.JTextField;

public class B_KeyEvent extends JFrame implements KeyListener{
//3. 프레임 상속받고 인터페이스 임플리먼츠하여 구현
	
	public B_KeyEvent() {
		super("이벤트예제");
		this.setSize(300,200);
		this.setLayout(null);
		
		//textfield컴포넌트활용
		JTextField tf=new JTextField();
		tf.setSize(100, 50);
		
		//textfield에 KeyListener 연결
		tf.addKeyListener(this);
		
		//컨테이너에 컴포넌트 붙이기
		this.add(tf);
		
		this.setVisible(true);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new B_KeyEvent();

	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		System.out.println("유니코드 키인 경우 누른 키를 떼는 순간");
	}

	@Override
	public void keyPressed(KeyEvent e) {
		System.out.println("키보드 치는 중입니다.");
		System.out.println(e.isShiftDown());
		System.out.println(e.isControlDown());
		
		if(e.getKeyChar()=='q') {
			System.exit(0); //0일 경우 정상종료, 1일 경우 비정상종료
		}
		
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		System.out.println("키가 떼어질때");
	}

}
