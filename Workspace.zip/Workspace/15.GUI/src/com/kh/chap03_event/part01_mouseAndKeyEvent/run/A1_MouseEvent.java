package com.kh.chap03_event.part01_mouseAndKeyEvent.run;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class A1_MouseEvent extends MouseAdapter{
	//2. 마우스 어댑터를 상속받을때
	
	public A1_MouseEvent() {
		JFrame jf = new JFrame();
		jf.setTitle("Mouse Event");
		jf.setSize(300,200);
		
		JPanel panel = new JPanel();
		panel.addMouseListener(this);
		
		
		jf.add(panel);
		jf.setVisible(true);
		jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	
	}
	
	
	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		System.out.println("MousePressed :"+e.getClickCount()+
				"x = "+e.getX()+",y = "+e.getY()
				+" 클릭버튼 "+e.getButton());
	}


	public static void main(String[] args) {
		// TODO Auto-generated method stub

		new A1_MouseEvent();
	}

}
