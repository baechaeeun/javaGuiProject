package com.kh.chap03_event.part01_mouseAndKeyEvent.run;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class A_MouseEvent implements MouseListener{
	//1. 별도의 클래스로 리스너 인터페이스 구현
	
	public A_MouseEvent() {
		
		//컨테이너만들기
		JFrame jf=new JFrame();
		jf.setTitle("Mouse Event"); //제목
		jf.setSize(300,200); //크기
		
		//패널 만들기
		JPanel panel = new JPanel();
		
		//컴포넌트에 이벤트리스너 연결
		panel.addMouseListener(this);
		
		//컨테이너에 패널붙이기
		jf.add(panel);
		
		
		jf.setVisible(true);
		jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	
	public static void main(String[] args) {
		new A_MouseEvent();

	}

	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		System.out.println("Mouse clicked :"+e.getClickCount()+
				"x = "+e.getX()+",y = "+e.getY()
				+" 클릭버튼"+e.getButton());
	}

	@Override
	public void mousePressed(MouseEvent e) {
		System.out.println("누를때");
		this.display("마우스 클릭 수 : "+e.getClickCount(), e);
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		System.out.println("뗄때");
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		System.out.println("Mouse entered :"+e.getClickCount()+
				"x = "+e.getX()+",y = "+e.getY()
				+" 클릭버튼"+e.getButton());
	}
	
	public void display(String s,MouseEvent e) {
		System.out.println(s+"x = "+e.getX()+",y = "+e.getY());
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		System.out.println("빠져나갈때");
	}

}
