package com.kh.chap02_layout.view;

import java.awt.CardLayout;
import java.awt.Color;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class D_CardLayout extends JFrame{
	
	public D_CardLayout() {
		super("CardLayout");
		
		this.setBounds(300, 200, 400, 400);
		
		CardLayout card = new CardLayout();
		this.setLayout(card);
		//패널만들기
		//- 패널은 컴포넌트이지만 다른 컴포넌트를 포함할 수 있는 컨테이너와 같은 성격을 지니고 있다.
		//- 패널은 다른 페이지로 이동하는 듯 한 효과를 낼 수 있다.
		
		JPanel card1 = new JPanel();
		JPanel card2 = new JPanel();
		JPanel card3 = new JPanel();
		
		//패널의 배경색 지정
		card1.setBackground(Color.GRAY);
		card2.setBackground(Color.YELLOW); //대소문자 상관x
		card3.setBackground(new Color(50,100,50)); //RGB 색상 조합하여 사용 가능
		
		//메인프레임(컨테이너) 에 패널 추가
		
		this.add(card1);
		this.add(card2);
		this.add(card3);
		
		//익명클래스 방법 : 클래스를 정의하지 않고 필요할 때 이름 없이 즉시 선언하고 인스턴스화해서 사용
		card1.addMouseListener(new MouseAdapter() {

			public void mouseClicked(MouseEvent e) {
				if (e.getButton() == 1) { // 좌클릭
					card.next(card1.getParent()); // 카드 1번이 속해있는 컨테이너 다음장을 보여줌
				}
				if (e.getButton() == 3) { // 우클릭
					card.previous(card1.getParent()); // 카드 1번이 속한 이전장을 보여줌
				}
			}
		});

		card2.addMouseListener(new MouseAdapter() {

			public void mouseClicked(MouseEvent e) {
				if (e.getButton() == 1) { // 좌클릭
					card.next(card2.getParent()); // 카드 1번이 속해있는 컨테이너 다음장을 보여줌
				}
				if (e.getButton() == 3) { // 우클릭
					card.previous(card2.getParent()); // 카드 1번이 속한 이전장을 보여줌
				}
			}
		});

		card3.addMouseListener(new MouseAdapter() {

			public void mouseClicked(MouseEvent e) {
				if (e.getButton() == 1) { // 좌클릭
					card.next(card3.getParent()); // 카드 1번이 속해있는 컨테이너 다음장을 보여줌
				}
				if (e.getButton() == 3) { // 우클릭
					card.previous(card3.getParent()); // 카드 1번이 속한 이전장을 보여줌
				}
			}
		});
		
		
		this.setVisible(true);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

}
