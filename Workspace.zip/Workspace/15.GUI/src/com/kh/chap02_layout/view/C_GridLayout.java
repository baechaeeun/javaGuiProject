package com.kh.chap02_layout.view;

import java.awt.GridLayout;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;

import javax.swing.JButton;
import javax.swing.JFrame;

public class C_GridLayout extends JFrame{

	public C_GridLayout() {
		super("GridLayout");
		//윗줄부터 시작해서 왼쪽에서 오른쪽으로 움직이며 각 줄을 이동하며 컴포넌트 배치
		
		this.setBounds(300, 200, 600, 400);
		this.setLayout(new GridLayout(5,5/*,10,20*/)); //가로 세로 간격 조정 가능
		
		//좌에서 우로 증가하는 1~25 만들기
		/*for(int i=1;i<26;i++) {
			String input = Integer.valueOf(i).toString();
			this.add(new JButton(input));
		}*/
		
		//빙고판 만들기
		//중복제거, 랜덤으로
		
		Set<Integer> set=new LinkedHashSet<>();
		
		while(set.size()<25) {
			int num=(int)(Math.random()*25+1);
			set.add(num);
		}
		
		System.out.println(set);
		
		Iterator<Integer> it=set.iterator();
		while(it.hasNext()) {
			String str=Integer.valueOf(it.next()).toString();
			this.add(new JButton(str));
		}
		
		this.setVisible(true);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}
