package com.kh.chap02_layout.run;

import com.kh.chap02_layout.view.A_BoarderLayout;
import com.kh.chap02_layout.view.B_FlowLayout;
import com.kh.chap02_layout.view.C_GridLayout;
import com.kh.chap02_layout.view.D_CardLayout;
import com.kh.chap02_layout.view.E_NullLayout;
import com.kh.chap02_layout.view.Test;

public class Run {

	public static void main(String[] args) {
		
		//new A_BoarderLayout();
		//new B_FlowLayout();
		//new C_GridLayout();
		//new D_CardLayout();
		//new E_NullLayout();
		new Test();
	}

}
