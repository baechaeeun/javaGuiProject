package com.kh.chap01_container.view;

import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JFrame;

public class MakeJFrame1 extends JFrame{
	public MakeJFrame1() {
		super("MyFrame");
		
		this.setBounds(300,200,600,500);
		//컨테이너 위치 (x, y, 가로 w, 세로 h)
		
		this.setTitle("abc");
		this.setLocation(200,300);
		this.setSize(800,500);
		
		//프레임 상단 이미지를 다른 이미지로 바꾸기
		try {
			this.setIconImage(ImageIO.read(new File("images/cat.PNG")));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		this.setResizable(true); //컨테이너 사이즈 고정 유무
		
		
		this.setVisible(true); //컨테이너가 화면에 보이게
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

}
