package com.kh.chap04_map.run;

import java.util.Collection;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;

import com.kh.chap04_map.model.vo.Student;

public class Run {
	
	//private LinkedHashMap<String,Student> stdMap=new LinkedHashMap<>();
	private Hashtable<String,Student> stdMap=new Hashtable<>();
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Run m =new Run();
		m.test2();
		
	}
	private void test2() {
		TreeMap<String,Student> tm = new TreeMap<>();
		tm.put("바나나우유",new Student(2,"사나"));
		tm.put("칠성사이다",new Student(1,"쯔위"));
		tm.put("초코우유",new Student(2,"모모"));
		tm.put("코카콜라",new Student(3,"다현"));
		
		Set<String> s = tm.descendingKeySet();
		Iterator<String> iter = s.iterator();
		while(iter.hasNext()) {
			
			String key = iter.next();
			Student value = tm.get(key);
			System.out.println(key+" = "+value);
		}
	
	}
	
	private void test1() {
		HashMap map=new HashMap();
		map.put(1,"a");
		map.put(3,"b");
		map.put(33,"c");
		
		System.out.println(map); //순서보장안됨
		
		stdMap.put("커피",new Student(1,"윤우진"));
		stdMap.put("도넛",new Student(2,"한희원"));
		stdMap.put("라면",new Student(3,"송승연"));
		
		System.out.println(stdMap);
		
		stdMap.put("커피",new Student(1,"이준우"));
		
		System.out.println(stdMap);
		
		stdMap.put("젤리",new Student(4,"이준우"));
		
		System.out.println(stdMap);
		
		Student s=stdMap.get("커피");
		System.out.println(s);
		
		Student removed = stdMap.remove("커피");
		System.out.println(stdMap);
		
		/*1. keySet
		-Value를 얻고자할때 Set인 키들을 뽑아와서 Set 형에 담아서 출력.
		-key 값을 Set<String>으로 만들어서 iterator 로 뽑는다.*/
		
		
		System.out.println("******* keySet() *******");
		Set<String> kSet=stdMap.keySet(); //
		

		Iterator<String> iter = kSet.iterator(); //keySet에 있는 key 값들을 ITerator 반복자에 담는 과정
		while(iter.hasNext()) { // 담을요소 있는지 확인
			String key=iter.next(); //있으면 키를 담고
			Student val = stdMap.get(key); //키로 값을 얻어 온다.
			System.out.println(key +" = "+val);
		}
		
		//2. values 메소드 사용 (값만 뽑기)
		System.out.println("******* Collection *******");
		Collection values = stdMap.values(); //
		Iterator iter1 = values.iterator();
		while(iter1.hasNext()) {
			System.out.println(iter1.next());
		}
		
		//3. EntrySet
		//-key와 value를 같이 얻어오고자 할때 Map의 내부인터페이스인 Entry 타입을 이용
		//-key와 value를 묶어서 Entry 라고 함
		//-entrySet : Map.Entry 의 집합 모음 (Map 내부 인터페이스)
		
		Set eSet = stdMap.entrySet(); //stdMap에 있는 키와 밸류 값 세트로 eSet 컬렉션에 담는 과정
		Iterator it = eSet.iterator(); //eSet에 있는 키와 밸류 값 세트로 Iterator 반복자에 담는 과정
		while(it.hasNext()) {
			Map.Entry entry = (Entry)it.next();
			System.out.println(entry.getKey()+"="+entry.getValue());
		}
		
		Set<Entry<String,Student>> eSet1 = stdMap.entrySet();
		Iterator<Entry<String,Student>> it1 = eSet.iterator();
		
		while(it1.hasNext()) {
			Entry<String,Student> entry = it1.next();
			System.out.println(entry.getKey()+" = "+entry.getValue());
		}
		
	}

}
