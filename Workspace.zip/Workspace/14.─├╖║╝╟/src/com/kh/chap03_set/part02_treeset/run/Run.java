package com.kh.chap03_set.part02_treeset.run;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.TreeSet;

import com.kh.chap03_set.part02_treeset.model.vo.Student;

public class Run {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		TreeSet<String> ts = new TreeSet<>();
		ts.add(new String("하하하"));
		ts.add(new String("나나나"));
		ts.add(new String("가가가"));
		ts.add(new String("다다다"));
		ts.add(new String("하하하"));
		
		System.out.println(ts);
		
		TreeSet<Student> ts2 = new TreeSet<>();
		ts2.add(new Student("공유",39,100));
		ts2.add(new Student("소지섭",24,20));
		ts2.add(new Student("원빈",40,70));
		ts2.add(new Student("공유",10,100));
		
		
		System.out.println(ts2);
		/*TreeSet의 경우 hashCode(),equals()를 가지고 중복 판단하지 않고
		 * compareTo()에 제시한 정렬필드가 같은 경우 동일 객체로 판단한다.
		 */
		
		//1. for each문 출력
		for(Student s: ts2) {
			System.out.println(s.toString());
		}
		
		//2.ArrayList에 담아서 출력
		ArrayList<Student> arr=new ArrayList<Student>(ts2);
		System.out.println(arr);
		
		Iterator<Student> i=arr.iterator();
		
		while(i.hasNext()) {
			System.out.println(i.next());
		}
		

	}

}
