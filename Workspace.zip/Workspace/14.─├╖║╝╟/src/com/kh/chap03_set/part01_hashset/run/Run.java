package com.kh.chap03_set.part01_hashset.run;

import java.util.HashSet;
import java.util.Iterator;

public class Run {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		/*
		 * 1. Hash (hash알고리즘 도입):
		 * 데이터의 검색 성능 향상을 위해서 사용
		 * (hashCode와 equals를 모두 오버라이딩 해야한다.
		 * 
		 * 2. Set
		 * 
		 */
		
		HashSet hs = new HashSet();
		
		hs.add("반갑습니다.");
		hs.add(new String("반갑습니다"));
		hs.add(new String("여러분"));
		hs.add(new String("안녕하세요"));
		hs.add(new String("여러분"));
		
		System.out.println(hs);
		
		Iterator it = hs.iterator();
		while(it.hasNext()) {
			System.out.println(it.next());
		}

	}

}
