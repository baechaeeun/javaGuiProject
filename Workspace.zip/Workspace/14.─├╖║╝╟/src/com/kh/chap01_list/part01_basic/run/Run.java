package com.kh.chap01_list.part01_basic.run;

import java.util.ArrayList;
import java.util.Date;

public class Run {

	public static void main(String[] args) {
		/*
		 * 1. 컬렉션 프레임워크란?
		 * 
		 */
		
		ArrayList a1=new ArrayList();
		
		//add() : ArrayList 데이터 추가
		//add 마우스 올리면 object 타입으로 들어가는 것을 볼 수 있다.
		//컬렉션은 객체 타입만 받아주므로 기본 자료형을 추가하면 내부적으로 autoBoxing에 의해 WrapperClass 로 변형되어 객체로 들어간다.
		a1.add(true);   	//0
		a1.add("이효리"); 	//1
		a1.add('여');    	//2
		a1.add(30);      	//3
		a1.add(new Date()); //4
		
		//get(index) : ArrayList 의 값 추출
		System.out.println(a1.get(2));

		for(int i=0;i<a1.size();i++) {
			System.out.println("인덱스 "+i+"번째 a1의 값 : "+a1.get(i));
		}
		
		System.out.println(a1); //ArrayList에 오버라이딩된 toString()은
								//데이터를 []로 구분한 String형으로 반환해줌
		
		//remove(인덱스) : 원하는 인덱스 번째 값 삭제
		a1.remove(1);
		System.out.println(a1);
		
		a1.add(3,37.85);
		System.out.println(a1);
		
		//set(인덱스, 원하는 값) : 원하는 값 수정
		a1.set(3, "abc");
		System.out.println(a1);
		
		for(Object a: a1) {
			if(a instanceof String) {
				System.out.println(a);
			}
		}
	}

}
