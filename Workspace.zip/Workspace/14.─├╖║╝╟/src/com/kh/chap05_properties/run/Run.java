package com.kh.chap05_properties.run;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.Properties;
import java.util.Set;

public class Run {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//Hashtable 상속받고 있고 HashMap과 비슷한데 키와 value가 모두 String 자료형이다. 제네릭이 필요없다.
		Properties prop = new Properties();
		prop.setProperty("driver", "oracle.jdbc.driver.OracleDriver");
		prop.setProperty("url", "jdbc:oracle:thin@localhost:1521:xe");
		prop.setProperty("user", "student");
		prop.setProperty("password", "student");
		System.out.println(prop);
		
		System.out.println("=== 1. iterator ===");
		Set st = prop.keySet();
		Iterator it = st.iterator();
		
		while(it.hasNext()) {
			String key=(String)it.next();
			System.out.println(key);
			System.out.println(prop.getProperty(key)); //value
		}
		
		System.out.println("=== 2. Enumeration ==="); //iterator의 구버전
		Enumeration em = prop.keys();
		while(em.hasMoreElements()) {
			String key=(String) em.nextElement();
			System.out.println(prop.getProperty(key)); //value
		}
		
		System.out.println("=== 3. 저장하고 불러오기 ===");
		
		try {
			//일반적인 Properties 파일로 저장
			prop.store(new FileOutputStream("prop.properties"), "Test Properties");
			
			//XML 파일로 저장
			prop.storeToXML(new FileOutputStream("prop.xml"), "Test XML");
		}catch(FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		Properties readProp = new Properties();
		
		try {
			//일반적인 Properties 파일 불러오기
			readProp.load(new FileInputStream("prop.properties"));
			
			//XML 파일 불러오기
			readProp.loadFromXML(new FileInputStream("prop.xml"));
			
			System.out.println(readProp.getProperty("user"));
			
			Set st1 = readProp.keySet();
			Iterator it2 = st1.iterator();
			while(it2.hasNext()) {
				String key = (String)it2.next();
				System.out.println(key+ " = "+readProp.getProperty(key));
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
