package com.kh.chap02_listSort.run;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;

import com.kh.chap02_listSort.model.comparator.AscCiteNum;
import com.kh.chap02_listSort.model.comparator.AscCountry;
import com.kh.chap02_listSort.model.comparator.DesCiteNum;
import com.kh.chap02_listSort.model.vo.Cite;

public class Run {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		/* 1. Comparable(java.lang) : 클래스의 기본 정렬 기준을 설정
		 * 
		 * 반드시 compareTo 메소드를 오버라이딩 해야 함
		 * 
		 * 
		 * 2. Comparator(java.util) : 원하는 정렬 기준대로 설정(사용자 정의)
		 * 
		 * 반드시 compare 메소드를 오버라이딩 해야 함
		 * 
		 */
		
		ArrayList<Cite> a1=new ArrayList<Cite>();
		a1.add(new Cite(1,"아이슬란드","오로라"));
		a1.add(new Cite(2,"라오스","블루라군"));
		a1.add(new Cite(3,"보홉","스킨스쿠버"));
		a1.add(new Cite(4,"블라디보스톡","발레"));
		a1.add(new Cite(5,"크로아티아","성벽투어"));
		
		//1. Collections 클래스 활용
		//- Comparable 사용시
		Collections.sort(a1);
		//-Comparator
		Collection.sort(a1,new AscCiteNum());
		Collections.sort(a1);
		Collections.sort(a1 , new AscCountry());
		Collections.sort(a1,new DesCiteNum());
		
		//2. list.sort로 활용
		
		a1.sort(null);
		
		Iterator<Cite> it1=a1.iterator();
		while(it1.hasNext()) {
			System.out.println(it1.next());
		}
		
		Iterator<Cite> it2 = new LinkedList(a1).descendingIterator(); //a1에 있는 객체들을 Iterator에 담는 과정
		
		while(it2.hasNext()) {
			System.out.println(it2.next());
		}
		
		/*for(Cite c : a1) {
			System.out.println(c);
		}*/

	}

}
