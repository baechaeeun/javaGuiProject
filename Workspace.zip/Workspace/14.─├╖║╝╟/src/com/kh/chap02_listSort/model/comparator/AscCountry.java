package com.kh.chap02_listSort.model.comparator;

import java.util.Comparator;

import com.kh.chap02_listSort.model.vo.Cite;

public class AscCountry implements Comparator<Cite> {

	@Override
	public int compare(Cite o1, Cite o2) {
		// TODO Auto-generated method stub
		return o1.getCountry().compareTo(o2.getCountry());
	}

}
