package com.kh.chap02_listSort.model.vo;

import java.util.Comparator;

public class Cite implements Comparable<Cite>{

	private int citeNum; 
	private String country;
	private String point;
	
	
	public Cite() {
		
	}
	
	public Cite(int citeNum, String country, String point) {
		super();
		this.citeNum = citeNum;
		this.country = country;
		this.point = point;
	}

	public int getCiteNum() {
		return citeNum;
	}

	public void setCiteNum(int citeNum) {
		this.citeNum = citeNum;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getPoint() {
		return point;
	}

	public void setPoint(String point) {
		this.point = point;
	}

	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return citeNum+ " "+country+" "+point;
	}


	/*@Override
	public int compareTo(Object o) {
		// TODO Auto-generated method stub
		//A.compartTo(B) A<B 음수를 리턴, A=B 0 리턴, A>B 양수를 리턴
		//양수인경우 순서를 변경해준다.
		
		return this.citeNum-((Cite)o).citeNum;
	}*/
	
	//나라명 오름차순 정렬을 한다고 하면
	
	//this(앞)     vs      o(뒤)
	//Cite				Cite
	//this(앞)의 나라명이 	o(뒤) 나라명보다 더 큰 값일 경우 순서를 변경해줘야 한다.
	
	
	//이때 String 클래스에서 제공하는 compareTo 메소드를 호출하면 알아서 계산해서 반환해준다.
	//비교 주체가 대상과 같으면 0, 주체가 대상보다 크면 1, 주체가 대상보다 작으면 -1
	
	/*public int compareTo(Cite o) { //인터페이스 제네릭을 적용했을때 
		//다운캐스팅이 필요없다.
		return this.country.compareTo(o.country);
	}*/

	@Override
	public int compareTo(Cite o) {
		// TODO Auto-generated method stub
		return this.country.compareTo(o.country);
	}

}
