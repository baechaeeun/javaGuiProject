package com.kh.chap02_listSort.model.comparator;

import java.util.Comparator;

import com.kh.chap02_listSort.model.vo.Cite;

public class AscCiteNum implements Comparator<Cite>{

	@Override
	public int compare(Cite o1, Cite o2) {
		// TODO Auto-generated method stub
		
		return o1.getCiteNum() - o2.getCiteNum(); //양수면 순서 바꿈
	}

}
