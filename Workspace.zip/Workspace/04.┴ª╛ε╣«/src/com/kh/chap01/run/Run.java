package com.kh.chap01.run;

import com.kh.chap01.condition.A_If;
import com.kh.chap01.condition.C_Switch;

public class Run {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*
		 * A_If a=new A_If(); a.method5();
		 */
		C_Switch c=new C_Switch();
		c.method2();
	}

}
