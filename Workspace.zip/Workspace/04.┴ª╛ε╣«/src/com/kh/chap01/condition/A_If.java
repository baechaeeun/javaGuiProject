package com.kh.chap01.condition;

import java.util.Scanner;

public class A_If {
	/*단독 if
	 * 
	 * 
	 * if(조건식){
	 * 			...실행할 코드 ....
	 * }
	 * 
	 * --> 조건식의 결과 값이 참(true)이면 중괄호 안의 코드를 실행
	 * --> 조건식의 결과 값이 거짓(false)이면 중괄호 안의 코드를 실행하지 않는다.
	 */
	public void method1() {
		//
		Scanner sc=new Scanner(System.in);
		
		System.out.print("정수 : ");
		int num=sc.nextInt();
		
		if(num > 0) {
			System.out.println("양수이다.");
		}
		
		if(num<0) {
			System.out.println("음수이다.");
		}
		
		if(num==0) {
			System.out.println("0이다.");
		}
	}
	public void method2() {
		Scanner sc=new Scanner(System.in);
		
		System.out.print("정수 : ");
		int num=sc.nextInt();
		
		if(num%2==0)
			System.out.println("짝수이다.");
		if(num%2==1)
			System.out.println("홀수이다.");
		
	}
	
	public void method3() {
		Scanner sc=new Scanner(System.in);
		
		System.out.print("이름 : ");
		String name=sc.nextLine();
		System.out.print("학년 (숫자만) : ");
		int grade=sc.nextInt();
		sc.nextLine();
		System.out.print("반 (숫자만) : ");
		int classNum=sc.nextInt();
		sc.nextLine();
		System.out.print("번호 (숫자만) : ");
		int num=sc.nextInt();
		sc.nextLine();
		
		System.out.print("성별(M/F) : ");
		char gender=sc.nextLine().charAt(0);
		
		System.out.print("성적(소수점 아래 둘째 자리까지) : ");
		double score = sc.nextDouble();
		sc.hasNextLine();
		
		String student = "";
		
		if(gender == 'M' || gender == 'm')
			student = "남학생";
		if(gender == 'F' || gender == 'f')
			student = "여학생";
		if(gender != 'M' && gender != 'm' && gender !='F' &&gender !='f') {
			System.out.println("잘못 입력 하였습니다.");
			return;
		}
		System.out.println();
		System.out.println(grade + "학년" + classNum + "반" + num + "번"
				+name+" "+student+"의 성적은 "+score +"이다.");
		
		
	}
	public void method4() {
		Scanner sc=new Scanner(System.in);
		int age=sc.nextInt();
		System.out.print("나이 : ");
		
		String result=null;
		
		if(age <= 13) {
			result="어린이";
		}
		if(age > 13&&age<=19) {
			result="청소년";
		}
		if(age > 19) {
			result="어른";
		}
	}
	public void method5() {
		Scanner sc=new Scanner(System.in);
		
		System.out.print("이름 : ");
		String name=sc.nextLine();
		
		if(name.equals("배채은"))
			System.out.println("입력값이 맞습니다.");
		
		// 기본 자료형으로 비교시 ==, != 로 동등비교를 했는데
		// String 형은 String 클래스에서 제공하는 equals() 라는 메소드를 통해서 비교해야 한다.
		// hashcode 
		
	}
}
