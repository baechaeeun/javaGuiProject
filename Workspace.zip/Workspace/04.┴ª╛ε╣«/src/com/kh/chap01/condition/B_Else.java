package com.kh.chap01.condition;

public class B_Else {
	
	/* if-else문
	 * 
	 * if(조건식){
	 * 
	 * ...실행코드1...
	 * 
	 * }
	 * else{
	 * 
	 * ...실행코드2...
	 * }
	 * 
	 * 조건식의 결과가 true인 경우 실행코드1을 수행 후 if-else 문을 빠져나감
	 * 하지만 조건식의 결과가 false인 경우 무조건 실행코드2를 수행. if-else 문을 빠져나감
	 * 
	 * 
	 */
	
	/* if- else if문
	 * 같은 비교대상으로 여러개의 조건을 제시할 경우 사용
	 * 
	 * if(조건식){
	 * 		...실행코드1...
	 * }else if(조건식2){
	 * 			...실행코드2...
	 * }
	 * 
	 * 
	 * 
	 * 
	 */

}
