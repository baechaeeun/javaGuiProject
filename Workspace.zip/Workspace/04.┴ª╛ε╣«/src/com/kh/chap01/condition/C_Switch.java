package com.kh.chap01.condition;

import java.util.Scanner;

public class C_Switch {
	/*switch문
	 * 
	 * 
	 * switch(동등 비교 대상자){
	 * 	case 값1 : 실행코드1 ;
	 * 				break;
	 * 	case 값2 : 실행코드2; 
	 * 				break;
	 * 
	 * }
	 */
	public void method1() {
		Scanner sc = new Scanner(System.in);
		System.out.print("정수 값을 입력하세요 : ");
		int num = sc.nextInt();
		String result = "";

		switch (num) {
		case 1:
			result = "빨간색입니다.";
			break;
		case 2:
			result="파란색입니다.";
			break;
		case 3:
			result="초록색입니다.";
			break;
		default:
			result="잘못입력하였습니다.";
			break;
		}
		System.out.println(result);
	}
	public void method2() {
		Scanner sc=new Scanner(System.in);
		System.out.print("과일 이름을 입력하세요 : ");
		
		String fruit=sc.nextLine();
		
		int price = 0;
		
		switch(fruit) {
		case "사과":
			price = 4000;
			break;
		case "딸기":
			price = 2000;
			break;
		}
		
		System.out.println(fruit+"의 가격은 "+price+"원 입니다.");
	}
}
