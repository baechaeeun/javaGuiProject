package com.kh.chap02.run;

import com.kh.chap02.loop.A_For;
import com.kh.chap02.loop.B_While;
import com.kh.chap02.loop.C_DoWhile;

public class Run {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		A_For a = new A_For();
//
//		a.method14();
		
//		B_While b=new B_While();
//		b.method8();
		
		C_DoWhile c=new C_DoWhile();
		c.method6();
	}

}
