package com.kh.chap02.loop;

import java.util.Scanner;

public class C_DoWhile {
	
	/* do-while 문
	 * 
	 * [초기식]
	 * do{
	 * 		반복적으로 실행할 코드;
	 * 		[증감식]
	 * 
	 * }while(조건식);
	 * 
	 * 
	 * 초기식 --> 무조건 한번은 실행 --> 증감식
	 * 조건식 --> true일 경우 실행 --> 증감식
	 * 조건식 --> true일 경우 실행 --> 증감식
	 * 조건식 --> false일 경우 빠져나감
	 * 
	 * while문하고 다른 점은 while 문은 처음 수행될때도 조건식을 검사하고 나서 조건식이 true이면 실행,
	 * do-while문은 첫 실행은 조건식 없이 무조건 수행된다.
	 * 
	 * 
	 */
	
	public void method1() {
		int num=1;
		do {
			System.out.println(num);
			
		}while(num==0);
	}
	
	public void method2() {
		//1부터 5까지 출력
		//1 2 3 4 5
		
		int num=1;
		do {
			System.out.print(num+ " ");
			num++;
		}while(num<=5);
	}
	
	public void method3() {
		//1부터 랜덤값(1~10)까지의 합계
		
		int random=(int)(Math.random()*10+1);
		System.out.println("랜덤 수 : "+random);
		int i=1;
		int sum=0;
		
		do {
			sum+=i;
			i++;
		}while(i<=random);
		
		System.out.println("합계 : "+sum);
	}
	
	public void method4() {
		//사용자가 입력한 단의 구구단을 출력하기
		
		Scanner sc=new Scanner(System.in);
		
		System.out.print("단 수를 입력하세요 : ");
		int dan=sc.nextInt();
		int i=1;
		do {
			System.out.println(dan+" * "+i+" = "+dan*i);
			i++;
		}while(i<=9);
	}
	
	public void method5() {
		//사용자한테 키보드로 문자열을 입력 받아서 문자열 뽑기
		
		Scanner sc=new Scanner(System.in);
		
		System.out.print("문자열 입력 : ");
		String str=sc.nextLine();
		int i=0;
		do {
			System.out.println(str.charAt(i));
			i++;
		}while(i<str.length());
	}
	
	public void method6() {
		// 사용자에게 문자열을 입력 받고 출력
		// "exit"가 아닐 때까지 반복
		
		Scanner sc=new Scanner(System.in);
		String str="";
		
		do {
			System.out.print("문자열을 입력하세요 : ");
			str=sc.nextLine();
			System.out.println(str);
		}while(!str.equals("exit"));
	}
	
	public void method7() {
		Scanner sc=new Scanner(System.in);
		
		//무한반복이용
		String str="";
		do {
			System.out.println("문자열 입력 : ");
			str=sc.nextLine();
			
			if(str.equals("exit")) {
				break;
			}
			System.out.println("str : "+str);
		}while(true);
	}

}
