package com.kh.chap02.loop;

import java.util.Scanner;

public class A_For {
	public void method1() {
		for(int i=0;i<5;i++)
			System.out.println("안녕하세요");
	}
	public void method3() {
		for(int i=1;i<=10;i++) {
			if(i%2==1)
				System.out.println(i);
		}
	}
	public void method6() {
		//1부터 10까지 정수의 합계
		
		int sum=0;
		for(int i=1;i<=10;i++)
			sum+=i;
		System.out.println(sum);
	}
	public void method7() {
		//1부터 어떤 랜덤값 (1~10 사이의 랜덤한 숫자)까지의 합계
		/*
		 * java.lang.Math 클래스에서 제공하는 random() 메소드를 사용해서 랜덤값을 발생 시킬 것
		 * 
		 * Math.random()  호출시 --? 0.0~0.9999 사이의 랜덤 값을 발생시켜준다.
		 * (0.0 <= 랜덤 값 <1.0)
		 */
		
		//int random = Math.random(); //double 형이라서 안됨 
		
		//int random=Math.random()*10; //0.0 ~~9.9999....
		
		int random = (int)( Math.random() * 10 + 1); //1.0 ~ 10.999... -> int로 형변환
		
		System.out.println("1~10 사이의 랜덤값 : "+random);
		
		int sum = 0;
		for(int i=1;i<=random ; i++) {
			sum += i;
		}
		
		System.out.println("1부터 "+random+"까지의 합 : "+sum);
	}
	public void method8() {
		// 사용자한테 키보드로 문자열을 입력 받아서
		// 각 인덱스 별로 문자를 각각 추출
		Scanner sc=new Scanner(System.in);
		System.out.print("문자열 입력 : ");
		String str=sc.nextLine();
		//str.length();
		
		for(int i=0;i<str.length();i++) {
			System.out.println(str.charAt(i));
		}
		
	}
	public void method9() {
		//2단 출력하기 (구구단)
		//2*1=2
		
		for(int i=1;i<=9;i++) {
			System.out.println("2 * "+i+" = "+2*i);
		}
	}
	
	public void method10() {
		Scanner sc=new Scanner(System.in);
		System.out.print("단수 (2~9)를 입력해주세요 : ");
		int dan=sc.nextInt();
		
		for(int i=1;i<10;i++) {
			System.out.println(dan+" * "+i+" = "+dan*i);
		}
	}
	public void method11() {
		//1부터 5까지 연이어서 출력되는 문장을 3개 출력
		
		for(int i=1;i<=3;i++) {
			for(int j=1;j<=5;j++) {
				System.out.print(j);
			}
			System.out.println("");
		}
	}
	
	public void method12() {
		//2단부터 9단까지 출력
		
		for(int i=2;i<=9;i++) {
			for(int j=1;j<=9;j++) {
				System.out.println(i+" * "+j+" = "+i*j);
			}
		}
	}
	public void method13() {
		//*****
		//*****
		//*****
		//*****
		for(int i=1;i<=4;i++) {
			for(int j=1;j<=5;j++) {
				System.out.print("*");
			}
			System.out.println("");
		}
		
	}
	public void method14() {
		//1***
		//*2**
		//**3*
		//***4
		
		for(int i=1;i<=4;i++) {
			for(int k=1;k<=4;k++) {
				if(k==i)
					System.out.print(k);
				else
					System.out.print("*");
			}
			System.out.println();
		}
	}
	public void method15() {
		
		
		
	}
}
