package com.kh.chap02.loop;

import java.util.Scanner;

public class B_While {
	/*
	 * while문
	 * 
	 * [초기식]
	 * while(조건식){
	 * 		반복적으로 실행할 코드
	 * 		[증감식]
	 * }
	 * 
	 * 조건식이 true일 경우 해당 실행 코드를 실행
	 * 
	 * 조건식 검사 --> true 일 경우 실행코드 실행
	 * 조건식 검사 --> true 일 경우 실행코드 실행
	 * 조건식 검사 --> true 일 경우 실행코드 실행
	 * 조건식 검사 --> false 일 경우 실행코드 실행 안함 ---> 반복문을 빠져나감 
	 * 
	 * 
	 */
	
	
	public void method1() {
		//안녕하세요 5번 출력
		int i = 1;
		
		while(i<=5) {
			System.out.println(i);
			i++;
		}
		
		i=5;
		while(i>=1) {
			System.out.println(i);
			i--;
		}
	
	}
	
	public void method2() {
		//1에서 10사이의 홀수만 출력
		
		int i=1;
		
		while(i<=10) {
			if(i%2==1)
				System.out.println(i);
			i++;
		}
		
		i=1;
		while(i<=10) {
			System.out.println(i+" ");
			
			i+=2;
		}
	}
	
	public void method3() {
		//1부터 랜덤값 (1~10) 까지의 함계
		
		int sum=0;
		int i=1;
		int random=(int)(Math.random()*10+1);
		System.out.println("랜덤 값 : "+random);
		
		while(i<=random) {
			sum+=i;
			i++;
		}
		System.out.println(sum);
	}
	
	public void method4() {
		// 사용자가 키보드로 입력한 단의 구구단 출력하기

		Scanner sc = new Scanner(System.in);

		System.out.print("단을 입력하세요 : ");
		int num = sc.nextInt();

		int i = 1;
		if (num >= 2 && num <= 9) {
			while (i <= 9) {
				System.out.println(num + " * " + i + " = " + num * i);
				i++;
			}
		}
	}
	
	public void method5() {
		//사용자한테 문자열을 입력받아서
		//각 인덱스 별 문자를 추출
		Scanner sc=new Scanner(System.in);
		
		System.out.print("문자열 입력 : ");
		String str=sc.nextLine();
		
		int i=0;
		while(i<str.length()) {
			System.out.println(str.charAt(i));
			i++;
		}
	}
	
	public void method6() {
		//시 분 출력하기
		int hour=0;
		
		while(hour<24) {
			int min = 0;
			while(min<60) {
				System.out.printf("%2d시 %2d분 \n",hour,min);
				min++;
			}
			hour++;
			
			System.out.println();
		}
	}
	public void method7() {
		//메뉴
		Scanner sc=new Scanner(System.in);
		
		while(true) {
			System.out.println();
			System.out.println("====메뉴====");
			System.out.println("1. 1부터 5까지 출력");
			System.out.println("2. 1부터 10까지 홀수 출력");
			System.out.println("3. 1부터 랜덤 값까지의 합계 출력");
			System.out.println("9. 프로그램 종료");
			
			System.out.println("메뉴 입력 : ");
			int num=sc.nextInt();
			
			switch(num) {
			case 1:method1();
			break;
			case 2:method2();
			break;
			case 3:method3();
			break;
			case 9:
				System.out.println("프로그램을 종료합니다");
				return;
			default:
				System.out.println("잘못 입력 하였습니다.");
			}
		}
	}
	
	public void method8() {
		//계속 문자열을 입력받고 그 문자열 출력한다.
		//문자열이 "exit" 가 아닐 때 까지
		
		Scanner sc=new Scanner(System.in);
		
		while(true) {
			System.out.print("문자열을 입력하세요 : ");
			String str=sc.nextLine();
			
			if(str.equals("exit"))
				break;
			
			System.out.println(str);
		}
	}
	public void method9() {
		//계속 문자열을 입력받고 그 문자열 출력한다.
		//문자열이 "exit" 가 아닐 때 까지
		
		Scanner sc=new Scanner(System.in);
		
		while(true) {
			System.out.print("문자열을 입력하세요 : ");
			String str=sc.nextLine();
			
			if(str.equals("exit"))
				break;
			
			System.out.println(str);
		}
	}

}
