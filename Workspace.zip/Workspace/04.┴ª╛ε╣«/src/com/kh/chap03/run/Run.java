package com.kh.chap03.run;

import com.kh.chap03.branch.A_Break;
import com.kh.chap03.branch.B_Continue;

public class Run {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*
		 * A_Break a=new A_Break(); a.method3();
		 */
		
		B_Continue b=new B_Continue();
		b.method4();
	}

}
