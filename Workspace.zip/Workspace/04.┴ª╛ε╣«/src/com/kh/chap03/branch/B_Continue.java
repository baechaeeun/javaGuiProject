package com.kh.chap03.branch;

public class B_Continue {
	/*continue : 반복문 안에서만 사용 가능하고, continue를 만나게 되면 그 다음 구문은 실행하지 않고, 나와 가장 가까운
	 * 반복문으로 올라간다.
	 */
	
	public void method1() {
		//1부터 10까지 홀수를 출력
		
		for(int i=1;i<=10;i++) {
			
			if(i%2==0)
				continue;
			
			System.out.println(i+" ");
		}
	}
	
	public void method2() {
		// 1부터 100까지의 정수들의 합을 출력
		// 단, 6의 배수는 빼고 덧셈 연산 계산.
		
		int sum=0;
		for(int i=1;i<=100;i++) {
			if(i%6==0)
				continue;
			sum+=i;
		}
		System.out.println("정수 합 : "+sum);
	}
	
	public void method3() {
		//2~9까지의 구구단을 출력
		//단 4단은 빼고 출력하세요

		for (int i = 2; i <= 9; i++) {
			if (i == 4)
				continue;

			System.out.println(i + "단 출력");
			for (int j = 1; j <= 9; j++) {
				System.out.println(i + " * " + j + " = " + i * j);
			}
			System.out.println("======================");
		}
	}
	public void method4() {
		//2~9까지의 구구단을 출력
		//짝수 수는 빼고 출력하세요

		for (int i = 2; i <= 9; i++) {
			if (i%2==0)
				continue;

			System.out.println(i + "단 출력");
			for (int j = 1; j <= 9; j++) {
				if(j%2==0)
					continue;
				System.out.println(i + " * " + j + " = " + i * j);
			}
			System.out.println("======================");
		}
	}
}
