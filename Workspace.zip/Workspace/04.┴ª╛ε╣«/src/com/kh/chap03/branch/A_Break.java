package com.kh.chap03.branch;

import java.util.Scanner;

public class A_Break {
	/* break : 가장 가까운 반복문을 빠져나가는 문고
	 * 			단, switch 문의 break는 switch문을 빠져나간다.
	 */
	
	public void method1() {
		Scanner sc=new Scanner(System.in);
		
		/*
		 * for(;;) { System.out.println("문자열 입력 : "); str=sc.nextLine();
		 * System.out.println(str); }
		 */
		
		while(true) {
			System.out.println("문자열 입력 : ");
			String str=sc.nextLine();
			
			if(str.equals("exit")){
				break;
			}
			System.out.println(str);
		}
	}
	
	public void method2() {
		//반복적으로 랜덤값 (1~10)을 발생시킨 후 출력
		//단, 그 랜덤 값이 홀수 값일 경우에는 출력하지 않고 반복문을 빠져나간 후 "프로그램을 종료합니다." 출력
		
		while(true) {
			int num=(int)(Math.random()*10+1);
			System.out.println("랜덤 값 : "+num);
			if(num%2==1)
				break;
		}
		System.out.println("프로그램을 종료합니다.");
	}
	
	public void method3() {
		//사용자에게 반복적으로 정수 2개와 연산기호 (문자)를 입력받고(+,-)
		//그에 해당하는 계산처리를 하시오
		//단, 제시된 연산기호를 입력하지 않고 달느 연산 기호를 입력했을 경우에 빠져나가도록
		Scanner sc=new Scanner(System.in);
		
		int num1,num2;
		char op;
		
		while(true) {
			System.out.print("숫자 1을 입력하세요 : ");
			num1=sc.nextInt();
			sc.nextLine();
			System.out.print("연산자를 입력하세요 : ");
			op=sc.nextLine().charAt(0);
			if(op!='+'&&op!='-') {
				System.out.println("잘못 입력하였습니다.");
				break;
			}
			System.out.print("숫자2를 입력하세요 : ");
			num2=sc.nextInt();
			sc.nextLine();
			
			switch(op) {
			case '+':
				System.out.println("계산 결과 : "+num1+" "+op+" "+num2+" = "+(num1+num2));
				break;
			case '-':
				System.out.println("계산 결과 : "+num1+" "+op+" "+num2+" = "+(num1-num2));
				break;
			}
		}
	}

}
