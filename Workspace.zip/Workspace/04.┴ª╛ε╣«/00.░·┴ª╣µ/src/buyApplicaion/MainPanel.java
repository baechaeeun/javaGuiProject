package buyApplicaion;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JPanel;

public class MainPanel extends JPanel{
	
	public MainPanel(MainFrame mf) {
		setLayout(null);
		setBounds(0, 0, 500, 800);
		
		JButton buyButton = new JButton("주문하기");
		buyButton.setBackground(Color.white);
		buyButton.setBounds(10,40,100,30);
		JButton searchButton = new JButton("매장찾기");
		searchButton.setBackground(Color.white);
		searchButton.setBounds(110,40,100,30);
		JButton newsButton = new JButton("공지사항 및 뉴스");
		newsButton.setBackground(Color.white);
		newsButton.setBounds(210,40,150,30);
		JButton rewardButton = new JButton("멤버쉽");
		rewardButton.setBackground(Color.white);
		rewardButton.setBounds(360,40,100,30);
		
		
		//주문하기
		buyButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				mf.change("buyPanel");
			}
		});		
		
		newsButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				mf.change("newsPanel");
			}
		});		
		searchButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				mf.change("SearchPanel");
				
			}
			
		});
		
		
		add(buyButton);
		//buyButton.setBounds(x, y, width, height);
		
		//jl.setForeground(Color.white);
		//setBackground(Color.black);
		//add(jl,BorderLayout.WEST);
		setBounds(0, 0, 500, 800);
		
		//리워드
		rewardButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				mf.change("myReward");
			}
		});		
		
		add(rewardButton);
		//buyButton.setBounds(x, y, width, height);
		add(searchButton);
		add(newsButton);
		
		
		//setBounds(0, 0, 500, 800);
		
		
		
		
		JButton back =new JButton("로그아웃");
		back.setBackground(Color.white);
		back.setBounds(0, 500,130,30);
		add(back);
		
		back.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				mf.change("loginOrAssign");
			}
		});
		
		JButton information =new JButton("사용자 정보");
		information.setBackground(Color.white);
		information.setBounds(0, 600,130,30);
		add(information);
		
		information.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				mf.change("printUser");
			}
		});
	}

}
