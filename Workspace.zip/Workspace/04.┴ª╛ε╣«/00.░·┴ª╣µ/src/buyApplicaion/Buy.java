package buyApplicaion;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Buy extends JPanel{
	
	public Buy(MainFrame mf) {
		setLayout(null);
		setBounds(0, 0, 500, 800);
		setSize(500,800);
		
		JLabel jl=new JLabel("장바구니 내역");
		jl.setForeground(Color.blue);

		add(jl,BorderLayout.NORTH);
		jl.setBounds(220, 10, 500, 20);
		
		ArrayList<MenuBag> menuBag=mf.getMenuBagList();
		int price=0;
		
		for(int i=0;i<menuBag.size();i++) {
			JLabel tmp=new JLabel(menuBag.get(i).getName()+" - "+menuBag.get(i).getPrice());
			add(tmp);
			tmp.setBounds(220, 50+30*i, 500, 20);
			price+=menuBag.get(i).getPrice();
		}
		
		JLabel jl2=new JLabel("결제 금액 : "+price);
		jl2.setForeground(Color.blue);

		add(jl2);
		jl2.setBounds(220, 80+30*menuBag.size(), 500, 20);
		
		JButton buy=new JButton("결제하기");
		buy.setBounds(150, 150+30*menuBag.size(),130,30);
		add(buy);
		
		buy.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(mf.getMenuBagList().size()==0) {
					mf.change("bagList");
				}
				else {
					///////////////////
					for(MenuBag m : mf.getMenuBagList()) {
						mf.getUserManager().renewBuy(m.getName());
					}
					mf.setMenuBagList(new ArrayList<MenuBag>());
					mf.change("buyPanelDrink");
				}
			}
		});
		
		JButton main =new JButton("이전화면으로");
		main.setBackground(Color.white);
		main.setBounds(0, 500,130,30);
		add(main);
		
		main.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				mf.change("buyPanelDrink");
			}
		});
		
		
	}

}
