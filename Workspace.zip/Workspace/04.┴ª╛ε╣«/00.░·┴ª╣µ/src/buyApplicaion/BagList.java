package buyApplicaion;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class BagList extends JPanel{
	
	public BagList(ArrayList<MenuBag> menuBag,MainFrame mf) {
		
		setLayout(null);
		setBounds(0, 0, 500, 800);
		setSize(500,800);
		
		if(menuBag.size()==0) {
			JLabel jl=new JLabel("장바구니가 비어있습니다.");
			jl.setForeground(Color.blue);

			add(jl,BorderLayout.NORTH);
			jl.setBounds(180, 10, 500, 20);
		}
		
		else {
			JLabel jl=new JLabel("장바구니 내역");
			jl.setForeground(Color.blue);

			add(jl,BorderLayout.NORTH);
			jl.setBounds(220, 10, 500, 20);
			
			int price=0;
			
			for(int i=0;i<menuBag.size();i++) {
				JLabel tmp=new JLabel(menuBag.get(i).getName()+" - "+menuBag.get(i).getPrice());
				add(tmp);
				tmp.setBounds(220, 50+30*i, 500, 20);
				price+=menuBag.get(i).getPrice();
			}
		}
		
		JButton main =new JButton("이전화면으로");
		main.setBackground(Color.white);
		main.setBounds(0, 500,130,30);
		add(main);
		
		main.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				mf.change("buyPanelDrink");
			}
		});
		
	}

}
