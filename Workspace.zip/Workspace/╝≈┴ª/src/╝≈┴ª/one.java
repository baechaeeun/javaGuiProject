package 숙제;

public class one {

}
