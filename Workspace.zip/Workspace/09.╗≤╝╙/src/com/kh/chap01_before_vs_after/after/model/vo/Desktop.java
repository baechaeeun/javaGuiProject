package com.kh.chap01_before_vs_after.after.model.vo;

public class Desktop extends Product{
	
	private boolean allInOne;
	
	public Desktop() {}

	public Desktop(String brand, String pCode, String pName,int price,boolean allInOne) {
		super(brand, pCode, pName, price); //자식 생성자 첫줄에 반드시 위치해야 한다.
		this.allInOne = allInOne;
	}

	public boolean isAllInOne() {
		return allInOne;
	}

	public void setAllInOne(boolean allInOne) {
		this.allInOne = allInOne;
	}
	
	public String information() {
		return "allInOne : "+allInOne;
	}
	
	public void print() {
		System.out.println("나  Desktop 객체야~!!");
	}

}
