package com.kh.chap01_before_vs_after.after.run;

import com.kh.chap01_before_vs_after.after.model.vo.Desktop;
import com.kh.chap01_before_vs_after.after.model.vo.SmartPhone;
import com.kh.chap01_before_vs_after.after.model.vo.Tv;

public class Run {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Desktop d=new Desktop("삼성","d-01","KH데스크탑",2000000,true);
		
		SmartPhone s=new SmartPhone("애플","s-01","아이폰",14000,"KT");
		
		Tv t=new Tv("LG","t-01", "KH티비",300000, 46);
		
		System.out.println(d.information());
		System.out.println(s.information());
		System.out.println(t.information());	
		
		/* 상속
		 * [접근제어자][기타제어자] class 클래스명 extends 상위클래스 [implements 인터페이스]
		 * 
		 * # this, super ==> static메소드에서는 사용할 수 없다.
		 * super : 상위 클래스를 가리키는 레퍼런스 변수, 은닉 변수를 불러온다.
		 * this : 클래스 인스턴스 나 자신을 나타내는 레퍼런스 변수
		 * 
		 * this(), super() : 생성자 호출 : 
		 * 
		 * 상속의 장점
		 * - 보다 적은 양의 코드로 새로운 클래스를 작성 가능
		 * - 코드를 공통적으로 관리하기 때문에 코드의 추가, 변경에 용이
		 * - 코드의 중복을 제거해서 프로그램의 생산성과 유지보수에 크게 기여
		 * 
		 * 상속의 특징
		 * - 클래스 간 상속은 다중 상속은 불가능하다, (단일 상속만 가능) extends Product, SmartPhone x
		 * - 명시되어 있지 않지만 모든 클래스는 object 클래스의 후손이다. --> 즉 Object 클래스가 제공하는
		 * 메소드를 오버라이딩하여 메소드 재정의를 할 수 있다.
		 * - 부모 클래스의 생성자와 초기화 블록은 상속이 불가능하다 ( 자식 클래스 생성 시 부모 클래스 생성자가 먼저 실행됨)
		 * - 부모의 private 멤버(필드, 메소드)는 상속은 되지만 직접 접근은 불가능하다. (단, protected로 
		 * 하게되면 후손 클래스가 직접 접근 가능)
		 * 
		 */
		
		d.print(); //실행하고자 하는 메소드가 자식에 없으면 자동으로 부모 메소드가 실행
		//단 자식이 메소드를 동일하게 작성되어 있으면 자식의 메소드가 우선권을 가지게 된다.
		//오버라이딩 - 부모클래스의 메소드를 자식클래스의 재정의해서 사용하는 것
	}

}
