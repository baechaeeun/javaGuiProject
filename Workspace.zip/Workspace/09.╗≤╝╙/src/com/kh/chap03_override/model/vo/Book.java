package com.kh.chap03_override.model.vo;

public class Book /*extends Object*/{
	
	private String title;
	private String author;
	private int price;
	
	public Book() {}

	public Book(String title, String author, int price) {
		super();
		this.title = title;
		this.author = author;
		this.price = price;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}
	
	public String information() {
		return "title : "+title+", author : "+author+", price : "+price;
	}

	//1. Object 클래스의 toString() 메소드 오버라이딩
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "title : "+title+", author : "+author+", price : "+price;
	}

	@Override
	public boolean equals(Object obj) {
		Book other=(Book)obj; //obj 타입을 Book타입으로 강제 형변환 해줬다.
		//상속 구조에서는 클래스로 형변환이 가능하다.
		//this(현객체) vs other
		//Book			Book
		
		if(this.title.equals(other.title)&&this.author.equals(other.author)&&
				this.price==other.price) {
			return true;
		}
		else {
			return false;
		}
		 
	}

	@Override
	public int hashCode() {
		//1번 방법 : 해당 객체의 필드 값들을 하나의 문자열로 합쳐서 해당 문자열의 해쉬코드를 리턴
		//title + author + price ---> 문자열 (String) 이 된다.
		//String 클래스의 hashCode 메소드를 통해 그 값을 리턴하자
		
		return (title + author + price).hashCode();
		//즉, 같은 문자열일 경우 해당 문자열의 hashCode는 같도록 String 클래스에서 이미 재정의 
		
		//두번째 방법
		//return Objects.hash(title,author,price);
	}
	
	
	/*오버라이딩
	 * -자식클래스가 상속받은 부모 클래스의 메소드를 재정의(재작성) 하는것
	 * -부모가 제공하는 메소드를 자식이 일부 고쳐서 사용하겠다는 의미로 자식 객체를 통해 실행 시 자식 메소드가 우선권을
	 * 가진다.
	 * 
	 * 오버라이딩 성립 조건
	 * -부모클래스의 메소드와 메소드 명 동일
	 * -매개변수 개수, 자료형, 순서 동일
	 * -변환형 동일
	 * -부모 메소드의 접근 제한자보다 범위가 같거나 커야한다.
	 * ex)부모 메소드의 접근 제한자가 protected일 경우에 오버라이딩하는 메소드의 접근 제한자는 protected 나
	 * 
	 * public
	 * 
	 * 
	 */
	
	
	

}
