package com.kh.chap03_override.run;

import com.kh.chap03_override.model.vo.Book;

public class Run {

	public static void main(String[] args) {
		// 모든 클래스는 Object의 후손이다.
		
		Book bk1=new Book("언어의 온도","이기주",10000);
		Book bk2=new Book("개미","베르나르 베르베르",20000);
		
		/*System.out.println(bk1.information());
		System.out.println(bk2.information());
		
		System.out.println(bk1.toString());
		System.out.println(bk2);//출력문에서 어떤 레퍼런스를 출력하고자 할때 JVM이 toString() 호출
		*/
		/* 1. toString()-----------------------------------
		 * 오버라이딩 전 : Object클래스의 toString() 실행 --> 풀패키지명 + @ + 해쉬코드 16진수 값 리턴
		 * 오버라이딩 후 : Book 클래스의 toString() 실행 --> 내가 재정의 한 대로 해당 객체가 가지고 있는
		 * 필드 값에 대한 정보 리턴
		 */
		
		System.out.println(bk1);
		System.out.println(bk2);
		
		Book bk3=new Book("언어의 온도","이기주",10000);
		System.out.println("bk1과 bk3이 같은 책입니까?"+(bk1==bk3));//주소 값 비교
		
		//레퍼런스끼리 비교할 때 equals 메소드 사용 가능 --> 이때 Object 클래스의 equals 실행
		System.out.println("bk1과 bk3이 같은 책입니까?"+(bk1.equals(bk3)));
		//false --> 주소 값 비교이기 때문
		
		//오버라이딩 전 : Object 클래스의 equals 메소드 실행 --> 두 주소 값을 비교
		//오버라이딩 후 : 두 객체의 주소 값 비교가 아닌 실제 필드 값들이 같은 경우 true로 반환되도록 재 정의
		
		//동일 객체 : 실제 필드 값들은 같지만 해쉬코드 값이 다른 경우
		//동등 객체 : 실제 필드 값도 같고 해쉬코드 값도 같은 경우 ----> 동일 객체라는 것은 중복된다는 뜻

		System.out.println("bk1의 해쉬코드 : "+bk1.hashCode());
		System.out.println("bk2의 해쉬코드 : "+bk2.hashCode());
		System.out.println("bk3의 해쉬코드 : "+bk3.hashCode());
		
		//오버라이딩 전 : Object 클래스의 hashCode() 메소드 실행 --> 해당 객체의 실제 주소값을 10진수로
		//계산한 결과
		//오버라이딩 후 : 두 객체의 실제 주소 값을 가지고 작업하지 않고 두 객체의 실제 멤버 값들이 같은 경우 같은 해쉬코드
		//값이 나오도록 재정의
		
		
		
	}

}
