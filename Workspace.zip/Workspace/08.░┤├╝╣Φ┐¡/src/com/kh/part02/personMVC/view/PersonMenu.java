package com.kh.part02.personMVC.view;

import java.util.Scanner;

import com.kh.part02.personMVC.controller.PersonController;
import com.kh.part02.personMVC.model.vo.Person;

public class PersonMenu {

	private Scanner sc=new Scanner(System.in);
	
	private PersonController pc = new PersonController();

	//메인메뉴 - 프로그램 실행과 동시에 보여질 메뉴
	public void mainMenu() {

		while(true) {
			System.out.println("=== 메뉴 ===");
			System.out.println("1. 회원 추가");
			System.out.println("2. 회원 전체조회");
			System.out.println("3. 회원 이름검색");
			System.out.println("4. 회원 평균재산 조회");
			System.out.println("9. 프로그램 종료");
			System.out.println("메뉴 선택 : ");
			int menu=sc.nextInt();
			sc.nextLine();
			
			switch(menu) {
			case 1:
				insertPerson();
				break;
			case 2:
				printPerson();
				break;
			case 3:
				searchPerson();
				break;
			case 4:
				System.out.println("평균 재산 : "+pc.avgWealth());
				break;
			case 9:
				System.out.println("프로그램을 종료합니다. ");
				return;
			default:
				System.out.println("다시 입력해주세요. ");
				break;

			}
		}
	}
//메뉴3
	public void searchPerson() {
		System.out.println("=== 사원 정보 검색 ===");
		
		System.out.println("검색할 이름 : ");
		String search=sc.nextLine();
		
		Person searchPerson=pc.searchPerson(search);
		
		if(searchPerson==null) {
			System.out.println("검색된 사람이 없습니다.");
		}
		else {
			System.out.println(searchPerson.information());
		}
		
	}
	//메뉴2
	public void printPerson() {
		System.out.println("=== 사원 정보 조회 ===");
		
		int count = pc.getCount(); //controller 현재 회원 수 알려달라고 요청
		
		if(count==0) {
			System.out.println("현재 추가된 회원이 없습니다.");
		}
		else {
			Person[] pe=pc.getPeople(); //controller 현재 회원 정보가 담겨 있는 배열 요청
			
			for(int i =0; i<count;i++) {
				System.out.println(pe[i].information());
			}
		}
		
	}
//메뉴1
	public void insertPerson() {
		System.out.println("=== 사원정보 입력 ===");
		System.out.println("이름 : ");
		String name = sc.nextLine();
		
		System.out.println("나이 : ");
		
		int age = sc.nextInt();
		
		System.out.println("재산 : ");
		int wealth = sc.nextInt();
		sc.nextLine();
		
		boolean cnt = pc.insertPerson(name, age, wealth); //controller
		if (!cnt){
			System.out.println("더 이상 추가할 수 없습니다. ");
		}
		
		
	}
	
}
