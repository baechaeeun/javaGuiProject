package com.kh.part02.personMVC.run;

import com.kh.part02.personMVC.view.PersonMenu;

public class Run {

	public static void main(String[] args) {
		// MVC
		//Model : 데이터 담당
		//View : 사용자의 시각적 요소 담당 (화면) --> 사용자에게 값을 출력해주거나 
		//사용자로부터 값을 입력받음
		//Controller : 사용자가 요청하는 기능을 처리
		
		/*	Run      -> View        ->    Controller
		 * 첫 화면 실행		출력 및 입력          요청         사용자의 요청 처리
		                  
		                             <-
		                                    결과 출력             요청 처리 결과 반환
		 */
		
		new PersonMenu().mainMenu();
	}

}
