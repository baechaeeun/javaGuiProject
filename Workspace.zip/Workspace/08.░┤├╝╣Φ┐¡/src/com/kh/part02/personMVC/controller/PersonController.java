package com.kh.part02.personMVC.controller;

import com.kh.part02.personMVC.model.vo.Person;

public class PersonController {

	private Person people [] =new Person[3];
	private int count = 0;

	//전달받은 회원의 이름, 나이, 재산을 가지고 person 객체 생성 후 해당 배열의 초기화를 시켜주는 메소드
	public boolean insertPerson(String name, int age, int wealth) {
		
		if(count < people.length) {
			people[count++] = new Person(name, age, wealth);
			return true;
		}
		else {
			return false;
		}		
	}
	//전달받은 검색어로 검색된 회원 객체를 반환해주는 메소드(단, 검색된 회원이 없는 경우 null 반환)
	public Person searchPerson(String search) {
		for(int i=0;i<count;i++) {
			if(people[i].getName().equals(search))
				return people[i];
		}
		return null;
	}
	//현재 회원이 몇명 존재하는지 반환해주는 메소드
	public int getCount() {
		return count;
	}

	//현재 회원들의 정보가 담겨있는 배열을 반환해주는 메소드
	public Person[] getPeople() {
		// TODO Auto-generated method stub
		return people;
	}
	
	public String avgWealth() {
		int sum =0;
		
		for(int i=0;i<count;i++) {
			sum+=people[i].getWealth();
		}
		
		double avg=(double)(sum/count);
		String avg1=String.format("%.3f", avg);
		String avg2=String.format("%.2f", avg);
		
		return String.valueOf(avg) + "    %.3f   :  "+avg1+
				"   %.2f   :    "+avg2;
	}
	
	
}
