package buyApplicaion;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

public class MenuCloser extends JPanel{
	
	public MenuCloser(String menu,int price,MainFrame mf) {
		
		setLayout(null);
		setBounds(0, 0, 500, 800);
		setSize(500,800);
		
		JLabel jl=new JLabel("메뉴 상세-"+menu+"("+price+")");
		jl.setForeground(Color.blue);

		add(jl,BorderLayout.NORTH);
		jl.setBounds(150, 20, 500, 20);
		
		JTextField num = new JTextField("개수를 입력하세요");
		add(num);
		
		JRadioButton hot = new JRadioButton("hot");
		JRadioButton ice = new JRadioButton("ice");
		hot.setBounds(170, 100, 100, 50);
		ice.setBounds(270, 100, 100, 50);
		add(hot);
		add(ice);
		
		ButtonGroup group1 = new ButtonGroup();
		
		group1.add(hot);
		group1.add(ice);
		
		JRadioButton hall = new JRadioButton("매장컵");
		JRadioButton personal = new JRadioButton("개인컵");
		JRadioButton one = new JRadioButton("일회용컵");
		hall.setBounds(100, 150, 100, 100);
		personal.setBounds(200, 150, 100, 100);
		one.setBounds(300, 150, 100, 100);
		add(hall);
		add(personal);
		add(one);
		
		ButtonGroup group2 = new ButtonGroup();
		
		group2.add(hall);
		group2.add(personal);
		group2.add(one);
		
		
		JRadioButton Tall = new JRadioButton("Tall");
		JRadioButton Grande = new JRadioButton("Grande");
		Tall.setBounds(170, 220, 100, 100);
		Grande.setBounds(270, 220, 100, 100);
		add(Tall);
		add(Grande);
		
		ButtonGroup group3 = new ButtonGroup();
		group3.add(Tall);
		group3.add(Grande);
		
		JButton bag = new JButton("장바구니 담기");
		JButton buy = new JButton("주문하기");
		
		bag.setBounds(100, 360, 150, 50);
		buy.setBounds(300, 360, 100, 50);
		
		add(bag);
		add(buy);
		
		JButton back =new JButton("←이전화면으로");
		back.setBackground(Color.white);
		back.setBounds(0, 450,130,30);
		add(back);
		
		back.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				mf.change("buyPanelDrink");
			}
		});
		
		JButton main =new JButton("←메인화면으로");
		main.setBackground(Color.white);
		main.setBounds(0, 500,130,30);
		add(main);
		
		main.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				mf.change("mainPanel");
			}
		});
		
		
		
	}
	

}
