package buyApplicaion;

public class MenuBag { //장바구니 구조체
	private String name;
	private int price;
	private int num;
	private char temperature;
	private int cup; //매장컵 - 1, 개인컵 - 2, 일회용컵 - 3
	private int size; //Tall - 1, Grande - 2
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public char getTemperature() {
		return temperature;
	}
	public void setTemperature(char temperature) {
		this.temperature = temperature;
	}
	public int getCup() {
		return cup;
	}
	public void setCup(int cup) {
		this.cup = cup;
	}
	public int getSize() {
		return size;
	}
	public void setSize(int size) {
		this.size = size;
	}
}
