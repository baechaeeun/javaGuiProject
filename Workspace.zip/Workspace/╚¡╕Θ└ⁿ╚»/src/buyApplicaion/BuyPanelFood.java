package buyApplicaion;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class BuyPanelFood extends JPanel{
	
	public BuyPanelFood(MainFrame mf) {
		setLayout(null);
		setBounds(0, 0, 500, 800);
		setSize(500,800);
		
		JLabel jl=new JLabel("주문하기");
		jl.setForeground(Color.blue);

		add(jl,BorderLayout.NORTH);
		jl.setBounds(220, 10, 500, 20);
		
		JButton b11=new JButton("음료");
		b11.setBackground(Color.white);
		add(b11);
		b11.setBounds(10,40,70,30);
		JButton b12=new JButton("푸드");
		b12.setBackground(Color.white);
		b12.setBounds(110,40,70,30);
		add(b12);
		JButton b13=new JButton("상품");
		b13.setBackground(Color.white);
		b13.setBounds(210,40,70,30);
		add(b13);
		JButton b14=new JButton("홀케이크 예약");
		b14.setBackground(Color.white);
		b14.setBounds(310,40,150,30);
		add(b14);
	
		
		b11.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				mf.change("buyPanelDrink");
			}
		});
		b12.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				mf.change("buyPanelFood");
				
			}
		});
		b13.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				mf.change("buyPanelItem");
			}
		});
		b14.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				mf.change("buyPanelCake");
			}
		});
		
		JButton b31=new JButton("윌넛 카라멜 치즈 케이크");
		b31.setBackground(Color.white);
		b31.setBounds(0,100,500,50);
		add(b31);
		
		JButton b32=new JButton("애플 까망베르 샌드위치");
		b32.setBackground(Color.white);
		b32.setBounds(0, 160,500, 50);
		add(b32);
		
		JButton b33=new JButton("트리플 머쉬룸 치즈 샌드위치");
		b33.setBackground(Color.white);
		b33.setBounds(0, 220, 500, 50);
		add(b33);
		
		JButton b34=new JButton("보늬밤 몽블랑 데니쉬");
		b34.setBackground(Color.white);
		b34.setBounds(0, 280, 500, 50);
		add(b34);
		
		JButton b35=new JButton("스크램블 에그 롤");
		b35.setBackground(Color.white);
		b35.setBounds(0, 340, 500, 50);
		add(b35);
		
		//BuyPanelDrink tmp=this;
				b31.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						mf.changeMenupan("윌넛 카라멜 치즈 케이크",6100);
					}
				});
				b32.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						mf.changeMenupan("애플 까망베르 샌드위치",6100);
					}
				});
				b33.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						mf.changeMenupan("트리플 머쉬룸 치즈 샌드위치",5900);
					}
				});
				b34.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						mf.changeMenupan("보늬밤 몽블랑 데니쉬",5200);
					}
				});
				b35.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						mf.changeMenupan("스크램블 에그 롤",5600);			}
				});
		
		JButton back =new JButton("←메인화면으로");
		back.setBackground(Color.white);
		back.setBounds(0, 500,130,30);
		add(back);
		
		back.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				mf.change("mainPanel");
			}
		});
	}

}
