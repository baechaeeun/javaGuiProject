package buyApplicaion;

import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class MainFrame extends JFrame{
	
	private static MainPanel mainPanel;
	private static BuyPanelDrink buyPanelDrink;
	private static BuyPanelCake buyPanelCake;
	private static BuyPanelFood buyPanelFood;
	private static BuyPanelItem buyPanelItem;
	private static MenuCloser menuCloser;
	/*private static SearchPanel searchPanel;
	private static NewsPanel newsPanel;
	private static MembershipPannel membershipPanel;*/
	private static ArrayList<MenuBag> menuBagList;
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		MainFrame mf=new MainFrame();
		
		mf.mainPanel=new MainPanel(mf);
		mf.buyPanelDrink=new BuyPanelDrink(mf);
		mf.buyPanelFood=new BuyPanelFood(mf);
		mf.buyPanelItem=new BuyPanelItem(mf);
		mf.buyPanelCake=new BuyPanelCake(mf);
		
		
		/*mf.SearchPanel=new SearchPanel(mf);
		mf.NewsPanel=new NewsPanel(mf);
		mf.MembershipPannel=new membershipPanel(mf);*/
		
		mf.add(mainPanel);
		
		mf.setSize(500,800);
		mf.getContentPane().setLayout(null);
		mf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		mf.setVisible(true);

	}
	
	public void change(String panelName) {
		switch(panelName) {
		case "mainPanel":
			getContentPane().removeAll();
			getContentPane().add(mainPanel);
			revalidate();
			repaint();
			break;
			
		case "buyPanelDrink":
			getContentPane().removeAll();
			getContentPane().add(buyPanelDrink);
			revalidate();
			repaint();
			break;
			
		case "buyPanelFood":
			getContentPane().removeAll();
			getContentPane().add(buyPanelFood);
			revalidate();
			repaint();
			break;
			
		case "buyPanelItem":
			getContentPane().removeAll();
			getContentPane().add(buyPanelItem);
			revalidate();
			repaint();
			break;
			
		case "buyPanel":
			getContentPane().removeAll();
			getContentPane().add(buyPanelDrink);
			revalidate();
			repaint();
			break;
			
		case "buyPanelCake":
			getContentPane().removeAll();
			getContentPane().add(buyPanelCake);
			revalidate();
			repaint();
			break;
			
			
		/*case "SearchPanel":
			getContentPane().removeAll();
			getContentPane().add(SearchPanel);
			revalidate();
			repaint();
			break;
		case "NewsPanel":
			getContentPane().removeAll();
			getContentPane().add(NewsPanel);
			revalidate();
			repaint();
			break;
			
		case "MembershipPannel":
			getContentPane().removeAll();
			getContentPane().add(MembershipPannel);
			revalidate();
			repaint();
			break;*/
		}
		
	}

	public void changeMenupan(String menu,int price) {
		
		menuCloser=new MenuCloser(menu,price,this);
		getContentPane().removeAll();
		getContentPane().add(menuCloser);
		revalidate();
		repaint();

	}
}
