package buyApplicaion;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JPanel;

public class MainPanel extends JPanel{
	
	public MainPanel(MainFrame mf) {
		
		JButton buyButton = new JButton("주문하기");
		buyButton.setBackground(Color.white);
		JButton searchButton = new JButton("매장찾기");
		searchButton.setBackground(Color.white);
		JButton newsButton = new JButton("공지사항 및 뉴스");
		newsButton.setBackground(Color.white);
		JButton membershipButton = new JButton("멤버쉽");
		membershipButton.setBackground(Color.white);
		
		buyButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				mf.change("buyPanel");
			}
		});
		
		
		add(buyButton);
		//buyButton.setBounds(x, y, width, height);
		add(searchButton);
		add(newsButton);
		add(membershipButton);
		
		//jl.setForeground(Color.white);
		//setBackground(Color.black);
		//add(jl,BorderLayout.WEST);
		setBounds(0, 0, 500, 50);
	}

}
