package com.kh.chap02_abstractAndInterface.run;

import com.kh.chap02_abstractAndInterface.model.vo.BasketBall;
import com.kh.chap02_abstractAndInterface.model.vo.FootBall;
import com.kh.chap02_abstractAndInterface.model.vo.Sports;

public class Run {

	public static void main(String[] args) {


		Sports s;
		s=new FootBall();
		
		Sports[] arr=new Sports[2];
		arr[0] = new BasketBall();
		arr[1] = new FootBall();
		
		for(int i=0;i<arr.length;i++) {
			arr[i].rule();
		}
		
		for(Sports e : arr) {
			e.rule();
		}
			
	}

}
