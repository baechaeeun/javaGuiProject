package com.kh.chap02_abstractAndInterface.model.vo;

public abstract class Sports {
	
	private int people;
	
	public Sports() {}

	public Sports(int people) {
		super();
		this.people = people;
	}

	public int getPeople() {
		return people;
	}

	public void setPeople(int people) {
		this.people = people;
	}
	
	public String toString() {
		return "Sports [people : "+people+"]";
	}
	
	public abstract void rule();
	/* 추상메소드 (미완성된 메소드로 내용 구현이 되어있지 않는 메소드)
	 * -->{} 몸통부가 아직 구현되지 않은 상태
	 * 
	 * -->미완성 추상메소드가 있다는 것은 이 클래스 또한 미완성된 상태 --> 추상 클래스로 명시 해줘야 한다.
	 * public abstract class Sports
	 *  
	 */

}
