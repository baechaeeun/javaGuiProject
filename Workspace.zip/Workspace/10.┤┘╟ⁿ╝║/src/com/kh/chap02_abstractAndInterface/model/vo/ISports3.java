package com.kh.chap02_abstractAndInterface.model.vo;

public interface ISports3 {

}
