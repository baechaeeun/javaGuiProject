package com.kh.chap02_abstractAndInterface.model.vo;

/* 상속
 * 미완성클래스 / 클래스 extends (하나만 상속 가능)
 * 인터페이스 : implements( 여러개 적을 수 있다)
 */
public class FootBall extends Sports implements ISports1, ISports2{

	public void rule() {
		System.out.println("손이 아닌 발로 공을 차야 한다. ");
		//미완성 메소드 구현(부모의 rule())
	}

	@Override
	public void rule1() {
		System.out.println(" 인터페이스 ISports1 메소드~");
	}

	@Override
	public void startTime() {
		System.out.println(" 인터페이스 ISports2 메소드~startTime");
		
	}

	@Override
	public void endTime() {
		System.out.println(" 인터페이스 ISports2 메소드~endTime");
		
	}
}
