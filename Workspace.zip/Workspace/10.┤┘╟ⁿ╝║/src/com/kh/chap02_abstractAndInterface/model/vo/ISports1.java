package com.kh.chap02_abstractAndInterface.model.vo;

public interface ISports1 /*extends ISports2, ISports3*/{
	//추상 클래스 --> 일반멤버 (변수 + 메소드) + 추상 메소드
	//인터페이스 --> only 상수 필드 + 추상메소드
	
	/*public static final*/ int NUM=10;
	
	/*public abstract*/ void rule1();
	//자동적으로 public abstract 예약어를 붙여준다.

}
