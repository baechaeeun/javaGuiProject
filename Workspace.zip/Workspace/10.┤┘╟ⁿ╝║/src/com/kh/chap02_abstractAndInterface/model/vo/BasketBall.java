package com.kh.chap02_abstractAndInterface.model.vo;

public class BasketBall extends Sports{
	
	public void rule() {
		/*상속받는 순간 */
		/*부모 클래스에 있는 추상 메소드를 강제 오버라이딩 하게 뜸. 미완성 상태이기 떄문에*/
		System.out.println("공을 던져서 링에 넣어야 한다.");
	}
	

}
