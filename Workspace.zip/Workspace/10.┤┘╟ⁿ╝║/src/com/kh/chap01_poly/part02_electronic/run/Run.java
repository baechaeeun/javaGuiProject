package com.kh.chap01_poly.part02_electronic.run;

import com.kh.chap01_poly.part02_electronic.controller.ElectronicController;
import com.kh.chap01_poly.part02_electronic.controller.ElectronicController2;
import com.kh.chap01_poly.part02_electronic.model.vo.Desktop;
import com.kh.chap01_poly.part02_electronic.model.vo.Electronic;
import com.kh.chap01_poly.part02_electronic.model.vo.NoteBook;
import com.kh.chap01_poly.part02_electronic.model.vo.Tablet;

public class Run {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		/*ElectronicController ec=new ElectronicController();
		
		ec.insert(new Desktop("삼성", "데스크탑", 120000, "Gefoce 1070"));
		ec.insert(new NoteBook("LG","그램",150000,3));
		ec.insert(new Tablet("애플","아이패드",180000,false));
		
		Desktop d=ec.selectDesktop();
		NoteBook n=ec.selectNoteBook();
		Tablet t=ec.selectTablet();
		
		System.out.println(d);
		System.out.println(n);
		System.out.println(t);*/
		
		ElectronicController2 ec=new ElectronicController2();
		
		ec.insert(new Desktop("삼성", "데스크탑", 120000, "Gefoce 1070"));
		ec.insert(new NoteBook("LG","그램",150000,3));
		ec.insert(new Tablet("애플","아이패드",180000,false));
		
		Electronic d=ec.select(0);
		Electronic n=ec.select(1);
		Electronic t=ec.select(2);
		
		System.out.println(d);
		System.out.println(n);
		System.out.println(t);
		
		Electronic elec[]=ec.select();
		//instanceof 사용, 자식 메소드 호출
		
		for(Electronic e:elec){
			if(e instanceof Desktop) {
				System.out.println(((Desktop) e).getGraphic());
			}
			else if(e instanceof NoteBook)
				System.out.println(((NoteBook) e).getUsbPort());
			else if(e instanceof Tablet)
				System.out.println(((Tablet) e).isPenFlag());
		}
		
		//다형성을 사용하는 이유
		//1. 부모타입의 객체 배열로 다양한 자식들을 받아올 수 있다.
		//-> 부모타입 하나로 다양한 자식들을 다룰 수 있다.
		
		//2. 매개변수에 다형성을 적용하는 경우 메소드 개수가 확 줄어든다.
		
	}

}
